﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    public class pCliente
    {
        //Cambio en la base de datos DNI por NumeroDocumento
        public static List<Entidades.Cliente> getAll()
        { 
            List<Entidades.Cliente> clientes = new List<Entidades.Cliente>();
            SQLiteCommand cmd = new SQLiteCommand("select IdCliente, Nombre, Apellido, DNI, Telefono, Email, LocalidadID, TipoDocumentoID from Cliente ORDER BY IdCliente ASC");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();

            while (obdr.Read())
            {
                Entidades.Cliente cliente = new Entidades.Cliente();
                cliente.IdCliente = obdr.GetInt32(0);
                cliente.Nombre = obdr.GetString(1);
                cliente.Apellido = obdr.GetString(2);
                cliente.NumeroDocumento = obdr.GetString(3);
                cliente.Telefono = obdr.GetInt32(4);
                cliente.Email = obdr.GetString(5);
                cliente.Localidad = pLocalidad.getById(obdr.GetInt32(6)); 
                cliente.TipoDocumento = pTipoDocumento.getById(obdr.GetInt32(7));
                //Obtengo todos los testamentos de la base de datos que tengan el ID de la versión
                //cliente.CuentaClientes = pCuentaCliente.getCuentaClientes(cliente.IdCliente);
                clientes.Add(cliente);
            }
            return clientes;
        }
        public static Entidades.Cliente getById(int id)
        {
            Cliente v = new Cliente();
            SQLiteCommand cmd = new SQLiteCommand("select IdCliente, Nombre, Apellido, DNI, Telefono, Email, LocalidadID, TipoDocumentoID from Cliente where IdCliente = @IdCliente");
            cmd.Parameters.Add(new SQLiteParameter("@IdCliente", id));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                v.IdCliente = obdr.GetInt32(0);
                v.Nombre = obdr.GetString(1);
                v.Apellido = obdr.GetString(2);
                v.NumeroDocumento= obdr.GetString(3);
                v.Telefono= obdr.GetInt32(4);
                v.Email = obdr.GetString(5);
                v.Localidad = pLocalidad.getById(6);
                v.TipoDocumento = pTipoDocumento.getById(7);
                // obtengo de la bd todas las cuentas clientes por ID del cliente
                //v.CuentaClientes = pCuentaCliente.getCuentaClientes(v.IdCliente);
            }
            return v;
        }
        //Guardo el testamento en la BD recibiendo como argumento el id: de la localidad a la que pertenece, y el cliente que se va a guardar
        public static void Save(Cliente v)
        {
            SQLiteCommand cmd = new SQLiteCommand("insert into Cliente(IdCliente, TipoDocumentoID, Nombre, Apellido, DNI, Telefono, Email, LocalidadID) " +
                "values(@idCliente, @tipoDocumentoId, @nombre, @apellido, @DNI, @telefono, @email, @LocalidadID)");
            cmd.Parameters.Add(new SQLiteParameter("@idCliente", v.IdCliente));           
            cmd.Parameters.Add(new SQLiteParameter("@nombre", v.Nombre));
            cmd.Parameters.Add(new SQLiteParameter("@apellido", v.Apellido));
            cmd.Parameters.Add(new SQLiteParameter("@telefono", v.Telefono));
            cmd.Parameters.Add(new SQLiteParameter("@DNI", v.NumeroDocumento));
            cmd.Parameters.Add(new SQLiteParameter("@email", v.Email));
            cmd.Parameters.Add(new SQLiteParameter("@tipoDocumentoId", v.TipoDocumento.TipoDocumentoID));
            cmd.Parameters.Add(new SQLiteParameter("@LocalidadID", v.Localidad.IdLocalidad));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
        /*//Borro el cliente que se recibe en el argumento
        public static void Delete(Cliente v)
        {
            SQLiteCommand cmd = new SQLiteCommand("delete from Cliente where IdCliente = @IdCliente");
            cmd.Parameters.Add(new SQLiteParameter("@iIdCliente", v.IdCliente));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
        //Actualizo el client que se recibe en el argumento
        public static void Update(Cliente v)
        { 
            SQLiteCommand cmd = new SQLiteCommand("UPDATE Cliente SET Nombre = @nombre, Apellido = @apellido , DNI = @dni, Email = @email, LocalidadID = WHERE IdCliente = @IdCliente");
            cmd.Parameters.Add(new SQLiteParameter("@iIdCliente", v.IdCliente));
            cmd.Parameters.Add(new SQLiteParameter("@nombre", v.Nombre));
            cmd.Parameters.Add(new SQLiteParameter("@apellido", v.Apellido));
            cmd.Parameters.Add(new SQLiteParameter("@dni", v.NumeroDocumento));
            cmd.Parameters.Add(new SQLiteParameter("@email", v.Email));
            
            
            //cmd.Parameters.Add(new SQLiteParameter("@", v.Apellido));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
        public static List<Cliente> getClientes(int LocalidadID)
        {
            List<Cliente> localidades = new List<Cliente>();
            SQLiteCommand cmd = new SQLiteCommand("select IdLocalidad, NombreLocalidad , ProvinciaID from Localidad where ProvinciaID = @ProvinciaID ORDER BY numero ASC");
            cmd.Parameters.Add(new SQLiteParameter("@ProvinciaID", LocalidadID));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                Cliente localidad = new Cliente();
                localidad.IdCliente = obdr.GetInt32(0);
                localidad.Nombre = obdr.GetString(1);
                localidad.Apellido = obdr.GetString(2);
                localidad.NumeroDocumento = obdr.GetString(3);
                localidad.Email = obdr.GetString(3);

                //Obtengo todos los libros de la base de datos que tengan el ID del testamento
                //localidad.Estadias = pLibro.getLibros(testamento.Id);
                localidades.Add(localidad);
            }
            return localidades;
        }*/
        public static void Delete(Cliente v)
        {
            SQLiteCommand cmd = new SQLiteCommand("delete from Cliente where IdCliente = @IdCliente");
            cmd.Parameters.Add(new SQLiteParameter("@IdCliente", v.IdCliente));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
    }
}
