﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    public class pCuentaCliente
    {
        public static List<CuentaCliente> getAll()
        {
            List<CuentaCliente> cuentasDeClientes = new List<CuentaCliente>();
            SQLiteCommand cmd = new SQLiteCommand("select IdCuentaCliente, Saldo, ClienteID from CuentaCliente ORDER BY ClienteID ASC");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                CuentaCliente cuentaCliente = new CuentaCliente();
                cuentaCliente.IdCuentaCliente = obdr.GetInt32(0);
                cuentaCliente.Saldo = obdr.GetDouble(1);
                cuentaCliente.Cliente = pCliente.getById(obdr.GetInt32(2));
                //Obtengo todos los gastos y estadias de la base de datos que este asociada al ID de la cuenta del cliente 
                //cuentaCliente.Gastos = pCuentaGasto.GetGastos(cuentaCliente.IdCuentaCliente);
                //cuentaCliente.Estadias = pEstadia.getEstadias(cuentaCliente.IdCuentaCliente);
                cuentasDeClientes.Add(cuentaCliente);
            }
            return cuentasDeClientes;
        }
        public static void Save(int ClienteID, int GastoExtraID, CuentaCliente t)
        {
            SQLiteCommand cmd = new SQLiteCommand("insert into CuentaCliente(Saldo, ClienteID,GastoExtraID) values(@Saldo, @ClienteID, @GastoExtraID)");
            cmd.Parameters.Add(new SQLiteParameter("@ClienteID", ClienteID));
            cmd.Parameters.Add(new SQLiteParameter("@GastoExtraID", GastoExtraID));

            cmd.Parameters.Add(new SQLiteParameter("@idCuentaCliente", t.IdCuentaCliente));
            cmd.Parameters.Add(new SQLiteParameter("@saldo", t.Saldo));
            
            

            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        //Borro el testamento que se recibe en el argumento
        public static void Delete(CuentaCliente t)
        {
            
            SQLiteCommand cmd = new SQLiteCommand("delete from CuentaCliente where IdCuentaCliente = @IdCuentaCliente");
            cmd.Parameters.Add(new SQLiteParameter("@idCuentaCliente", t.IdCuentaCliente));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        //Actualizo el testamento que se recibe en el argumento
        public static void Update(CuentaCliente t)
        {
            SQLiteCommand cmd = new SQLiteCommand("UPDATE CuentaCliente SET Saldo = @Saldo WHERE IdCuentaCliente = @IdCuentaCliente");
            cmd.Parameters.Add(new SQLiteParameter("@IdCuentaCliente", t.IdCuentaCliente));
            cmd.Parameters.Add(new SQLiteParameter("@numeroTestamento", t.Saldo));
            
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        //Obtengo las cuentasCliente de la tabla Cliente, recibiendo como argumento el id de la del cliente
        public static List<CuentaCliente> getCuentaClientes(int ClienteID ) 
        {
            List<CuentaCliente> cuentasDeClientes = new List<CuentaCliente>();
            SQLiteCommand cmd = new SQLiteCommand("select IdCuentaCliente, Saldo, from Cliente where ClienteID = @ClienteID ORDER BY Saldo ASC");
            cmd.Parameters.Add(new SQLiteParameter("@ClienteID", ClienteID));
            //cmd.Parameters.Add(new SQLiteParameter("@versionID", GastoExtraID));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                CuentaCliente cuentaCliente = new CuentaCliente();
                cuentaCliente.IdCuentaCliente = obdr.GetInt32(0);
                cuentaCliente.Saldo = obdr.GetDouble(1);

                //Obtengo todos los gastos y estadias de la base de datos que este asociada al ID de la cuenta del cliente 
                //cuentaCliente.Gastos = pCuentaGasto.GetGastos(cuentaCliente.IdCuentaCliente);
                //cuentaCliente.Estadias = pEstadia.getEstadias(cuentaCliente.IdCuentaCliente);
                cuentasDeClientes.Add(cuentaCliente);
            }
            return cuentasDeClientes;
        }

        //internal static List<CuentaCliente> getCuentaClientes(int IdCuentaCliente)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
