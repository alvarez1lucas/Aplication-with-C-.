﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    public class pCuentaGasto
    {
        public static void Save(CuentaGasto c)
        {
            SQLiteCommand cmd = new SQLiteCommand("INSERT INTO CuentaGasto(FechaDelGasto, CuentaClienteID, GastoExtraID) values( @FechaDelGasto, @CuentaClienteID, @GastoExtraID)");
            cmd.Parameters.Add(new SQLiteParameter("@FechaDelGasto", c.FechaDelGasto));
            cmd.Parameters.Add(new SQLiteParameter("@CuentaClienteID", c.CuentaCliente.IdCuentaCliente));
            cmd.Parameters.Add(new SQLiteParameter("@GastoExtraID", c.Gastos.IdGastoExtra));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        //Borro el testamento que se recibe en el argumento
        public static void Delete(CuentaGasto c)
        {
            
            SQLiteCommand cmd = new SQLiteCommand("delete from CuentaGasto where IdCuentaGasto = @IdCuentaGasto");
            cmd.Parameters.Add(new SQLiteParameter("@IdCuentaGasto", c.IdCuentaGasto));
            cmd.Parameters.Add(new SQLiteParameter("@id", c.FechaDelGasto));

            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        //Actualizo el testamento que se recibe en el argumento
        public static void Update(CuentaGasto t)
        {
            SQLiteCommand cmd = new SQLiteCommand("UPDATE Testamento SET FechaDelGasto = @FechaDelGasto WHERE IdCuentaGasto = @IdCuentaGasto");
            cmd.Parameters.Add(new SQLiteParameter("@IdCuentaGasto", t.IdCuentaGasto));
            cmd.Parameters.Add(new SQLiteParameter("@numeroTestamento", t.FechaDelGasto));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
        public static List<CuentaGasto> GetGastos(int ClienteID, int GastoExtraID)
        {
            List<CuentaGasto> cuentasgastos = new List<CuentaGasto>();
            SQLiteCommand cmd = new SQLiteCommand("select IdCuentaGasto, FechaDelGasto, ClienteID, GastoExtraID from CuentaGasto where ClienteID = @ClienteID, GastoExtraID = @GastoExtraID  ORDER BY FechaDelGasto ASC");
            cmd.Parameters.Add(new SQLiteParameter("@ClienteID", ClienteID));
            cmd.Parameters.Add(new SQLiteParameter("@GastoExtraID", GastoExtraID));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                CuentaGasto cuentagasto = new CuentaGasto();
                cuentagasto.IdCuentaGasto = obdr.GetInt32(0);
                cuentagasto.FechaDelGasto = obdr.GetString(1);
                //Obtengo todos los libros de la base de datos que tengan el ID del testament
                //cuentagasto.Reserva = pLibro.getLibros(testamento.Id);
                cuentasgastos.Add(cuentagasto);
            }
            return cuentasgastos;
        }

        internal static List<CuentaGasto> GetGastos(int idCliente) 
        {
            throw new NotImplementedException();
        }

        
    }
}
