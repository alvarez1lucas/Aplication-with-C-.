﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    public class pEstadia
    {
        //Guardo el testamento en la BD recibiendo como argumento el id: de la versión a la que pertenece, y el testamento que se va a guardar
        public static void Save(Estadia t)
        {
            SQLiteCommand cmd = new SQLiteCommand("INSERT INTO Estadía(CostoTotal, CuentaClienteID, ReservaID ) values(@CostoTotal, @CuentaClienteID, @ReservaID)");
            cmd.Parameters.Add(new SQLiteParameter("@CostoTotal", t.CostoTotal));
            cmd.Parameters.Add(new SQLiteParameter("@ReservaID", t.Reserva.IdReserva));
            cmd.Parameters.Add(new SQLiteParameter("@CuentaClienteID", t.CuentaCliente.IdCuentaCliente));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        //Borro el testamento que se recibe en el argumento
        public static void Delete(Estadia t)
        {
            //Console.WriteLine();
            //Console.WriteLine("Se va a eliminar la estadia: " + t.Nombre);
            //Console.ReadKey(true);
            SQLiteCommand cmd = new SQLiteCommand("DELETE FROM Estadia where IdEstadia = @IdEstadia");
            cmd.Parameters.Add(new SQLiteParameter("@IdEstadia", t.IdEstadia));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        //Actualizo el testamento que se recibe en el argumento
        public static void Update(Estadia t)
        {
            SQLiteCommand cmd = new SQLiteCommand("UPDATE Estadia SET CostoTotal = @CostoTotal,  WHERE IdEstadia = @IdEstadia");
            cmd.Parameters.Add(new SQLiteParameter("@IdEstadia", t.IdEstadia));
            cmd.Parameters.Add(new SQLiteParameter("@CostoTotal", t.CostoTotal));
            
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
        public static Estadia getById(int id)
        {
            Estadia h = new Estadia();
            SQLiteCommand cmd = new SQLiteCommand("select IdEstadia, CostoTotal from Estadia where IdEstadia = @IdEstadia");
            cmd.Parameters.Add(new SQLiteParameter("@IdEstadia", id));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                h.IdEstadia = obdr.GetInt32(0);
                h.CostoTotal = obdr.GetInt32(1);
                //h.CostoTotal = obdr.GetInt32(1);
                //h.// = pReserva.get(h.IdEstadia);
            }
            return h;
        }

        //Obtengo los testamentos de la Versión, recibiendo como argumento el id de la versión
        public static List<Estadia> getEstadias(int ClienteID, int ReservaID)
        {
            List<Estadia> estadias = new List<Estadia>();
            SQLiteCommand cmd = new SQLiteCommand("select IdEstadia, CostoTotal, ClienteID, ReservaID from Estadia where ClienteID = @ClienteID, ReservaID = @ReservaID ORDER BY CostoTotal ASC");
            cmd.Parameters.Add(new SQLiteParameter("@ClienteID", ClienteID));
            cmd.Parameters.Add(new SQLiteParameter("@ReservaID", ReservaID));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                Estadia estadia = new Estadia();
                estadia.IdEstadia = obdr.GetInt32(0);
                estadia.CostoTotal = obdr.GetInt32(1);
                
                //Obtengo todos las reservas de la base de datos que tengan el ID del estadia
                //estadia.Reservas = pReserva.getReservas(estadia.IdEstadia);
                estadias.Add(estadia);
            }
            return estadias;
        }
    }
}
