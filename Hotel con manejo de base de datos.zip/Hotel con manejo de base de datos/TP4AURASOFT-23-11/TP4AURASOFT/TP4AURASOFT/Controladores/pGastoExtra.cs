﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    public class pGastoExtra
    {
        public static List<GastoExtra> getAll()
        {
            List<GastoExtra> gastosExtras = new List<GastoExtra>();
            SQLiteCommand cmd = new SQLiteCommand("select IdGastoExtra, TipoGasto, Valor from GastoExtra ORDER BY TipoGasto ASC");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();

            while (obdr.Read())
            {
                GastoExtra gastoExtra = new GastoExtra();
                gastoExtra.IdGastoExtra = obdr.GetInt32(0);
                gastoExtra.TipoGasto = obdr.GetString(1);
                gastoExtra.Valor = obdr.GetDouble(2);
                //Obtengo todos los gastos de la base de datos que tengan el ID del gasto extra
                //gastoExtra.Gastos = pCuentaGasto.GetGastos(gastoExtra.IdGastoExtra);
                gastosExtras.Add(gastoExtra);
            }
            return gastosExtras;
        }
        public static GastoExtra getById(int id)
        {
            GastoExtra v = new GastoExtra();
            SQLiteCommand cmd = new SQLiteCommand("select IdGastoExtra, TipoGasto, Valor from GastoExtra where IdGastoExtra = @IdGastoExtra");
            cmd.Parameters.Add(new SQLiteParameter("@IdGastoExtra", id));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                v.IdGastoExtra = obdr.GetInt32(0);
                v.TipoGasto = obdr.GetString(1);
                v.Valor = obdr.GetDouble(2);
            }
            return v;
        }
        public static void Save(GastoExtra v)
        {
            SQLiteCommand cmd = new SQLiteCommand("insert into GastoExtra(TipoGasto, Valor) values(@TipoGasto, @Valor)");
            cmd.Parameters.Add(new SQLiteParameter("@TipoGasto", v.TipoGasto));
            cmd.Parameters.Add(new SQLiteParameter("@Valor", v.Valor));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        public static void Delete(GastoExtra v)
        {
            SQLiteCommand cmd = new SQLiteCommand("delete from GastoExtra where IdGastoExtra = @IdGastoExtra");
            cmd.Parameters.Add(new SQLiteParameter("@IdGastoExtra", v.IdGastoExtra));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
        public static void Update(GastoExtra v)
        {
            SQLiteCommand cmd = new SQLiteCommand("UPDATE GastoExtra SET IdGastoExtra = @IdGastoExtra, TipoGasto = @TipoGasto, Valor = @Valor WHERE IdGastoExtra = @IdGastoExtra");
            cmd.Parameters.Add(new SQLiteParameter("@IdGastoExtra", v.IdGastoExtra));
            cmd.Parameters.Add(new SQLiteParameter("@TipoGasto", v.TipoGasto));
            cmd.Parameters.Add(new SQLiteParameter("@Valor", v.Valor));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
    }
}
