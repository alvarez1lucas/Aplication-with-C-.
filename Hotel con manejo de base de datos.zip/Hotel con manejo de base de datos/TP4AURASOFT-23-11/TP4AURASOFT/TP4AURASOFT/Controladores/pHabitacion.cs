﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    public class pHabitacion
    {
        public static List<Habitacion> getAll()
        {
            List<Habitacion> versiones = new List<Habitacion>();
            SQLiteCommand cmd = new SQLiteCommand("select IdHabitacion, NumeroHabitacion, PrecioPorNoche, CamasIndividuales, CamasMatrimoniales, Baños, Disponibilidad from Habitacion ORDER BY NumeroHabitacion ASC");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();

            while (obdr.Read())
            {
                Habitacion version = new Habitacion();
                version.IdHabitacion = obdr.GetInt32(0);
                version.NumeroHabitacion = obdr.GetInt32(1);
                version.PrecioPorNoche = obdr.GetDouble(2);
                version.CamasIndividuales = obdr.GetInt32(3);
                version.CamasMatrimoniales = obdr.GetInt32(4);
                version.Toilets = obdr.GetInt32(5);
                version.Disponibilidad = obdr.GetInt32(6);
                //Obtengo todos los testamentos de la base de datos que tengan el ID de la versión
                //version.Testamentos = pTestamento.getTestamentos(version.Id);
                versiones.Add(version);
            }
            return versiones;
        }
        public static Habitacion getById(int id)
        {
            Habitacion h = new Habitacion();
            SQLiteCommand cmd = new SQLiteCommand("select IdHabitacion, NumeroHabitacion, PrecioPorNoche, CamasIndividuales, CamasMatrimoniales, Baños, Disponibilidad from Habitacion where IdHabitacion = @id");
            cmd.Parameters.Add(new SQLiteParameter("@id", id));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                h.IdHabitacion = obdr.GetInt32(0);
                h.NumeroHabitacion = obdr.GetInt32(1);
                h.PrecioPorNoche = obdr.GetDouble(2);
                h.CamasIndividuales = obdr.GetInt32(3);
                h.CamasMatrimoniales = obdr.GetInt32(4);
                h.Toilets = obdr.GetInt32(5);
                h.Disponibilidad = obdr.GetInt32(6);
                //Obtengo todos las reservas de la base de datos que tengan el ID del habitacion
                //h.Reservas = pReserva.getReservas(h.IdHabitacion);
            }
            return h;
        }
        public static void Save(Habitacion v)
        {
            SQLiteCommand cmd = new SQLiteCommand("insert into Habitacion(NumeroHabitacion, PrecioPorNoche, CamasIndividuales, CamasMatrimoniales, Baños, Disponibilidad) values(@numeroVersion, @nombre, @camasIndividuales, @camasMatrimoniales, @toilets, @disponibilidad)");
            cmd.Parameters.Add(new SQLiteParameter("@numeroVersion", v.NumeroHabitacion));
            cmd.Parameters.Add(new SQLiteParameter("@nombre", v.PrecioPorNoche));
            cmd.Parameters.Add(new SQLiteParameter("@camasIndividuales", v.CamasIndividuales));
            cmd.Parameters.Add(new SQLiteParameter("@camasMatrimoniales", v.CamasMatrimoniales));
            cmd.Parameters.Add(new SQLiteParameter("@toilets", v.Toilets));
            cmd.Parameters.Add(new SQLiteParameter("@disponibilidad", v.Disponibilidad));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        public static void Delete(Habitacion v)
        {
            SQLiteCommand cmd = new SQLiteCommand("DELETE FROM Habitacion WHERE IdHabitacion = @id");
            cmd.Parameters.Add(new SQLiteParameter("@id", v.IdHabitacion));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
        public static void Update(Habitacion v)
        {
            SQLiteCommand cmd = new SQLiteCommand("UPDATE Habitacion SET NumeroHabitacion = @numeroVersion, PrecioPorNoche = @nombre, CamasIndividuales = @camasIndividuales, CamasMatrimoniales = @camasMatrimoniales, Baños = @toilets, Disponibilidad = @disponibilidad WHERE IdHabitacion = @id");
            cmd.Parameters.Add(new SQLiteParameter("@numeroVersion", v.NumeroHabitacion));
            cmd.Parameters.Add(new SQLiteParameter("@nombre", v.PrecioPorNoche));
            cmd.Parameters.Add(new SQLiteParameter("@camasIndividuales", v.CamasIndividuales));
            cmd.Parameters.Add(new SQLiteParameter("@camasMatrimoniales", v.CamasMatrimoniales));
            cmd.Parameters.Add(new SQLiteParameter("@toilets", v.Toilets));
            cmd.Parameters.Add(new SQLiteParameter("@disponibilidad", v.Disponibilidad));
            cmd.Parameters.Add(new SQLiteParameter("@id", v.IdHabitacion));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        public static List<Habitacion> getAllDisponibles()
        {
            List<Habitacion> versiones = new List<Habitacion>();
            SQLiteCommand cmd = new SQLiteCommand("select IdHabitacion, NumeroHabitacion, PrecioPorNoche, CamasIndividuales, CamasMatrimoniales, Baños, Disponibilidad from Habitacion WHERE Disponibilidad = 0 ORDER BY NumeroHabitacion ASC");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();

            while (obdr.Read())
            {
                Habitacion version = new Habitacion();
                version.IdHabitacion = obdr.GetInt32(0);
                version.NumeroHabitacion = obdr.GetInt32(1);
                version.PrecioPorNoche = obdr.GetDouble(2);
                version.CamasIndividuales = obdr.GetInt32(3);
                version.CamasMatrimoniales = obdr.GetInt32(4);
                version.Toilets = obdr.GetInt32(5);
                version.Disponibilidad = obdr.GetInt32(6);
                //Obtengo todos los testamentos de la base de datos que tengan el ID de la versión
                //version.Testamentos = pTestamento.getTestamentos(version.Id);
                versiones.Add(version);
            }
            return versiones;
        }
    }
}
