﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    public class pLocalidad
    {
        //Guardo el localidad en la BD recibiendo como argumento el id: de la provincia a la que pertenece, y la localidad que se va a guardar
        public static void Save(int ProvinciaID, Localidad l)
        {
            SQLiteCommand cmd = new SQLiteCommand("insert into Localidad( NombreLocalidad, ProvinciaID) values( @nombreLocalidad, @ProvinciaID)");
            cmd.Parameters.Add(new SQLiteParameter("@nombreLocalidad", l.NombreLocalidad));
            cmd.Parameters.Add(new SQLiteParameter("@ProvinciaID", ProvinciaID));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
        //Obtengo los testamentos de la Versión, recibiendo como argumento el id de la versión
        public static List<Localidad> getLocalidades(int ProvinciaID)
        {
            List<Localidad> localidades = new List<Localidad>();
            SQLiteCommand cmd = new SQLiteCommand("select IdLocalidad, NombreLocalidad, ProvinciaID from Localidad where ProvinciaID = @ProvinciaID ORDER BY numero ASC");
            cmd.Parameters.Add(new SQLiteParameter("@ProvinciaID", ProvinciaID));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                Localidad localidad = new Localidad();
                localidad.IdLocalidad = obdr.GetInt32(0);
                localidad.NombreLocalidad = obdr.GetString(1);
                // Se sacó la lista Clientes de la entidad
                //Obtengo todos los clientes de la base de datos que tengan el ID de la localidad
                //localidad.Clientes = pCliente.getClientes(localidad.IdLocalidad);
                //localidades.Add(localidad);
            }
            return localidades;
        }

        public static List<Localidad> getAll()
        {
            List<Localidad> localidades = new List<Localidad>();
            SQLiteCommand cmd = new SQLiteCommand("select IdLocalidad, NombreLocalidad, ProvinciaID from Localidad ORDER BY NombreLocalidad ASC");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();

            while (obdr.Read())
            {
                Localidad localidad = new Localidad();
                localidad.IdLocalidad = obdr.GetInt32(0);
                localidad.NombreLocalidad = obdr.GetString(1);
                localidad.Provincia = pProvincia.getById(obdr.GetInt32(2));
                // Se sacó la lista Clientes de la entidad
                localidades.Add(localidad);
            }
            return localidades;
        }
        public static Localidad getById(int id)
        {
            Localidad v = new Localidad();
            SQLiteCommand cmd = new SQLiteCommand("select IdLocalidad, NombreLocalidad, ProvinciaID from Localidad where IdLocalidad = @IdLocalidad");
            cmd.Parameters.Add(new SQLiteParameter("@IdLocalidad", id));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                v.IdLocalidad = obdr.GetInt32(0);
                v.NombreLocalidad = obdr.GetString(1);
                v.Provincia = pProvincia.getById(obdr.GetInt32(2));
                //Se sacó la lista Clientes de la entidad
                //v.Clientes = pCliente.getClientes(v.IdLocalidad);
            }
            return v;
        
        }
        
    }
}
