﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    public class pProvincia
    {
        public static List<Provincia> getAll()
        {
            List<Provincia> provincias = new List<Provincia>();
            SQLiteCommand cmd = new SQLiteCommand("select IdProvincia, NombreProvincia from Provincia ORDER BY NombreProvincia ASC");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();

            while (obdr.Read())
            {
                Provincia provincia = new Provincia();
                provincia.IdProvincia = obdr.GetInt32(0);
                provincia.NombreProvincia = obdr.GetString(1);
                
                //Obtengo todos los testamentos de la base de datos que tengan el ID de la versión
                //provincia.Localidades = pLocalidad.getLocalidades(provincia.IdProvincia);
                provincias.Add(provincia);
            }
            return provincias;
        }
        public static Provincia getById(int id)
        {
            Provincia v = new Provincia();
            SQLiteCommand cmd = new SQLiteCommand("select IdProvincia, NombreProvincia from Provincia where IdProvincia = @IdProvincia");
            cmd.Parameters.Add(new SQLiteParameter("@IdProvincia", id));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                v.IdProvincia = obdr.GetInt32(0);
                v.NombreProvincia = obdr.GetString(1);
                
                //Obtengo todos las localidad de la base de datos que tengan el ID del Provincia
                //v.Localidades = pLocalidad.getLocalidades(v.IdProvincia);
            }
            return v;
        }
        
        //public static void Save(Provincia v)
        //{
        //    SQLiteCommand cmd = new SQLiteCommand("insert into version(numeroVersion, nombre) values(@numeroVersion)");
        //    cmd.Parameters.Add(new SQLiteParameter("@numeroVersion", v.NombreProvincia));

        //    cmd.Connection = Conexion.Connection;
        //    cmd.ExecuteNonQuery();
        //}

        //public static void Delete(Provincia v)
        //{
        //    SQLiteCommand cmd = new SQLiteCommand("delete from Provincia where IdProvincia = @IdProvincia");
        //    cmd.Parameters.Add(new SQLiteParameter("@IdProvincia", v.IdProvincia));
        //    cmd.Connection = Conexion.Connection;
        //    cmd.ExecuteNonQuery();
        //}
        //public static void Update(Provincia v)
        //{
        //    SQLiteCommand cmd = new SQLiteCommand("UPDATE version SET nombre = @nombre, numeroVersion = @numeroVersion WHERE id = @id");
        //    cmd.Parameters.Add(new SQLiteParameter("@id", v.IdProvincia));
        //    cmd.Parameters.Add(new SQLiteParameter("@numeroVersion", v.NombreProvincia));
        //    //cmd.Parameters.Add(new SQLiteParameter("@nombre", v.Nombre));
        //    cmd.Connection = Conexion.Connection;
        //    cmd.ExecuteNonQuery();
        //}
    }
}
