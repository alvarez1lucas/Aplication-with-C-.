﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    public class pReserva
    {
        public static List<Reserva> getAll()
        {
            List<Reserva> reservas = new List<Reserva>();
            SQLiteCommand cmd = new SQLiteCommand("select IdReserva, FechaReserva, FechaEntrada, FechaSalida, HabitacionID, CantidadPersonas from Reserva ORDER BY IdReserva ASC");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                Reserva reserva = new Reserva();
                reserva.IdReserva = obdr.GetInt32(0);
                //reserva.EstadiaID = obdr.GetInt32(0);
                //reserva.HabitacionID = obdr.GetInt32(0);
                reserva.FechaReserva = obdr.GetString(1);
                reserva.FechaEntrada = obdr.GetString(2);
                reserva.FechaSalida = obdr.GetString(3);
                reserva.Habitacion = pHabitacion.getById(obdr.GetInt32(4));
                reserva.CantidadDePersonas = obdr.GetInt32(5);
                reservas.Add(reserva);
            }
            return reservas;
        }
        public static void Save(Reserva r)
        {
            SQLiteCommand cmd = new SQLiteCommand("insert into Reserva(FechaReserva, FechaEntrada, FechaSalida, CantidadPersonas, HabitacionID) values(@FechaReserva, @FechaEntrada, @FechaSalida, @CantidadDePersonas, @HabitacionID)");
            cmd.Parameters.Add(new SQLiteParameter("@FechaReserva", r.FechaReserva));
            cmd.Parameters.Add(new SQLiteParameter("@FechaEntrada", r.FechaEntrada));
            cmd.Parameters.Add(new SQLiteParameter("@FechaSalida", r.FechaSalida));
            cmd.Parameters.Add(new SQLiteParameter("@CantidadDePersonas", r.CantidadDePersonas));

            cmd.Parameters.Add(new SQLiteParameter("@HabitacionID", r.Habitacion.IdHabitacion));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        //Borro el reserva que se recibe en el argumento
        public static void Delete(Reserva r)
        {

            SQLiteCommand cmd = new SQLiteCommand("delete from Reserva where IdReserva = @IdReserva");
            cmd.Parameters.Add(new SQLiteParameter("@IdReserva", r.IdReserva));

            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        //Actualizo el reserva que se recibe en el argumento
        public static void Update(Reserva t)
        {
            SQLiteCommand cmd = new SQLiteCommand("UPDATE Reserva SET FechaReserva = @FechaReserva, FechaEntrada = @FechaEntrada, FechaSalida = @FechaSalida, CantidadDePersonas = @CantidadDePersonas  WHERE IdReserva = @IdReserva");
            //cmd.Parameters.Add(new SQLiteParameter("@id", t.HabitacionID));
            //cmd.Parameters.Add(new SQLiteParameter("@id", t.EstadiaID));
            cmd.Parameters.Add(new SQLiteParameter("@IdReserva", t.IdReserva));
            cmd.Parameters.Add(new SQLiteParameter("@FechaReserva", t.FechaReserva));
            cmd.Parameters.Add(new SQLiteParameter("@FechaEntrada", t.FechaEntrada));
            cmd.Parameters.Add(new SQLiteParameter("@FechaSalida", t.FechaSalida));
            cmd.Parameters.Add(new SQLiteParameter("@CantidadDePersonas", t.CantidadDePersonas));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }

        public static List<Reserva> getReservas( int HabitacionID)
        {
            List<Reserva> reservas = new List<Reserva>();
            SQLiteCommand cmd = new SQLiteCommand("select IdReservas, FechaReserva, FechaEntrada, FechaSalida, HabitacionID from Reserva where versionID = @versionID ORDER BY numero ASC");
            
            cmd.Parameters.Add(new SQLiteParameter("@HabitacionID", HabitacionID));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                Reserva reserva = new Reserva();
                reserva.IdReserva = obdr.GetInt32(0);
                //reserva.EstadiaID = obdr.GetInt32(0);
                //reserva.HabitacionID = obdr.GetInt32(0);
                reserva.FechaReserva = obdr.GetString(1);
                reserva.FechaEntrada = obdr.GetString(2);
                reserva.FechaSalida = obdr.GetString(3);

                reservas.Add(reserva);
            }
            return reservas;
        }
        public static Reserva getById(int id)
        {
            Reserva v = new Reserva();
            SQLiteCommand cmd = new SQLiteCommand("select id, numeroversion, nombre from Version where id = @id");
            cmd.Parameters.Add(new SQLiteParameter("@id", id));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                v.IdReserva = obdr.GetInt32(0);
                v.FechaReserva= obdr.GetString(1);
                v.FechaEntrada = obdr.GetString(2);
                v.FechaSalida = obdr.GetString(3);
                //v.Habitacion = obdr.
            }
            return v;
        }

        //internal static List<Reserva> getReservas(int idHabitacion)
        //{
        //    throw new NotImplementedException();
        //}

       
    }
}
