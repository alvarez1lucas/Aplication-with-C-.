﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Controladores
{
    internal class pTipoDocumento
    {
        public static List<TipoDocumento> getAll()
        {
            List<TipoDocumento> tipoDocumento = new List<TipoDocumento>();
            SQLiteCommand cmd = new SQLiteCommand("select IdTipoDocumento, TipoDocumento from TipoDocumento ORDER BY TipoDocumento ASC");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();

            while (obdr.Read())
            {
                TipoDocumento td = new TipoDocumento();
                td.TipoDocumentoID = obdr.GetInt32(0);
                td.Nombre = obdr.GetString(1);
                tipoDocumento.Add(td);
            }
            return tipoDocumento;
        }
        public static TipoDocumento getById(int id)
        {
            TipoDocumento td = new TipoDocumento();
            SQLiteCommand cmd = new SQLiteCommand("select IdTipoDocumento, TipoDocumento from TipoDocumento where IdTipoDocumento = @IdTipoDocumento");
            cmd.Parameters.Add(new SQLiteParameter("@IdTipoDocumento", id));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                td.TipoDocumentoID = obdr.GetInt32(0);
                td.Nombre = obdr.GetString(1);
            }
            return td;
        }
    }
}
