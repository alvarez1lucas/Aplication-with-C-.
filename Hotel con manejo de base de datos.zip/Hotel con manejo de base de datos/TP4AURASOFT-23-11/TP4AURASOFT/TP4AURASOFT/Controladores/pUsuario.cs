﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TP4AURASOFT.Entidades;
using System.Data.SQLite;
using TP4AURASOFT.Controladores;


namespace TP4AURASOFT.Controladores
{
    internal class pUsuario
    {
        public static List<Usuario> GetAll()
        {
            List<Usuario> usuarios = new List<Usuario>();
            SQLiteCommand cmd = new SQLiteCommand("SELECT IdUsuario, Username, password, nombre FROM Usuario");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {
                Usuario a = new Usuario();
                a.Id = obdr.GetInt32(0);
                a.Username = obdr.GetString(1);
                a.Password = obdr.GetString(2);
                a.Nombre = obdr.GetString(3);


                usuarios.Add(a);
            }
            return usuarios;
        }

        public static Usuario GetById(int id)
        {
            Usuario a = new Usuario();
            SQLiteCommand cmd = new SQLiteCommand("SELECT IdUsuario, username, password, nombre FROM Usuario Where IdUsuario =  @IdUsuario");
            cmd.Parameters.Add(new SQLiteParameter("@IdUsuario", id));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {

                a.Id = obdr.GetInt32(0);
                a.Username = obdr.GetString(1);
                a.Password = obdr.GetString(2);
                a.Nombre = obdr.GetString(3);
            }
            return a;
        }

        public static Usuario GetByUsername(string username)
        {
            Usuario a = new Usuario();
            SQLiteCommand cmd = new SQLiteCommand("SELECT IdUsuario, username, password, nombre FROM Usuario Where username = @username");
            cmd.Parameters.Add(new SQLiteParameter("@username", username));
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();
            while (obdr.Read())
            {

                a.Id = obdr.GetInt32(0);
                a.Username = obdr.GetString(1);
                a.Password = obdr.GetString(2);
                a.Nombre = obdr.GetString(3);
            }
            return a;
        }

        public static void Insert(Usuario u)
        {
            SQLiteCommand cmd = new SQLiteCommand("Insert Into Usuario(username, password, nombre) VALUES (@nombreusuario, @clave, @nombre)");
            cmd.Parameters.Add(new SQLiteParameter("@nombreusuario", u.Username));
            cmd.Parameters.Add(new SQLiteParameter("@clave", u.Password));
            cmd.Parameters.Add(new SQLiteParameter("@nombre", u.Nombre));
            cmd.Connection = Conexion.Connection;
            cmd.ExecuteNonQuery();
        }
    }
}
