﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class Cliente
    {
        public int IdCliente { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        
        //Agregar TipoDocumento (entidad)
        public TipoDocumento TipoDocumento { get; set; }
        public string NumeroDocumento { get; set; } // Cambiado a string porque los pasaportes pueden tener letras. 
        public int Telefono { get; set; }
        public string Email { get; set; }
        public Localidad Localidad { get; set; }
        //public CuentaCliente CuentaCliente { get; set; } // Esto es para establecer relacion con la entidad/tabla Cliente


        public Cliente()
        {
            //CuentaClientes = new List<CuentaCliente>();  
        }

        public Cliente(int idCliente, string nombre, string apellido, TipoDocumento tipoDocumento, string numeroDocumento, int telefono, string email, Localidad localidad/*CuentaCliente cuentaClientes*/)
        {
            IdCliente = idCliente;
            Nombre = nombre;
            Apellido = apellido;
            TipoDocumento = tipoDocumento;
            NumeroDocumento = numeroDocumento;
            Telefono = telefono;
            Email = email;
            Localidad = localidad;
            //CuentaCliente = cuentaClientes;
        }

        public override string ToString()
        {
            return $"{Apellido}, {Nombre} - {NumeroDocumento}";
        }
    }
}
