﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class CuentaCliente
    {
        public int IdCuentaCliente { get; set; }
        public double Saldo { get; set; }
        //public List<CuentaGasto> Gastos { get; set; }
        //public List<Estadia> Estadias { get; set; }
        public Cliente Cliente { get; set; } // Esto es para establecer relacion con la entidad/tabla Cliente

        public CuentaCliente()
        {
            //Gastos = new List<CuentaGasto>();
            //Estadias = new List<Estadia>();
        }
        public CuentaCliente(int idCliente, double saldo, Cliente cliente/*List<CuentaGasto> gastos, List<Estadia> estadias*/)
        {
            IdCuentaCliente = idCliente;
            Saldo = saldo;
            Cliente = cliente;
            //Gastos = gastos;
            //Estadias = estadias;
        }

        public override string ToString()
        {
            return $"{Cliente.Apellido}, {Cliente.Nombre} - {IdCuentaCliente}";
        }
    }
}
