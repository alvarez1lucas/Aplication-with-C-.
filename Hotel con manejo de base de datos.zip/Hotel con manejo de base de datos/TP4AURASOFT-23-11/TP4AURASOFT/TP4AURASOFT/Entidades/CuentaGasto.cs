﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class CuentaGasto
    {
        //public Cliente cliente { get; set; } //relacion con CuentaCliente
        //public int ClienteID { get; set; }
        //public int GastoExtraID { get; set; }
        public int IdCuentaGasto { get; set; }
        public string FechaDelGasto { get; set; }
        public GastoExtra Gastos { get; set; } // Relación uno a muchos con GastoExtra
        public CuentaCliente CuentaCliente { get; set; }

        public CuentaGasto()
        {
        }
        public CuentaGasto(int idCuentaGasto, string fechaDelGasto, GastoExtra gastoExtra, CuentaCliente cuentaCliente)
        {
            IdCuentaGasto = idCuentaGasto;
            FechaDelGasto = fechaDelGasto;
            Gastos = gastoExtra;
            CuentaCliente = cuentaCliente;
        }
    }
}
