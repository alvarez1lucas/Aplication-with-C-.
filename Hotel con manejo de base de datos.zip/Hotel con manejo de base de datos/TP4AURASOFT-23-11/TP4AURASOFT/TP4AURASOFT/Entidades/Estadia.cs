﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class Estadia
    {
        //public Cliente Cliente { get; set; }
        public int IdEstadia { get; set; }
        //public int ClienteID { get; set;
        public CuentaCliente CuentaCliente { get; set; }
        public double CostoTotal { get; set; }
        //public List<Reserva> Reservas { get; set; }
        public Reserva Reserva { get; set; }

        public Estadia()
        {
            //Reservas = new List<Reserva>();
        }
        public Estadia(int idEstadia, int cuentaClienteID, double costoTotal, CuentaCliente cuentaCliente, Reserva reserva)
        {
            IdEstadia = idEstadia;
            CuentaCliente = cuentaCliente;
            CostoTotal = costoTotal;
            Reserva = reserva;
        }
    }
}
