﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class GastoExtra
    {
        public int IdGastoExtra { get; set; }

        public string TipoGasto { get; set; }

        public double Valor { get; set; }

        //public List<CuentaGasto> Gastos { get; set; }

        public GastoExtra()
        {
            //Gastos = new List<CuentaGasto>();
        }

        public GastoExtra(int idGastoExtra, string tipoGasto, double valor/*, List<CuentaGasto> cuentaGastos*/)
        {
            this.IdGastoExtra = idGastoExtra;
            TipoGasto = tipoGasto;
            Valor = valor;
            //Gastos = cuentaGastos;
        }
    }
}
