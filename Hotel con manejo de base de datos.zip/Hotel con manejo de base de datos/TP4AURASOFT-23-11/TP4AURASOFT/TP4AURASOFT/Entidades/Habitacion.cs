﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class Habitacion
    {
        public int IdHabitacion { get; set; }
        public int NumeroHabitacion { get; set; }
        public double PrecioPorNoche { get; set; }
        public int CamasIndividuales { get; set; }
        public int CamasMatrimoniales { get; set; }
        public int Disponibilidad { get; set; }
        public int Toilets { get; set; }



        //public Reserva 
        //public List<Reserva> Reservas { get; set; }

        public Habitacion()
        {
            //Reservas = new List<Reserva>();
        }

        public Habitacion(int idHabitacion, int numeroHabitacion, double precioPorNoche, int camasIndividuales, int camasMatrimoniales, int disponibilidad, int toilet)
        {
            IdHabitacion = idHabitacion;
            NumeroHabitacion = numeroHabitacion;
            PrecioPorNoche = precioPorNoche;
            CamasIndividuales = camasIndividuales;
            CamasMatrimoniales = camasMatrimoniales;
            Disponibilidad = disponibilidad;
            Toilets = toilet;
        }
    }
}
