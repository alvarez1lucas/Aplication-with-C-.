﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class Localidad
    {
        public int IdLocalidad { get; set; }
        public string NombreLocalidad { get; set; }
        public Provincia Provincia { get; set; }
        //public List<Cliente> Clientes { get; set; } 

        public Localidad()
        {
            //Clientes = new List<Cliente>();
        }

        public Localidad(int idLocalidad, string nombreLocalidad, Provincia provincia/*, List<Cliente> clientes*/)
        {
            IdLocalidad = idLocalidad;
            NombreLocalidad = nombreLocalidad;
            Provincia = provincia;
            /*Clientes = clientes;*/
        }
    }
}
