﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class Provincia
    {
        public int IdProvincia { get; set; }
        public string NombreProvincia { get; set; }
        //public List<Localidad> Localidades { get; set; }

        public Provincia()
        {
            //Localidades = new List<Localidad>();
        }

        public Provincia(int idProvincia, string nombreProvincia/*, List<Localidad> localidades*/)
        {
            this.IdProvincia = idProvincia;
            this.NombreProvincia = nombreProvincia;
            //this.Localidades = localidades;
        }
    }
}
