﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class Reserva
    {
        public int IdReserva { get; set; }
        //public int HabitacionID { get; set; }
        //public int EstadiaID { get; set; }
        public string FechaReserva { get; set; }
        public string FechaEntrada { get; set; }
        public string FechaSalida { get; set; }
        public int CantidadDePersonas { get; set; }
        public Habitacion Habitacion { get; set; }


        public Reserva()
        {
        }


        public Reserva(int idReserva, string fechaReserva, string fechaEntrada, string fechaSalida, int cantidadDePersonas, Habitacion habitacion)
        {
            IdReserva = idReserva;
            FechaReserva = fechaReserva;
            FechaEntrada = fechaEntrada;
            FechaSalida = fechaSalida;
            CantidadDePersonas = cantidadDePersonas;
            Habitacion = habitacion;
        }

        public override string ToString()
        {
            return $"Hab. {Habitacion.NumeroHabitacion} - {FechaEntrada}";
        }
    }
}
