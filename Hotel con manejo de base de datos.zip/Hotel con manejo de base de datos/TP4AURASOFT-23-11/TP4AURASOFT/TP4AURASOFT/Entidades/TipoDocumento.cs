﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class TipoDocumento
    {
        public int TipoDocumentoID { get; set; }
        public string Nombre { get; set; }
        public TipoDocumento() { }
        public TipoDocumento(int tipoDocumentoID, string nombre)
        {
            TipoDocumentoID = tipoDocumentoID;
            Nombre = nombre;
        }
    }
}
