﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP4AURASOFT.Entidades
{
    public class Usuario
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public Usuario() { }

        public Usuario(int id, string nombre, string nombreUsuario, string clave)
        {
            Id = id;
            Nombre = nombre;
            Username = nombreUsuario;
            Password = clave;
        }
    }
}
