﻿using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Formularios
{
    public partial class AgregarCliente : Form
    {
        Entidades.Cliente cliente = new Entidades.Cliente(); // Siempre usar Entidades.Cliente porque sino por defecto hace referencia a Formularios.Cliente 
        public AgregarCliente()
        {
            InitializeComponent();
            /*cbLocalidad.ForeColor = Color.Gray;
            cbLocalidad.Text = " Seleccionar localidad";*/
        }


        private void AgregarCliente_Load(object sender, EventArgs e)
        {
            //this.ControlBox = false;
        }

        private void tbNombre_TextChanged(object sender, EventArgs e) //AÑADIR NOMBRE A CLIENTE
        {
            cliente.Nombre = tbNombre.Text;
        }

        private void tbApellido_TextChanged(object sender, EventArgs e)//AÑADIR APELLIDO A CLIENTE
        {
            cliente.Apellido = tbApellido.Text;
        }

        private void cbDocumentos_Click(object sender, EventArgs e) // Obtener desde la bas de datos todos tipos de documentos
        {
            tipoDocumentoBindingSource.DataSource = pTipoDocumento.getAll();
        }

        private void cbDocumentos_SelectedIndexChanged(object sender, EventArgs e)//AÑADIR TIPO DE DOCUMENTOS = PASAPORTE/DNI/OTROS
        {
            TipoDocumento td = (TipoDocumento)cbDocumentos.SelectedItem;
            cliente.TipoDocumento = td; // Se puede guardar directamente así porque el value member es TipoDocumentoID
        }

        private void tbNumDocumento_KeyPress(object sender, KeyPressEventArgs e) //Validar el ingreso del número de documento según el tipo elegido 
        {
            if (cbDocumentos.SelectedIndex != -1)
            {
                if (cliente.TipoDocumento.TipoDocumentoID <= 3) // Si el tipo de documento es CUIT, CUIL o DNI
                {
                    if (char.IsNumber(e.KeyChar))
                    {
                        e.Handled = false;
                    }
                    else if (e.KeyChar == (char)Keys.Back)
                    {
                        // Permite la tecla de retroceso (borrar)
                        e.Handled = false;
                    }
                    else { e.Handled = true; }
                }

                // Si el tipo de documento es pasaporte
                else
                {
                    if (char.IsNumber(e.KeyChar) || char.IsLetter(e.KeyChar))
                    {
                        e.KeyChar = char.ToUpper(e.KeyChar);
                        e.Handled = false;
                    }
                    else if (e.KeyChar == (char)Keys.Back)
                    {
                        // Permite la tecla de retroceso (borrar)
                        e.Handled = false;
                    }
                    else { e.Handled = true; }
                }
            }

            else
            {
                e.Handled = true;
            }


        }

        private void tbNumDocumento_TextChanged(object sender, EventArgs e)//AÑADIR NÚMERO DE DOCUMENTO TIPO INT
        {
            cliente.NumeroDocumento = tbNumDocumento.Text;
        }

        private void tbTelefono_KeyPress(object sender, KeyPressEventArgs e) // Validar que el ingreso sea numero
        {
            if (char.IsNumber(e.KeyChar) && tbTelefono.Text.Length < 9)
            {
                e.Handled = false;
            }
            else if (e.KeyChar == (char)Keys.Back)
            {
                // Permite la tecla de retroceso (borrar)
                e.Handled = false;
            }
            else { e.Handled = true; }
        }

        private void tbTelefono_TextChanged(object sender, EventArgs e)//AÑADIR NÚMERO DE TELEFONO TIPO INT
        {
            if (tbTelefono.Text.Length > 0)
            {
                cliente.Telefono = int.Parse(tbTelefono.Text);
            }
        }

        private void tbMail_TextChanged(object sender, EventArgs e)//AÑADIR MAIL
        {
            cliente.Email = tbMail.Text;
        }
        private void cbLocalidad_Click(object sender, EventArgs e) // SE CARGAN TODAS LAS LOCALIDADES AL COMBO BOX AL CLICKEARLO
        {
            cbLocalidad.ForeColor = Color.Black;
            localidadBindingSource.DataSource = pLocalidad.getAll();
        }

        private void cbLocalidad_SelectedIndexChanged(object sender, EventArgs e)//SELECCIONAR LOCALIDADES DE LA PROVINCIA DE ENTRE RIOS
        {
            Localidad l = (Localidad)cbLocalidad.SelectedItem;
            cliente.Localidad = l; // Se puede guardar directamente así porque el value member es LocalidadID
        }

        private void btAgregarClienteBD_Click(object sender, EventArgs e)//AÑADIR EL CLIENTE A LA BD
        {
            bool valido = true;

            foreach (Control c in this.Controls)
            {
                if (c.Text.Length == 0)
                {
                    valido = false;
                }
            }

            if (!valido)
            {
                MessageBox.Show("Por favor, complete todos los campos antes de agregar la habitación.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Detener la operación si hay campos vacíos
            }

            else
            {
                pCliente.Save(cliente);
                MessageBox.Show("Cliente guardado");
                Close();
            }

        }

        private void btCancelarAgregarCliente_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }

    }
}
