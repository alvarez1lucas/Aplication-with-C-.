﻿namespace TP4AURASOFT.Formularios
{
    partial class AgregarEstadia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AgregarEstadia));
            btCancelarEstadia = new Button();
            btAgregarEstadia = new Button();
            label1 = new Label();
            cbCuentaCliente = new ComboBox();
            cuentaClienteBindingSource = new BindingSource(components);
            label6 = new Label();
            label2 = new Label();
            cbReserva = new ComboBox();
            reservaBindingSource = new BindingSource(components);
            lbMonto = new Label();
            ((System.ComponentModel.ISupportInitialize)cuentaClienteBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)reservaBindingSource).BeginInit();
            SuspendLayout();
            // 
            // btCancelarEstadia
            // 
            btCancelarEstadia.Anchor = AnchorStyles.None;
            btCancelarEstadia.BackColor = SystemColors.Info;
            btCancelarEstadia.Location = new Point(570, 355);
            btCancelarEstadia.Name = "btCancelarEstadia";
            btCancelarEstadia.Size = new Size(97, 29);
            btCancelarEstadia.TabIndex = 10;
            btCancelarEstadia.Text = "Cancelar";
            btCancelarEstadia.UseVisualStyleBackColor = false;
            btCancelarEstadia.Click += btCancelarEstadia_Click;
            // 
            // btAgregarEstadia
            // 
            btAgregarEstadia.Anchor = AnchorStyles.None;
            btAgregarEstadia.BackColor = SystemColors.Info;
            btAgregarEstadia.Location = new Point(135, 355);
            btAgregarEstadia.Name = "btAgregarEstadia";
            btAgregarEstadia.Size = new Size(100, 29);
            btAgregarEstadia.TabIndex = 9;
            btAgregarEstadia.Text = "Agregar";
            btAgregarEstadia.UseVisualStyleBackColor = false;
            btAgregarEstadia.Click += btAgregarEstadia_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(253, 177);
            label1.Name = "label1";
            label1.Size = new Size(108, 20);
            label1.TabIndex = 11;
            label1.Text = "Cuenta Cliente:";
            label1.Click += label1_Click;
            // 
            // cbCuentaCliente
            // 
            cbCuentaCliente.Anchor = AnchorStyles.None;
            cbCuentaCliente.DataSource = cuentaClienteBindingSource;
            cbCuentaCliente.FormattingEnabled = true;
            cbCuentaCliente.Location = new Point(376, 174);
            cbCuentaCliente.Name = "cbCuentaCliente";
            cbCuentaCliente.Size = new Size(151, 28);
            cbCuentaCliente.TabIndex = 12;
            cbCuentaCliente.SelectedIndexChanged += cbCuentaCliente_SelectedIndexChanged;
            // 
            // cuentaClienteBindingSource
            // 
            cuentaClienteBindingSource.DataSource = typeof(Entidades.CuentaCliente);
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(253, 234);
            label6.Name = "label6";
            label6.Size = new Size(111, 20);
            label6.TabIndex = 21;
            label6.Text = "Monto a pagar:";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(289, 122);
            label2.Name = "label2";
            label2.Size = new Size(63, 20);
            label2.TabIndex = 23;
            label2.Text = "Reserva:";
            // 
            // cbReserva
            // 
            cbReserva.Anchor = AnchorStyles.None;
            cbReserva.DataSource = reservaBindingSource;
            cbReserva.FormattingEnabled = true;
            cbReserva.Location = new Point(376, 122);
            cbReserva.Name = "cbReserva";
            cbReserva.Size = new Size(151, 28);
            cbReserva.TabIndex = 24;
            cbReserva.SelectedIndexChanged += cbReserva_SelectedIndexChanged;
            // 
            // reservaBindingSource
            // 
            reservaBindingSource.DataSource = typeof(Entidades.Reserva);
            // 
            // lbMonto
            // 
            lbMonto.Anchor = AnchorStyles.None;
            lbMonto.AutoSize = true;
            lbMonto.BackColor = SystemColors.ButtonHighlight;
            lbMonto.Location = new Point(370, 234);
            lbMonto.Name = "lbMonto";
            lbMonto.Size = new Size(17, 20);
            lbMonto.TabIndex = 25;
            lbMonto.Text = "0";
            // 
            // AgregarEstadia
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(lbMonto);
            Controls.Add(cbReserva);
            Controls.Add(label2);
            Controls.Add(label6);
            Controls.Add(cbCuentaCliente);
            Controls.Add(label1);
            Controls.Add(btCancelarEstadia);
            Controls.Add(btAgregarEstadia);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "AgregarEstadia";
            Text = "AgregarEstadia";
            ((System.ComponentModel.ISupportInitialize)cuentaClienteBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)reservaBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btCancelarEstadia;
        private Button btAgregarEstadia;
        private Label label1;
        private ComboBox cbCuentaCliente;
        private Label label6;
        private Label label2;
        private ComboBox cbReserva;
        private BindingSource reservaBindingSource;
        private BindingSource cuentaClienteBindingSource;
        private Label lbMonto;
    }
}