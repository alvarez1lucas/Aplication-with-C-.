﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Formularios
{
    public partial class AgregarEstadia : Form
    {
        Estadia estadia = new Estadia();
        public AgregarEstadia()
        {
            InitializeComponent();
            CargarReservas();
            CargarCuentas();
            lbMonto.Visible = false;
        }

        private void CargarReservas()
        {
            reservaBindingSource.DataSource = pReserva.getAll();
            cbReserva.DisplayMember = "ToString()";
        }

        private void CargarCuentas()
        {
            cuentaClienteBindingSource.DataSource = pCuentaCliente.getAll();
            cbCuentaCliente.DisplayMember = "ToString()";
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cbReserva_SelectedIndexChanged(object sender, EventArgs e)
        {
            estadia.Reserva = (Reserva)cbReserva.SelectedItem;
            CalcularMonto();
        }

        private void cbCuentaCliente_SelectedIndexChanged(object sender, EventArgs e)//MOSTRAR ID CUENTA DE CLIENTE(LOS ID TIENEN QUE SER DE 5 DIGITOS
        {
            estadia.CuentaCliente = (CuentaCliente)cbCuentaCliente.SelectedItem;
        }

        private void CalcularMonto()
        {
            lbMonto.Visible = true;

            if (estadia != null && estadia.Reserva != null && estadia.Reserva.Habitacion != null)
            {
                DateTime entrada;
                DateTime salida;

                if (DateTime.TryParse(estadia.Reserva.FechaEntrada, out entrada) && DateTime.TryParse(estadia.Reserva.FechaSalida, out salida))
                {
                    TimeSpan diferenciaDias = salida - entrada;
                    int cantidadDias = (int)diferenciaDias.TotalDays;

                    double montoEstadia = estadia.Reserva.Habitacion.PrecioPorNoche * cantidadDias;

                    // Mostrar el monto en el Label
                    lbMonto.Text = $"${montoEstadia}";
                    estadia.CostoTotal = montoEstadia;
                }
            }

        }

        private void tbMontoEstadia_TextChanged(object sender, EventArgs e)
        {

        }

        private void btAgregarEstadia_Click(object sender, EventArgs e)//AÑADIR A LA BD
        {
            if (estadia.CuentaCliente != null
                && estadia.Reserva != null)
            {
                pEstadia.Save(estadia);
                MessageBox.Show("Estadía agregada correctamente");
                Close();
            }
            else
            {
                MessageBox.Show("Por favor, complete todos los campos antes de agregar la habitación", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Detener la operación si hay campos vacíos
            }
        }

        private void btCancelarEstadia_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }

    }
}
