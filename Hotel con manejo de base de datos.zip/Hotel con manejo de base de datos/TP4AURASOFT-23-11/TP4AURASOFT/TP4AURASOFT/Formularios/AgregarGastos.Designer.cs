﻿namespace TP4AURASOFT.Formularios
{
    partial class AgregarGastos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AgregarGastos));
            btCancelarGasto = new Button();
            btAgregarGasto = new Button();
            dtFechaGasto = new DateTimePicker();
            label4 = new Label();
            label3 = new Label();
            cbCliente = new ComboBox();
            cuentaClienteBindingSource = new BindingSource(components);
            label2 = new Label();
            cbTipoGastos = new ComboBox();
            gastoExtraBindingSource = new BindingSource(components);
            label1 = new Label();
            lbMonto = new Label();
            ((System.ComponentModel.ISupportInitialize)cuentaClienteBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)gastoExtraBindingSource).BeginInit();
            SuspendLayout();
            // 
            // btCancelarGasto
            // 
            btCancelarGasto.Anchor = AnchorStyles.None;
            btCancelarGasto.BackColor = SystemColors.Info;
            btCancelarGasto.Location = new Point(569, 349);
            btCancelarGasto.Name = "btCancelarGasto";
            btCancelarGasto.Size = new Size(106, 35);
            btCancelarGasto.TabIndex = 19;
            btCancelarGasto.Text = "Cancelar";
            btCancelarGasto.UseVisualStyleBackColor = false;
            btCancelarGasto.Click += btCancelarGasto_Click;
            // 
            // btAgregarGasto
            // 
            btAgregarGasto.Anchor = AnchorStyles.None;
            btAgregarGasto.BackColor = SystemColors.Info;
            btAgregarGasto.Location = new Point(127, 349);
            btAgregarGasto.Name = "btAgregarGasto";
            btAgregarGasto.Size = new Size(106, 35);
            btAgregarGasto.TabIndex = 18;
            btAgregarGasto.Text = "Agregar";
            btAgregarGasto.UseVisualStyleBackColor = false;
            btAgregarGasto.Click += btAgregarGasto_Click;
            // 
            // dtFechaGasto
            // 
            dtFechaGasto.Anchor = AnchorStyles.None;
            dtFechaGasto.Location = new Point(313, 286);
            dtFechaGasto.Name = "dtFechaGasto";
            dtFechaGasto.Size = new Size(273, 27);
            dtFechaGasto.TabIndex = 17;
            dtFechaGasto.ValueChanged += dtFechaGasto_ValueChanged;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(180, 291);
            label4.Name = "label4";
            label4.Size = new Size(113, 20);
            label4.TabIndex = 16;
            label4.Text = "Fecha de Gasto:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(240, 223);
            label3.Name = "label3";
            label3.Size = new Size(111, 20);
            label3.TabIndex = 14;
            label3.Text = "Monto a pagar:";
            // 
            // cbCliente
            // 
            cbCliente.Anchor = AnchorStyles.None;
            cbCliente.DataSource = cuentaClienteBindingSource;
            cbCliente.FormattingEnabled = true;
            cbCliente.Location = new Point(375, 104);
            cbCliente.Name = "cbCliente";
            cbCliente.Size = new Size(151, 28);
            cbCliente.TabIndex = 13;
            cbCliente.SelectedIndexChanged += cbCliente_SelectedIndexChanged;
            // 
            // cuentaClienteBindingSource
            // 
            cuentaClienteBindingSource.DataSource = typeof(Entidades.CuentaCliente);
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(287, 107);
            label2.Name = "label2";
            label2.Size = new Size(58, 20);
            label2.TabIndex = 12;
            label2.Text = "Cliente:";
            // 
            // cbTipoGastos
            // 
            cbTipoGastos.Anchor = AnchorStyles.None;
            cbTipoGastos.DataSource = gastoExtraBindingSource;
            cbTipoGastos.FormattingEnabled = true;
            cbTipoGastos.Location = new Point(375, 159);
            cbTipoGastos.Name = "cbTipoGastos";
            cbTipoGastos.Size = new Size(151, 28);
            cbTipoGastos.TabIndex = 11;
            cbTipoGastos.SelectedIndexChanged += cbTipoGastos_SelectedIndexChanged;
            // 
            // gastoExtraBindingSource
            // 
            gastoExtraBindingSource.DataSource = typeof(Entidades.GastoExtra);
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(246, 162);
            label1.Name = "label1";
            label1.Size = new Size(105, 20);
            label1.TabIndex = 10;
            label1.Text = "Tipo de Gasto:";
            // 
            // lbMonto
            // 
            lbMonto.Anchor = AnchorStyles.None;
            lbMonto.AutoSize = true;
            lbMonto.BackColor = SystemColors.ButtonHighlight;
            lbMonto.Location = new Point(375, 223);
            lbMonto.Name = "lbMonto";
            lbMonto.Size = new Size(17, 20);
            lbMonto.TabIndex = 26;
            lbMonto.Text = "0";
            // 
            // AgregarGastos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(lbMonto);
            Controls.Add(btCancelarGasto);
            Controls.Add(btAgregarGasto);
            Controls.Add(dtFechaGasto);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(cbCliente);
            Controls.Add(label2);
            Controls.Add(cbTipoGastos);
            Controls.Add(label1);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "AgregarGastos";
            Text = "AgregarGastos";
            ((System.ComponentModel.ISupportInitialize)cuentaClienteBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)gastoExtraBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btCancelarGasto;
        private Button btAgregarGasto;
        private DateTimePicker dtFechaGasto;
        private Label label4;
        private Label label3;
        private ComboBox cbCliente;
        private Label label2;
        private ComboBox cbTipoGastos;
        private Label label1;
        private Label lbMonto;
        private BindingSource cuentaClienteBindingSource;
        private BindingSource gastoExtraBindingSource;
    }
}