﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Formularios
{
    public partial class AgregarGastos : Form
    {
        CuentaGasto cuentaGasto = new CuentaGasto();
        public AgregarGastos()
        {
            InitializeComponent();
            CargarCuentas();
            CargarGastos();
            lbMonto.Visible = false;
        }

        private void CargarCuentas()
        {
            cuentaClienteBindingSource.DataSource = pCuentaCliente.getAll();
            cbCliente.DisplayMember = "ToString()";
        }
        private void CargarGastos()
        {
            gastoExtraBindingSource.DataSource = pGastoExtra.getAll();
            cbTipoGastos.DisplayMember = "TipoGasto";
        }
        private void cbCliente_SelectedIndexChanged(object sender, EventArgs e)//ID CLIENTE O CUENTA CLIENTE
        {
            cuentaGasto.CuentaCliente = (CuentaCliente)cbCliente.SelectedItem;
        }

        private void cbTipoGastos_SelectedIndexChanged(object sender, EventArgs e)//TIPOS DE GASTOS = COMIDA, LIMPIEZA, EXCURSIONES, ALQUILER PElICULA,etc
        {
            cuentaGasto.Gastos = (GastoExtra)cbTipoGastos.SelectedItem;
            if (cuentaGasto.Gastos != null)
            {
                lbMonto.Visible = true;
                lbMonto.Text = $"${cuentaGasto.Gastos.Valor}";
            }
        }

        private void dtFechaGasto_ValueChanged(object sender, EventArgs e)//FECHA EN LA QUE SE REALIZÓ EL GASTO
        {
            cuentaGasto.FechaDelGasto = dtFechaGasto.Value.ToString("yyyy-MM-dd");
        }

        private void btAgregarGasto_Click(object sender, EventArgs e)//AGREGAR EL GASTO A LA BD
        {
            if (cuentaGasto.CuentaCliente != null
                && cuentaGasto.FechaDelGasto != null && cuentaGasto.Gastos != null)
            {
                pCuentaGasto.Save(cuentaGasto);
                MessageBox.Show("Gasto agregado correctamente");
                Close();
            }
            else
            {
                MessageBox.Show("Por favor, complete todos los campos antes de agregar la habitación", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Detener la operación si hay campos vacíos
            }
        }

        private void btCancelarGasto_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }
    }
}
