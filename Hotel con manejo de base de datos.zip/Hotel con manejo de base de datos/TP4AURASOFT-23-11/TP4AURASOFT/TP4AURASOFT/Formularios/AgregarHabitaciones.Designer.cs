﻿namespace TP4AURASOFT.Formularios
{
    partial class AgregarHabitaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AgregarHabitaciones));
            label5 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btCancelarAgregarHabitacion = new Button();
            btAgregarHabitacionBD = new Button();
            nudCamasIndividuales = new NumericUpDown();
            nudCamasMatrimoniales = new NumericUpDown();
            tbNúmeroHabitación = new TextBox();
            tbMontoPorNoche = new TextBox();
            cbDisponibilidad = new ComboBox();
            label6 = new Label();
            label4 = new Label();
            lbCapacidad = new Label();
            label7 = new Label();
            nudBaños = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)nudCamasIndividuales).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudCamasMatrimoniales).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudBaños).BeginInit();
            SuspendLayout();
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(393, 197);
            label5.Name = "label5";
            label5.Size = new Size(155, 20);
            label5.TabIndex = 29;
            label5.Text = "Camas Matrimoniales:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(175, 199);
            label3.Name = "label3";
            label3.Size = new Size(139, 20);
            label3.TabIndex = 27;
            label3.Text = "Camas Individuales:";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(238, 150);
            label2.Name = "label2";
            label2.Size = new Size(130, 20);
            label2.TabIndex = 26;
            label2.Text = "Monto por Noche:";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(302, 107);
            label1.Name = "label1";
            label1.Size = new Size(66, 20);
            label1.TabIndex = 25;
            label1.Text = "Número:";
            // 
            // btCancelarAgregarHabitacion
            // 
            btCancelarAgregarHabitacion.Anchor = AnchorStyles.None;
            btCancelarAgregarHabitacion.BackColor = SystemColors.Info;
            btCancelarAgregarHabitacion.Location = new Point(575, 363);
            btCancelarAgregarHabitacion.Name = "btCancelarAgregarHabitacion";
            btCancelarAgregarHabitacion.Size = new Size(97, 29);
            btCancelarAgregarHabitacion.TabIndex = 24;
            btCancelarAgregarHabitacion.Text = "Cancelar";
            btCancelarAgregarHabitacion.UseVisualStyleBackColor = false;
            btCancelarAgregarHabitacion.Click += btCancelarAgregarHabitacion_Click;
            // 
            // btAgregarHabitacionBD
            // 
            btAgregarHabitacionBD.Anchor = AnchorStyles.None;
            btAgregarHabitacionBD.BackColor = SystemColors.Info;
            btAgregarHabitacionBD.Location = new Point(127, 363);
            btAgregarHabitacionBD.Name = "btAgregarHabitacionBD";
            btAgregarHabitacionBD.Size = new Size(100, 29);
            btAgregarHabitacionBD.TabIndex = 23;
            btAgregarHabitacionBD.Text = "Agregar";
            btAgregarHabitacionBD.UseVisualStyleBackColor = false;
            btAgregarHabitacionBD.Click += btAgregarHabitacionBD_Click;
            // 
            // nudCamasIndividuales
            // 
            nudCamasIndividuales.Anchor = AnchorStyles.None;
            nudCamasIndividuales.Location = new Point(320, 197);
            nudCamasIndividuales.Name = "nudCamasIndividuales";
            nudCamasIndividuales.Size = new Size(67, 27);
            nudCamasIndividuales.TabIndex = 34;
            nudCamasIndividuales.ValueChanged += nudCamasIndividuales_ValueChanged;
            // 
            // nudCamasMatrimoniales
            // 
            nudCamasMatrimoniales.Anchor = AnchorStyles.None;
            nudCamasMatrimoniales.Location = new Point(554, 197);
            nudCamasMatrimoniales.Name = "nudCamasMatrimoniales";
            nudCamasMatrimoniales.Size = new Size(67, 27);
            nudCamasMatrimoniales.TabIndex = 35;
            nudCamasMatrimoniales.ValueChanged += nudCamasMatrimoniales_ValueChanged;
            // 
            // tbNúmeroHabitación
            // 
            tbNúmeroHabitación.Anchor = AnchorStyles.None;
            tbNúmeroHabitación.Location = new Point(374, 104);
            tbNúmeroHabitación.Name = "tbNúmeroHabitación";
            tbNúmeroHabitación.Size = new Size(67, 27);
            tbNúmeroHabitación.TabIndex = 39;
            tbNúmeroHabitación.TextChanged += tbNúmeroHabitación_TextChanged;
            // 
            // tbMontoPorNoche
            // 
            tbMontoPorNoche.Anchor = AnchorStyles.None;
            tbMontoPorNoche.Location = new Point(374, 147);
            tbMontoPorNoche.Name = "tbMontoPorNoche";
            tbMontoPorNoche.Size = new Size(88, 27);
            tbMontoPorNoche.TabIndex = 40;
            tbMontoPorNoche.TextChanged += tbMontoPorNoche_TextChanged;
            // 
            // cbDisponibilidad
            // 
            cbDisponibilidad.Anchor = AnchorStyles.None;
            cbDisponibilidad.FormattingEnabled = true;
            cbDisponibilidad.Items.AddRange(new object[] { "Disponible", "Ocupado" });
            cbDisponibilidad.Location = new Point(386, 284);
            cbDisponibilidad.Name = "cbDisponibilidad";
            cbDisponibilidad.Size = new Size(112, 28);
            cbDisponibilidad.TabIndex = 41;
            cbDisponibilidad.SelectedIndexChanged += cbDisponibilidad_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(270, 287);
            label6.Name = "label6";
            label6.Size = new Size(110, 20);
            label6.TabIndex = 43;
            label6.Text = "Disponibilidad:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(285, 326);
            label4.Name = "label4";
            label4.Size = new Size(83, 20);
            label4.TabIndex = 44;
            label4.Text = "Capacidad:";
            // 
            // lbCapacidad
            // 
            lbCapacidad.Anchor = AnchorStyles.None;
            lbCapacidad.AutoSize = true;
            lbCapacidad.BackColor = SystemColors.ButtonHighlight;
            lbCapacidad.Location = new Point(374, 326);
            lbCapacidad.Name = "lbCapacidad";
            lbCapacidad.Size = new Size(17, 20);
            lbCapacidad.TabIndex = 45;
            lbCapacidad.Text = "0";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Location = new Point(328, 244);
            label7.Name = "label7";
            label7.Size = new Size(52, 20);
            label7.TabIndex = 46;
            label7.Text = "Baños:";
            // 
            // nudBaños
            // 
            nudBaños.Anchor = AnchorStyles.None;
            nudBaños.Location = new Point(386, 242);
            nudBaños.Name = "nudBaños";
            nudBaños.Size = new Size(67, 27);
            nudBaños.TabIndex = 47;
            nudBaños.ValueChanged += nudBaños_ValueChanged;
            // 
            // AgregarHabitaciones
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(nudBaños);
            Controls.Add(label7);
            Controls.Add(lbCapacidad);
            Controls.Add(label4);
            Controls.Add(label6);
            Controls.Add(cbDisponibilidad);
            Controls.Add(tbMontoPorNoche);
            Controls.Add(tbNúmeroHabitación);
            Controls.Add(nudCamasMatrimoniales);
            Controls.Add(nudCamasIndividuales);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btCancelarAgregarHabitacion);
            Controls.Add(btAgregarHabitacionBD);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "AgregarHabitaciones";
            Text = "AgregarHabitaciones";
            ((System.ComponentModel.ISupportInitialize)nudCamasIndividuales).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudCamasMatrimoniales).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudBaños).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label5;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btCancelarAgregarHabitacion;
        private Button btAgregarHabitacionBD;
        private NumericUpDown nudCamasIndividuales;
        private NumericUpDown nudCamasMatrimoniales;
        private TextBox tbNúmeroHabitación;
        private TextBox tbMontoPorNoche;
        private ComboBox cbDisponibilidad;
        private Label label6;
        private Label label4;
        private Label lbCapacidad;
        private Label label7;
        private NumericUpDown nudBaños;
    }
}