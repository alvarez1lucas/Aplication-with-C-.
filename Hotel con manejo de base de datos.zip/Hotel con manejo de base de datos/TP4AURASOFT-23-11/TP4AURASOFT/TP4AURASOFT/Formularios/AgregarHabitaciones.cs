﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Formularios
{
    public partial class AgregarHabitaciones : Form
    {
        private Habitacion habitacion = new Habitacion();

        public AgregarHabitaciones()
        {
            InitializeComponent();
        }

        private void tbNúmeroHabitación_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(tbNúmeroHabitación.Text, out int numeroHabitacion))
            {
                habitacion.NumeroHabitacion = numeroHabitacion;
            }
        }

        private void tbMontoPorNoche_TextChanged(object sender, EventArgs e)
        {
            if (double.TryParse(tbMontoPorNoche.Text, out double montoPorNoche))
            {
                habitacion.PrecioPorNoche = montoPorNoche;
            }
        }

        private void nudCamasIndividuales_ValueChanged(object sender, EventArgs e)
        {
            habitacion.CamasIndividuales = (int)nudCamasIndividuales.Value;
            int capacidad = (int)nudCamasIndividuales.Value + (int)nudCamasMatrimoniales.Value;
            lbCapacidad.Text = capacidad.ToString();
        }

        private void nudCamasMatrimoniales_ValueChanged(object sender, EventArgs e)
        {
            habitacion.CamasMatrimoniales = (int)nudCamasMatrimoniales.Value;
            int capacidad = (int)nudCamasIndividuales.Value + (int)nudCamasMatrimoniales.Value;
            lbCapacidad.Text = capacidad.ToString();
        }

        private void nudBaños_ValueChanged(object sender, EventArgs e)
        {
            habitacion.Toilets = (int)nudBaños.Value;
        }

        private void cbDisponibilidad_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbDisponibilidad.SelectedItem.ToString() == "Disponible")
            {
                habitacion.Disponibilidad = 0;
            }
            else
            {
                habitacion.Disponibilidad = 1;
            }
        }

        private void btAgregarHabitacionBD_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbNúmeroHabitación.Text) ||
            string.IsNullOrWhiteSpace(tbMontoPorNoche.Text) ||
            nudCamasIndividuales.Value == 0 ||
            nudCamasMatrimoniales.Value == 0 ||
            nudBaños.Value == 0 ||
            cbDisponibilidad.SelectedItem == null)
            {
                MessageBox.Show("Por favor, complete todos los campos antes de agregar la habitación.", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Detener la operación si hay campos vacíos
            }

            try
            {
                // Resto del código para guardar la habitación
                pHabitacion.Save(habitacion);
                MessageBox.Show("Habitación agregada correctamente");
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al agregar habitación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btCancelarAgregarHabitacion_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}