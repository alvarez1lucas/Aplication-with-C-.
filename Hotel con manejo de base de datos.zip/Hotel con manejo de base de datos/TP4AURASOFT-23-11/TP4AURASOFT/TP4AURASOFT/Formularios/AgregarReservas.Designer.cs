﻿namespace TP4AURASOFT.Formularios
{
    partial class AgregarReservas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AgregarReservas));
            clienteBindingSource = new BindingSource(components);
            label2 = new Label();
            cbHabitación = new ComboBox();
            habitacionBindingSource = new BindingSource(components);
            label3 = new Label();
            label4 = new Label();
            dtFechaEntrada = new DateTimePicker();
            dtFechaSalida = new DateTimePicker();
            label5 = new Label();
            btAgregarReservas = new Button();
            btCancelar = new Button();
            label6 = new Label();
            dtFechaReserva = new DateTimePicker();
            cbPersonas = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)clienteBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)habitacionBindingSource).BeginInit();
            SuspendLayout();
            // 
            // clienteBindingSource
            // 
            clienteBindingSource.DataSource = typeof(Entidades.Cliente);
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(228, 142);
            label2.Name = "label2";
            label2.Size = new Size(85, 20);
            label2.TabIndex = 2;
            label2.Text = "Habitación:";
            // 
            // cbHabitación
            // 
            cbHabitación.Anchor = AnchorStyles.None;
            cbHabitación.DataSource = habitacionBindingSource;
            cbHabitación.DisplayMember = "NumeroHabitacion";
            cbHabitación.FormattingEnabled = true;
            cbHabitación.Location = new Point(331, 139);
            cbHabitación.Name = "cbHabitación";
            cbHabitación.Size = new Size(83, 28);
            cbHabitación.TabIndex = 3;
            cbHabitación.SelectedIndexChanged += cbHabitación_SelectedIndexChanged;
            cbHabitación.Click += cbHabitación_Click;
            // 
            // habitacionBindingSource
            // 
            habitacionBindingSource.DataSource = typeof(Entidades.Habitacion);
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(244, 192);
            label3.Name = "label3";
            label3.Size = new Size(69, 20);
            label3.TabIndex = 4;
            label3.Text = "Personas:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(198, 245);
            label4.Name = "label4";
            label4.Size = new Size(105, 20);
            label4.TabIndex = 6;
            label4.Text = "Fecha Entrada:";
            // 
            // dtFechaEntrada
            // 
            dtFechaEntrada.Anchor = AnchorStyles.None;
            dtFechaEntrada.Location = new Point(309, 240);
            dtFechaEntrada.Name = "dtFechaEntrada";
            dtFechaEntrada.Size = new Size(278, 27);
            dtFechaEntrada.TabIndex = 7;
            dtFechaEntrada.ValueChanged += dtFechaEntrada_ValueChanged;
            // 
            // dtFechaSalida
            // 
            dtFechaSalida.Anchor = AnchorStyles.None;
            dtFechaSalida.Location = new Point(309, 289);
            dtFechaSalida.Name = "dtFechaSalida";
            dtFechaSalida.Size = new Size(278, 27);
            dtFechaSalida.TabIndex = 9;
            dtFechaSalida.ValueChanged += dtFechaSalida_ValueChanged;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(208, 294);
            label5.Name = "label5";
            label5.Size = new Size(95, 20);
            label5.TabIndex = 8;
            label5.Text = "Fecha Salida:";
            // 
            // btAgregarReservas
            // 
            btAgregarReservas.Anchor = AnchorStyles.None;
            btAgregarReservas.BackColor = SystemColors.Info;
            btAgregarReservas.Location = new Point(141, 382);
            btAgregarReservas.Name = "btAgregarReservas";
            btAgregarReservas.Size = new Size(108, 35);
            btAgregarReservas.TabIndex = 10;
            btAgregarReservas.Text = "Agregar";
            btAgregarReservas.UseVisualStyleBackColor = false;
            btAgregarReservas.Click += btAgregarReservas_Click;
            // 
            // btCancelar
            // 
            btCancelar.Anchor = AnchorStyles.None;
            btCancelar.BackColor = SystemColors.Info;
            btCancelar.Location = new Point(564, 382);
            btCancelar.Name = "btCancelar";
            btCancelar.Size = new Size(108, 35);
            btCancelar.TabIndex = 11;
            btCancelar.Text = "Cancelar";
            btCancelar.UseVisualStyleBackColor = false;
            btCancelar.Click += btCancelar_Click;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(198, 339);
            label6.Name = "label6";
            label6.Size = new Size(105, 20);
            label6.TabIndex = 12;
            label6.Text = "Fecha Reserva:";
            // 
            // dtFechaReserva
            // 
            dtFechaReserva.Anchor = AnchorStyles.None;
            dtFechaReserva.Location = new Point(309, 339);
            dtFechaReserva.Name = "dtFechaReserva";
            dtFechaReserva.Size = new Size(278, 27);
            dtFechaReserva.TabIndex = 13;
            dtFechaReserva.ValueChanged += dtFechaReserva_ValueChanged;
            // 
            // cbPersonas
            // 
            cbPersonas.Anchor = AnchorStyles.None;
            cbPersonas.FormattingEnabled = true;
            cbPersonas.Location = new Point(331, 189);
            cbPersonas.Name = "cbPersonas";
            cbPersonas.Size = new Size(83, 28);
            cbPersonas.TabIndex = 5;
            cbPersonas.SelectedIndexChanged += cbPersonas_SelectedIndexChanged;
            cbPersonas.Click += cbPersonas_Click;
            // 
            // AgregarReservas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(dtFechaReserva);
            Controls.Add(label6);
            Controls.Add(btCancelar);
            Controls.Add(btAgregarReservas);
            Controls.Add(dtFechaSalida);
            Controls.Add(label5);
            Controls.Add(dtFechaEntrada);
            Controls.Add(label4);
            Controls.Add(cbPersonas);
            Controls.Add(label3);
            Controls.Add(cbHabitación);
            Controls.Add(label2);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "AgregarReservas";
            Text = "AgregarReservas";
            ((System.ComponentModel.ISupportInitialize)clienteBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)habitacionBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private ComboBox cbHabitación;
        private Label label3;
        private Label label4;
        private DateTimePicker dtFechaEntrada;
        private DateTimePicker dtFechaSalida;
        private Label label5;
        private Button btAgregarReservas;
        private Button btCancelar;
        private Label label6;
        private DateTimePicker dtFechaReserva;
        private BindingSource clienteBindingSource;
        private BindingSource habitacionBindingSource;
        private ComboBox cbPersonas;
    }
}