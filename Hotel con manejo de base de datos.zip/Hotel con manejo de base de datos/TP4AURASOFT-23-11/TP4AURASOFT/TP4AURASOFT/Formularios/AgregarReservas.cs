﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Formularios
{
    public partial class AgregarReservas : Form
    {
        Reserva reserva = new Reserva();
        public AgregarReservas()
        {
            InitializeComponent();
        }

        private void cbHabitación_Click(object sender, EventArgs e)
        {
            habitacionBindingSource.DataSource = pHabitacion.getAllDisponibles(); // Todas las habitaciones que en la base de datos tengan disponiblidad = 0
        }
        private void cbHabitación_SelectedIndexChanged(object sender, EventArgs e)//SELECCIONAR HABITACIÓN
        {
            reserva.Habitacion = (Habitacion)cbHabitación.SelectedItem;
        }

        private void cbPersonas_Click(object sender, EventArgs e)
        {
            // Calcular la cantidad de personas que pueden entrar en la habitacion elegida
            if (reserva.Habitacion != null)
            {
                List<int> capacidad = new List<int>();
                int maxCapacidad = (reserva.Habitacion.CamasIndividuales + (reserva.Habitacion.CamasMatrimoniales * 2));
                for (int i = 0; i < maxCapacidad; i++)
                {
                    capacidad.Add(i + 1);
                }

                cbPersonas.DataSource = capacidad;
            }


        }
        private void cbPersonas_SelectedIndexChanged(object sender, EventArgs e)//ELEGIR LA CAPACIDAD DE PERSONAS QUE TIENE LA HABITACIÓN
        {
            reserva.CantidadDePersonas = (int)cbPersonas.SelectedItem;
        }

        private void dtFechaEntrada_ValueChanged(object sender, EventArgs e)
        {
            reserva.FechaEntrada = dtFechaEntrada.Value.ToString("yyyy-MM-dd");
        }

        private void dtFechaSalida_ValueChanged(object sender, EventArgs e)
        {
            reserva.FechaSalida = dtFechaSalida.Value.ToString("yyyy-MM-dd");
        }

        private void dtFechaReserva_ValueChanged(object sender, EventArgs e)
        {
            reserva.FechaReserva = dtFechaReserva.Value.ToString("yyyy-MM-dd");
        }


        private void btAgregarReservas_Click(object sender, EventArgs e)
        {
            if (cbHabitación.SelectedItem != null
                && cbPersonas.SelectedItem != null
                && reserva.FechaReserva != null
                && reserva.FechaEntrada != null
                && reserva.FechaSalida != null)
            {
                pReserva.Save(reserva);
                MessageBox.Show("Reserva agregada correctamente");
                Close();
            }
            else
            {
                MessageBox.Show("Por favor, complete todos los campos antes de agregar la habitación", "Campos Vacíos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Detener la operación si hay campos vacíos
            }
        }


        private void btCancelar_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }

    }
}
