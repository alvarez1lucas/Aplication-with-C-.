﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP4AURASOFT.Formularios
{
    public partial class Cliente : Form
    {
       

        public Cliente()
        {
            InitializeComponent();
        }

        private void Cliente_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
        }

        private void dtClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)//MOSTRAR LOS CLIENTES CON SUS CELDAS RESPECTIVAS
        {

        }
    }
}
