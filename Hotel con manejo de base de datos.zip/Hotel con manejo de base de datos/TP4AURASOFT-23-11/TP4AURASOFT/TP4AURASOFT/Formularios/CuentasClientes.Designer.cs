﻿namespace TP4AURASOFT.Formularios
{
    partial class CuentasClientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CuentasClientes));
            tbBuscarCuentaCliente = new TextBox();
            label1 = new Label();
            dtCuentaClientes = new DataGridView();
            cuentaClienteBindingSource = new BindingSource(components);
            idCuentaClienteDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            saldoDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            clienteDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dtCuentaClientes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)cuentaClienteBindingSource).BeginInit();
            SuspendLayout();
            // 
            // tbBuscarCuentaCliente
            // 
            tbBuscarCuentaCliente.Anchor = AnchorStyles.None;
            tbBuscarCuentaCliente.Location = new Point(364, 88);
            tbBuscarCuentaCliente.Name = "tbBuscarCuentaCliente";
            tbBuscarCuentaCliente.Size = new Size(297, 27);
            tbBuscarCuentaCliente.TabIndex = 14;
            tbBuscarCuentaCliente.TextChanged += tbBuscarCuentaCliente_TextChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(130, 91);
            label1.Name = "label1";
            label1.Size = new Size(219, 20);
            label1.TabIndex = 13;
            label1.Text = "Ingrese Cuenta Cliente a Buscar:";
            // 
            // dtCuentaClientes
            // 
            dtCuentaClientes.Anchor = AnchorStyles.None;
            dtCuentaClientes.AutoGenerateColumns = false;
            dtCuentaClientes.BackgroundColor = SystemColors.ButtonHighlight;
            dtCuentaClientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtCuentaClientes.Columns.AddRange(new DataGridViewColumn[] { idCuentaClienteDataGridViewTextBoxColumn, saldoDataGridViewTextBoxColumn, clienteDataGridViewTextBoxColumn });
            dtCuentaClientes.DataSource = cuentaClienteBindingSource;
            dtCuentaClientes.Location = new Point(113, 135);
            dtCuentaClientes.Name = "dtCuentaClientes";
            dtCuentaClientes.RowHeadersWidth = 51;
            dtCuentaClientes.RowTemplate.Height = 29;
            dtCuentaClientes.Size = new Size(578, 288);
            dtCuentaClientes.TabIndex = 12;
            dtCuentaClientes.CellContentClick += dtCuentaClientes_CellContentClick;
            // 
            // cuentaClienteBindingSource
            // 
            cuentaClienteBindingSource.DataSource = typeof(Entidades.CuentaCliente);
            // 
            // idCuentaClienteDataGridViewTextBoxColumn
            // 
            idCuentaClienteDataGridViewTextBoxColumn.DataPropertyName = "IdCuentaCliente";
            idCuentaClienteDataGridViewTextBoxColumn.HeaderText = "IdCuentaCliente";
            idCuentaClienteDataGridViewTextBoxColumn.MinimumWidth = 6;
            idCuentaClienteDataGridViewTextBoxColumn.Name = "idCuentaClienteDataGridViewTextBoxColumn";
            idCuentaClienteDataGridViewTextBoxColumn.Width = 125;
            // 
            // saldoDataGridViewTextBoxColumn
            // 
            saldoDataGridViewTextBoxColumn.DataPropertyName = "Saldo";
            saldoDataGridViewTextBoxColumn.HeaderText = "Saldo";
            saldoDataGridViewTextBoxColumn.MinimumWidth = 6;
            saldoDataGridViewTextBoxColumn.Name = "saldoDataGridViewTextBoxColumn";
            saldoDataGridViewTextBoxColumn.Width = 125;
            // 
            // clienteDataGridViewTextBoxColumn
            // 
            clienteDataGridViewTextBoxColumn.DataPropertyName = "Cliente";
            clienteDataGridViewTextBoxColumn.HeaderText = "Cliente";
            clienteDataGridViewTextBoxColumn.MinimumWidth = 6;
            clienteDataGridViewTextBoxColumn.Name = "clienteDataGridViewTextBoxColumn";
            clienteDataGridViewTextBoxColumn.Width = 125;
            // 
            // CuentasClientes
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(tbBuscarCuentaCliente);
            Controls.Add(label1);
            Controls.Add(dtCuentaClientes);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "CuentasClientes";
            Text = "CuentasClientes";
            ((System.ComponentModel.ISupportInitialize)dtCuentaClientes).EndInit();
            ((System.ComponentModel.ISupportInitialize)cuentaClienteBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tbBuscarCuentaCliente;
        private Label label1;
        private DataGridView dtCuentaClientes;
        private DataGridViewTextBoxColumn idCuentaClienteDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn saldoDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn clienteDataGridViewTextBoxColumn;
        private BindingSource cuentaClienteBindingSource;
    }
}