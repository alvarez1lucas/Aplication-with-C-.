﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP4AURASOFT.Formularios
{
    public partial class CuentasClientes : Form
    {
        public CuentasClientes()
        {
            InitializeComponent();
        }

        private void tbBuscarCuentaCliente_TextChanged(object sender, EventArgs e)//BUSCAR CUENTA CLIENTES
        {

        }

        private void dtCuentaClientes_CellContentClick(object sender, DataGridViewCellEventArgs e)//MOSTRAR TABLAS DE CUENTAS CLIENTES
        {

        }
    }
}
