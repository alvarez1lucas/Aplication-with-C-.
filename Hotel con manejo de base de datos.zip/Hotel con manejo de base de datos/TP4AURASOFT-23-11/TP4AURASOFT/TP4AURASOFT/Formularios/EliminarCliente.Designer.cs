﻿namespace TP4AURASOFT.Formularios
{
    partial class EliminarCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EliminarCliente));
            label1 = new Label();
            cbClienteEliminar = new ComboBox();
            btELiminarClienteBD = new Button();
            btCancelarAgregarCliente = new Button();
            clienteBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)clienteBindingSource).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Font = new Font("Goudy Old Style", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(231, 166);
            label1.Name = "label1";
            label1.Size = new Size(345, 34);
            label1.TabIndex = 12;
            label1.Text = "Ingrese Cliente a Eliminar:";
            // 
            // cbClienteEliminar
            // 
            cbClienteEliminar.Anchor = AnchorStyles.None;
            cbClienteEliminar.DataSource = clienteBindingSource;
            cbClienteEliminar.FormattingEnabled = true;
            cbClienteEliminar.Location = new Point(264, 225);
            cbClienteEliminar.Name = "cbClienteEliminar";
            cbClienteEliminar.Size = new Size(287, 28);
            cbClienteEliminar.TabIndex = 13;
            cbClienteEliminar.SelectedIndexChanged += cbClienteEliminar_SelectedIndexChanged;
            // 
            // btELiminarClienteBD
            // 
            btELiminarClienteBD.Anchor = AnchorStyles.None;
            btELiminarClienteBD.BackColor = SystemColors.Info;
            btELiminarClienteBD.Location = new Point(187, 348);
            btELiminarClienteBD.Name = "btELiminarClienteBD";
            btELiminarClienteBD.Size = new Size(100, 29);
            btELiminarClienteBD.TabIndex = 24;
            btELiminarClienteBD.Text = "Eliminar";
            btELiminarClienteBD.UseVisualStyleBackColor = false;
            btELiminarClienteBD.Click += btELiminarClienteBD_Click;
            // 
            // btCancelarAgregarCliente
            // 
            btCancelarAgregarCliente.Anchor = AnchorStyles.None;
            btCancelarAgregarCliente.BackColor = SystemColors.Info;
            btCancelarAgregarCliente.Location = new Point(524, 348);
            btCancelarAgregarCliente.Name = "btCancelarAgregarCliente";
            btCancelarAgregarCliente.Size = new Size(97, 29);
            btCancelarAgregarCliente.TabIndex = 25;
            btCancelarAgregarCliente.Text = "Cancelar";
            btCancelarAgregarCliente.UseVisualStyleBackColor = false;
            btCancelarAgregarCliente.Click += btCancelarAgregarCliente_Click;
            // 
            // clienteBindingSource
            // 
            clienteBindingSource.DataSource = typeof(Entidades.Cliente);
            // 
            // EliminarCliente
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(btCancelarAgregarCliente);
            Controls.Add(btELiminarClienteBD);
            Controls.Add(cbClienteEliminar);
            Controls.Add(label1);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "EliminarCliente";
            Text = "EliminarCliente";
            Load += EliminarCliente_Load;
            ((System.ComponentModel.ISupportInitialize)clienteBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private ComboBox cbClienteEliminar;
        private Button btELiminarClienteBD;
        private Button btCancelarAgregarCliente;
        private BindingSource clienteBindingSource;
    }
}