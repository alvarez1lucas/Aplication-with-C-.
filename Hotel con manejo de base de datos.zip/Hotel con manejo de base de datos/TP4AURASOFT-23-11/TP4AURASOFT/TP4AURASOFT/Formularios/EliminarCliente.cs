﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP4AURASOFT.Controladores;

namespace TP4AURASOFT.Formularios
{
    public partial class EliminarCliente : Form
    {
        Entidades.Cliente cliente = new Entidades.Cliente();
        public EliminarCliente()
        {
            InitializeComponent();
            CargarCB();
        }

        private void CargarCB()
        {
            clienteBindingSource.DataSource = pCliente.getAll();
            cbClienteEliminar.DisplayMember = "ToString()";
        }
        private void EliminarCliente_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
        }

       

        private void cbClienteEliminar_SelectedIndexChanged(object sender, EventArgs e)//SELECCIONAR CLIENTE MEDIANTE ID
        {
                cliente = (Entidades.Cliente)cbClienteEliminar.SelectedItem;
        }

        private void btELiminarClienteBD_Click(object sender, EventArgs e)//ELIMINAR DATOS DEL CLIENTE EN LA BD
        {
            pCliente.Delete(cliente);
            MessageBox.Show("Cliente eliminado");
            Close();
        }

        private void btCancelarAgregarCliente_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }
    }
}
