﻿namespace TP4AURASOFT.Formularios
{
    partial class EliminarEstadia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EliminarEstadia));
            btCancelarEstadia = new Button();
            btELiminarEstadiaBD = new Button();
            cbEstadíaEliminar = new ComboBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btCancelarEstadia
            // 
            btCancelarEstadia.Anchor = AnchorStyles.None;
            btCancelarEstadia.BackColor = SystemColors.Info;
            btCancelarEstadia.Location = new Point(523, 316);
            btCancelarEstadia.Name = "btCancelarEstadia";
            btCancelarEstadia.Size = new Size(97, 29);
            btCancelarEstadia.TabIndex = 33;
            btCancelarEstadia.Text = "Cancelar";
            btCancelarEstadia.UseVisualStyleBackColor = false;
            btCancelarEstadia.Click += btCancelarEstadia_Click;
            // 
            // btELiminarEstadiaBD
            // 
            btELiminarEstadiaBD.Anchor = AnchorStyles.None;
            btELiminarEstadiaBD.BackColor = SystemColors.Info;
            btELiminarEstadiaBD.Location = new Point(186, 316);
            btELiminarEstadiaBD.Name = "btELiminarEstadiaBD";
            btELiminarEstadiaBD.Size = new Size(100, 29);
            btELiminarEstadiaBD.TabIndex = 32;
            btELiminarEstadiaBD.Text = "Eliminar";
            btELiminarEstadiaBD.UseVisualStyleBackColor = false;
            btELiminarEstadiaBD.Click += btELiminarEstadiaBD_Click;
            // 
            // cbEstadíaEliminar
            // 
            cbEstadíaEliminar.Anchor = AnchorStyles.None;
            cbEstadíaEliminar.FormattingEnabled = true;
            cbEstadíaEliminar.Location = new Point(261, 218);
            cbEstadíaEliminar.Name = "cbEstadíaEliminar";
            cbEstadíaEliminar.Size = new Size(287, 28);
            cbEstadíaEliminar.TabIndex = 31;
            cbEstadíaEliminar.SelectedIndexChanged += cbEstadíaEliminar_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Font = new Font("Goudy Old Style", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(227, 163);
            label1.Name = "label1";
            label1.Size = new Size(344, 34);
            label1.TabIndex = 30;
            label1.Text = "Ingrese Estadía a Eliminar:";
            // 
            // EliminarEstadia
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(btCancelarEstadia);
            Controls.Add(btELiminarEstadiaBD);
            Controls.Add(cbEstadíaEliminar);
            Controls.Add(label1);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "EliminarEstadia";
            Text = "EliminarEstadia";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btCancelarEstadia;
        private Button btELiminarEstadiaBD;
        private ComboBox cbEstadíaEliminar;
        private Label label1;
    }
}