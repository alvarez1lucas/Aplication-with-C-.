﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP4AURASOFT.Formularios
{
    public partial class EliminarEstadia : Form
    {
        public EliminarEstadia()
        {
            InitializeComponent();
        }

        private void cbEstadíaEliminar_SelectedIndexChanged(object sender, EventArgs e)//SELECCIONAR ID ESTADIA A ELIMINAR
        {

        }

        private void btELiminarEstadiaBD_Click(object sender, EventArgs e)//ELIMINAR ESTADIA DE LA BD
        {

        }

        private void btCancelarEstadia_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }
    }
}
