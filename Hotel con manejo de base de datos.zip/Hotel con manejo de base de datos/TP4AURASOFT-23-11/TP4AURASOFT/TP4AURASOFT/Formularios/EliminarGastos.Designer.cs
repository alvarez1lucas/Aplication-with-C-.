﻿namespace TP4AURASOFT.Formularios
{
    partial class EliminarGastos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EliminarGastos));
            btCancelarGasto = new Button();
            btELiminarGastoBD = new Button();
            cbGastoEliminar = new ComboBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btCancelarGasto
            // 
            btCancelarGasto.Anchor = AnchorStyles.None;
            btCancelarGasto.BackColor = SystemColors.Info;
            btCancelarGasto.Location = new Point(522, 314);
            btCancelarGasto.Name = "btCancelarGasto";
            btCancelarGasto.Size = new Size(97, 29);
            btCancelarGasto.TabIndex = 33;
            btCancelarGasto.Text = "Cancelar";
            btCancelarGasto.UseVisualStyleBackColor = false;
            btCancelarGasto.Click += btCancelarGasto_Click;
            // 
            // btELiminarGastoBD
            // 
            btELiminarGastoBD.Anchor = AnchorStyles.None;
            btELiminarGastoBD.BackColor = SystemColors.Info;
            btELiminarGastoBD.Location = new Point(185, 314);
            btELiminarGastoBD.Name = "btELiminarGastoBD";
            btELiminarGastoBD.Size = new Size(100, 29);
            btELiminarGastoBD.TabIndex = 32;
            btELiminarGastoBD.Text = "Eliminar";
            btELiminarGastoBD.UseVisualStyleBackColor = false;
            btELiminarGastoBD.Click += btELiminarGastoBD_Click;
            // 
            // cbGastoEliminar
            // 
            cbGastoEliminar.Anchor = AnchorStyles.None;
            cbGastoEliminar.FormattingEnabled = true;
            cbGastoEliminar.Location = new Point(260, 216);
            cbGastoEliminar.Name = "cbGastoEliminar";
            cbGastoEliminar.Size = new Size(287, 28);
            cbGastoEliminar.TabIndex = 31;
            cbGastoEliminar.SelectedIndexChanged += cbGastoEliminar_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Font = new Font("Goudy Old Style", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(235, 162);
            label1.Name = "label1";
            label1.Size = new Size(326, 34);
            label1.TabIndex = 30;
            label1.Text = "Ingrese Gasto a Eliminar:";
            // 
            // EliminarGastos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(btCancelarGasto);
            Controls.Add(btELiminarGastoBD);
            Controls.Add(cbGastoEliminar);
            Controls.Add(label1);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "EliminarGastos";
            Text = "EliminarGastos";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btCancelarGasto;
        private Button btELiminarGastoBD;
        private ComboBox cbGastoEliminar;
        private Label label1;
    }
}