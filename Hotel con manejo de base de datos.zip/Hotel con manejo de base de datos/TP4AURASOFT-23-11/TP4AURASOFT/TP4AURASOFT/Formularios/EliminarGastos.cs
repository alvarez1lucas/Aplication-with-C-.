﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP4AURASOFT.Formularios
{
    public partial class EliminarGastos : Form
    {
        public EliminarGastos()
        {
            InitializeComponent();
        }

        private void cbGastoEliminar_SelectedIndexChanged(object sender, EventArgs e)//ElEGIR ID DE GASTO A ELIMINAR
        {

        }

        private void btELiminarGastoBD_Click(object sender, EventArgs e)//ELIMINAR GASTO DE LA BD
        {

        }

        private void btCancelarGasto_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }
    }
}
