﻿namespace TP4AURASOFT.Formularios
{
    partial class EliminarHabitaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EliminarHabitaciones));
            btCancelarHabitacionCliente = new Button();
            btELiminarHabitaciónBD = new Button();
            cbHabitacionEliminar = new ComboBox();
            label1 = new Label();
            habitacionBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)habitacionBindingSource).BeginInit();
            SuspendLayout();
            // 
            // btCancelarHabitacionCliente
            // 
            btCancelarHabitacionCliente.Anchor = AnchorStyles.None;
            btCancelarHabitacionCliente.BackColor = SystemColors.Info;
            btCancelarHabitacionCliente.Location = new Point(522, 327);
            btCancelarHabitacionCliente.Name = "btCancelarHabitacionCliente";
            btCancelarHabitacionCliente.Size = new Size(97, 29);
            btCancelarHabitacionCliente.TabIndex = 29;
            btCancelarHabitacionCliente.Text = "Cancelar";
            btCancelarHabitacionCliente.UseVisualStyleBackColor = false;
            btCancelarHabitacionCliente.Click += btCancelarHabitacionCliente_Click;
            // 
            // btELiminarHabitaciónBD
            // 
            btELiminarHabitaciónBD.Anchor = AnchorStyles.None;
            btELiminarHabitaciónBD.BackColor = SystemColors.Info;
            btELiminarHabitaciónBD.Location = new Point(185, 327);
            btELiminarHabitaciónBD.Name = "btELiminarHabitaciónBD";
            btELiminarHabitaciónBD.Size = new Size(100, 29);
            btELiminarHabitaciónBD.TabIndex = 28;
            btELiminarHabitaciónBD.Text = "Eliminar";
            btELiminarHabitaciónBD.UseVisualStyleBackColor = false;
            btELiminarHabitaciónBD.Click += btELiminarHabitaciónBD_Click;
            // 
            // cbHabitacionEliminar
            // 
            cbHabitacionEliminar.Anchor = AnchorStyles.None;
            cbHabitacionEliminar.DataSource = habitacionBindingSource;
            cbHabitacionEliminar.FormattingEnabled = true;
            cbHabitacionEliminar.Location = new Point(260, 229);
            cbHabitacionEliminar.Name = "cbHabitacionEliminar";
            cbHabitacionEliminar.Size = new Size(287, 28);
            cbHabitacionEliminar.TabIndex = 27;
            cbHabitacionEliminar.SelectedIndexChanged += cbHabitacionEliminar_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Font = new Font("Goudy Old Style", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(201, 174);
            label1.Name = "label1";
            label1.Size = new Size(391, 34);
            label1.TabIndex = 26;
            label1.Text = "Ingrese Habitación a Eliminar:";
            // 
            // habitacionBindingSource
            // 
            habitacionBindingSource.DataSource = typeof(Entidades.Habitacion);
            // 
            // EliminarHabitaciones
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(btCancelarHabitacionCliente);
            Controls.Add(btELiminarHabitaciónBD);
            Controls.Add(cbHabitacionEliminar);
            Controls.Add(label1);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "EliminarHabitaciones";
            Text = "EliminarHabitaciones";
            ((System.ComponentModel.ISupportInitialize)habitacionBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btCancelarHabitacionCliente;
        private Button btELiminarHabitaciónBD;
        private ComboBox cbHabitacionEliminar;
        private Label label1;
        private BindingSource habitacionBindingSource;
    }
}