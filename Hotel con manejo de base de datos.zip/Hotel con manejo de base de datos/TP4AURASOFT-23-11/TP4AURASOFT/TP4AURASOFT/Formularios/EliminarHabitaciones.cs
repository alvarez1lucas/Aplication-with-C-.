﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Formularios
{
    public partial class EliminarHabitaciones : Form
    {
        Habitacion h = new Habitacion();
        public EliminarHabitaciones()
        {
            InitializeComponent();
            CargarCB();
        }

        private void CargarCB()
        {
            habitacionBindingSource.DataSource = pHabitacion.getAll();
            cbHabitacionEliminar.DisplayMember = "NumeroHabitacion";
        }

        private void cbHabitacionEliminar_SelectedIndexChanged(object sender, EventArgs e)//SELECCIONAR HABITACIÓN POR NÚMERO HABITACIÓN
        {
            h = (Habitacion)cbHabitacionEliminar.SelectedItem;
        }

        private void btELiminarHabitaciónBD_Click(object sender, EventArgs e)//ELIMINAR LA HABITACIÓN DE LA BD
        {
            pHabitacion.Delete(h);
            MessageBox.Show("Hbitacion eliminada correctamente");
            Close();
        }

        private void btCancelarHabitacionCliente_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }
    }
}
