﻿namespace AURASOFT_DESIGN_TP4.Formularios
{
    partial class EliminarReservas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EliminarReservas));
            btCancelarReserva = new Button();
            btELiminarReservaBD = new Button();
            cbReservaEliminar = new ComboBox();
            label1 = new Label();
            reservaBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)reservaBindingSource).BeginInit();
            SuspendLayout();
            // 
            // btCancelarReserva
            // 
            btCancelarReserva.Anchor = AnchorStyles.None;
            btCancelarReserva.BackColor = SystemColors.Info;
            btCancelarReserva.Location = new Point(523, 321);
            btCancelarReserva.Name = "btCancelarReserva";
            btCancelarReserva.Size = new Size(97, 29);
            btCancelarReserva.TabIndex = 33;
            btCancelarReserva.Text = "Cancelar";
            btCancelarReserva.UseVisualStyleBackColor = false;
            btCancelarReserva.Click += btCancelarReserva_Click;
            // 
            // btELiminarReservaBD
            // 
            btELiminarReservaBD.Anchor = AnchorStyles.None;
            btELiminarReservaBD.BackColor = SystemColors.Info;
            btELiminarReservaBD.Location = new Point(186, 321);
            btELiminarReservaBD.Name = "btELiminarReservaBD";
            btELiminarReservaBD.Size = new Size(100, 29);
            btELiminarReservaBD.TabIndex = 32;
            btELiminarReservaBD.Text = "Eliminar";
            btELiminarReservaBD.UseVisualStyleBackColor = false;
            btELiminarReservaBD.Click += btELiminarReservaBD_Click;
            // 
            // cbReservaEliminar
            // 
            cbReservaEliminar.Anchor = AnchorStyles.None;
            cbReservaEliminar.DataSource = reservaBindingSource;
            cbReservaEliminar.FormattingEnabled = true;
            cbReservaEliminar.Location = new Point(261, 223);
            cbReservaEliminar.Name = "cbReservaEliminar";
            cbReservaEliminar.Size = new Size(287, 28);
            cbReservaEliminar.TabIndex = 31;
            cbReservaEliminar.SelectedIndexChanged += cbReservaEliminar_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Font = new Font("Goudy Old Style", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(202, 168);
            label1.Name = "label1";
            label1.Size = new Size(350, 34);
            label1.TabIndex = 30;
            label1.Text = "Ingrese Reserva a Eliminar:";
            // 
            // reservaBindingSource
            // 
            reservaBindingSource.DataSource = typeof(TP4AURASOFT.Entidades.Reserva);
            // 
            // EliminarReservas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(btCancelarReserva);
            Controls.Add(btELiminarReservaBD);
            Controls.Add(cbReservaEliminar);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "EliminarReservas";
            Text = "EliminarReservas";
            ((System.ComponentModel.ISupportInitialize)reservaBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btCancelarReserva;
        private Button btELiminarReservaBD;
        private ComboBox cbReservaEliminar;
        private Label label1;
        private BindingSource reservaBindingSource;
    }
}