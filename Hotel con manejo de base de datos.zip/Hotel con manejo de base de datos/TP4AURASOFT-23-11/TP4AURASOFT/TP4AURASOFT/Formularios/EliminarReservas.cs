﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;
using TP4AURASOFT.Formularios;

namespace AURASOFT_DESIGN_TP4.Formularios
{
    public partial class EliminarReservas : Form
    {
        Reserva reserva = new Reserva();
        public EliminarReservas()
        {
            InitializeComponent();
            CargarCB();
        }

        private void CargarCB()
        {
            reservaBindingSource.DataSource = pReserva.getAll();
            cbReservaEliminar.DisplayMember = "ToString()";
        }
        private void cbReservaEliminar_SelectedIndexChanged(object sender, EventArgs e) //SELECCIONAR RESERVAS
        {
            reserva = (Reserva)cbReservaEliminar.SelectedItem;
        }

        private void btELiminarReservaBD_Click(object sender, EventArgs e)//ELIMINAR LA RESERVA SELECCIONADA
        {
            pReserva.Delete(reserva);
            MessageBox.Show(" Reserva eliminada");
            Close();
        }

        private void btCancelarReserva_Click(object sender, EventArgs e)//CANCELAR LA RESERVA
        {
            Close();
        }
    }
}
