﻿namespace TP4AURASOFT.Formularios
{
    partial class Estadía
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Estadía));
            dtEstadia = new DataGridView();
            idEstadiaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            cuentaClienteDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            costoTotalDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            reservaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            estadiaBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)dtEstadia).BeginInit();
            ((System.ComponentModel.ISupportInitialize)estadiaBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dtEstadia
            // 
            dtEstadia.Anchor = AnchorStyles.None;
            dtEstadia.AutoGenerateColumns = false;
            dtEstadia.BackgroundColor = SystemColors.ButtonHighlight;
            dtEstadia.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtEstadia.Columns.AddRange(new DataGridViewColumn[] { idEstadiaDataGridViewTextBoxColumn, cuentaClienteDataGridViewTextBoxColumn, costoTotalDataGridViewTextBoxColumn, reservaDataGridViewTextBoxColumn });
            dtEstadia.DataSource = estadiaBindingSource;
            dtEstadia.Location = new Point(112, 78);
            dtEstadia.Name = "dtEstadia";
            dtEstadia.RowHeadersWidth = 51;
            dtEstadia.RowTemplate.Height = 29;
            dtEstadia.Size = new Size(578, 346);
            dtEstadia.TabIndex = 12;
            dtEstadia.CellContentClick += dtEstadia_CellContentClick;
            // 
            // idEstadiaDataGridViewTextBoxColumn
            // 
            idEstadiaDataGridViewTextBoxColumn.DataPropertyName = "IdEstadia";
            idEstadiaDataGridViewTextBoxColumn.HeaderText = "IdEstadia";
            idEstadiaDataGridViewTextBoxColumn.MinimumWidth = 6;
            idEstadiaDataGridViewTextBoxColumn.Name = "idEstadiaDataGridViewTextBoxColumn";
            idEstadiaDataGridViewTextBoxColumn.Width = 125;
            // 
            // cuentaClienteDataGridViewTextBoxColumn
            // 
            cuentaClienteDataGridViewTextBoxColumn.DataPropertyName = "CuentaCliente";
            cuentaClienteDataGridViewTextBoxColumn.HeaderText = "CuentaCliente";
            cuentaClienteDataGridViewTextBoxColumn.MinimumWidth = 6;
            cuentaClienteDataGridViewTextBoxColumn.Name = "cuentaClienteDataGridViewTextBoxColumn";
            cuentaClienteDataGridViewTextBoxColumn.Width = 125;
            // 
            // costoTotalDataGridViewTextBoxColumn
            // 
            costoTotalDataGridViewTextBoxColumn.DataPropertyName = "CostoTotal";
            costoTotalDataGridViewTextBoxColumn.HeaderText = "CostoTotal";
            costoTotalDataGridViewTextBoxColumn.MinimumWidth = 6;
            costoTotalDataGridViewTextBoxColumn.Name = "costoTotalDataGridViewTextBoxColumn";
            costoTotalDataGridViewTextBoxColumn.Width = 125;
            // 
            // reservaDataGridViewTextBoxColumn
            // 
            reservaDataGridViewTextBoxColumn.DataPropertyName = "Reserva";
            reservaDataGridViewTextBoxColumn.HeaderText = "Reserva";
            reservaDataGridViewTextBoxColumn.MinimumWidth = 6;
            reservaDataGridViewTextBoxColumn.Name = "reservaDataGridViewTextBoxColumn";
            reservaDataGridViewTextBoxColumn.Width = 125;
            // 
            // estadiaBindingSource
            // 
            estadiaBindingSource.DataSource = typeof(Entidades.Estadia);
            // 
            // Estadía
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(dtEstadia);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "Estadía";
            Text = "Estadía";
            ((System.ComponentModel.ISupportInitialize)dtEstadia).EndInit();
            ((System.ComponentModel.ISupportInitialize)estadiaBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private DataGridView dtEstadia;
        private DataGridViewTextBoxColumn idEstadiaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn cuentaClienteDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn costoTotalDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn reservaDataGridViewTextBoxColumn;
        private BindingSource estadiaBindingSource;
    }
}