﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP4AURASOFT.Formularios
{
    public partial class Estadía : Form
    {
        public Estadía()
        {
            InitializeComponent();
        }

        

        private void dtEstadia_CellContentClick(object sender, DataGridViewCellEventArgs e)//MOSTRAR DATOS DE ESTADIA
        {

        }
    }
}
