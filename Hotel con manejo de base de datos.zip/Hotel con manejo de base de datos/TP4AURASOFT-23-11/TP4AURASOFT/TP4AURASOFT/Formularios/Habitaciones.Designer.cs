﻿namespace TP4AURASOFT.Formularios
{
    partial class Habitaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Habitaciones));
            dtHabitaciones = new DataGridView();
            idHabitacionDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            numeroHabitacionDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            precioPorNocheDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            camasIndividualesDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            camasMatrimonialesDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            disponibilidadDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            toiletsDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            habitacionBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)dtHabitaciones).BeginInit();
            ((System.ComponentModel.ISupportInitialize)habitacionBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dtHabitaciones
            // 
            dtHabitaciones.Anchor = AnchorStyles.None;
            dtHabitaciones.AutoGenerateColumns = false;
            dtHabitaciones.BackgroundColor = SystemColors.ButtonHighlight;
            dtHabitaciones.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtHabitaciones.Columns.AddRange(new DataGridViewColumn[] { idHabitacionDataGridViewTextBoxColumn, numeroHabitacionDataGridViewTextBoxColumn, precioPorNocheDataGridViewTextBoxColumn, camasIndividualesDataGridViewTextBoxColumn, camasMatrimonialesDataGridViewTextBoxColumn, disponibilidadDataGridViewTextBoxColumn, toiletsDataGridViewTextBoxColumn });
            dtHabitaciones.DataSource = habitacionBindingSource;
            dtHabitaciones.Location = new Point(113, 76);
            dtHabitaciones.Name = "dtHabitaciones";
            dtHabitaciones.RowHeadersWidth = 51;
            dtHabitaciones.RowTemplate.Height = 29;
            dtHabitaciones.Size = new Size(574, 346);
            dtHabitaciones.TabIndex = 0;
            dtHabitaciones.CellContentClick += dtHabitaciones_CellContentClick;
            // 
            // idHabitacionDataGridViewTextBoxColumn
            // 
            idHabitacionDataGridViewTextBoxColumn.DataPropertyName = "IdHabitacion";
            idHabitacionDataGridViewTextBoxColumn.HeaderText = "IdHabitacion";
            idHabitacionDataGridViewTextBoxColumn.MinimumWidth = 6;
            idHabitacionDataGridViewTextBoxColumn.Name = "idHabitacionDataGridViewTextBoxColumn";
            idHabitacionDataGridViewTextBoxColumn.Width = 125;
            // 
            // numeroHabitacionDataGridViewTextBoxColumn
            // 
            numeroHabitacionDataGridViewTextBoxColumn.DataPropertyName = "NumeroHabitacion";
            numeroHabitacionDataGridViewTextBoxColumn.HeaderText = "NumeroHabitacion";
            numeroHabitacionDataGridViewTextBoxColumn.MinimumWidth = 6;
            numeroHabitacionDataGridViewTextBoxColumn.Name = "numeroHabitacionDataGridViewTextBoxColumn";
            numeroHabitacionDataGridViewTextBoxColumn.Width = 125;
            // 
            // precioPorNocheDataGridViewTextBoxColumn
            // 
            precioPorNocheDataGridViewTextBoxColumn.DataPropertyName = "PrecioPorNoche";
            precioPorNocheDataGridViewTextBoxColumn.HeaderText = "PrecioPorNoche";
            precioPorNocheDataGridViewTextBoxColumn.MinimumWidth = 6;
            precioPorNocheDataGridViewTextBoxColumn.Name = "precioPorNocheDataGridViewTextBoxColumn";
            precioPorNocheDataGridViewTextBoxColumn.Width = 125;
            // 
            // camasIndividualesDataGridViewTextBoxColumn
            // 
            camasIndividualesDataGridViewTextBoxColumn.DataPropertyName = "CamasIndividuales";
            camasIndividualesDataGridViewTextBoxColumn.HeaderText = "CamasIndividuales";
            camasIndividualesDataGridViewTextBoxColumn.MinimumWidth = 6;
            camasIndividualesDataGridViewTextBoxColumn.Name = "camasIndividualesDataGridViewTextBoxColumn";
            camasIndividualesDataGridViewTextBoxColumn.Width = 125;
            // 
            // camasMatrimonialesDataGridViewTextBoxColumn
            // 
            camasMatrimonialesDataGridViewTextBoxColumn.DataPropertyName = "CamasMatrimoniales";
            camasMatrimonialesDataGridViewTextBoxColumn.HeaderText = "CamasMatrimoniales";
            camasMatrimonialesDataGridViewTextBoxColumn.MinimumWidth = 6;
            camasMatrimonialesDataGridViewTextBoxColumn.Name = "camasMatrimonialesDataGridViewTextBoxColumn";
            camasMatrimonialesDataGridViewTextBoxColumn.Width = 125;
            // 
            // disponibilidadDataGridViewTextBoxColumn
            // 
            disponibilidadDataGridViewTextBoxColumn.DataPropertyName = "Disponibilidad";
            disponibilidadDataGridViewTextBoxColumn.HeaderText = "Disponibilidad";
            disponibilidadDataGridViewTextBoxColumn.MinimumWidth = 6;
            disponibilidadDataGridViewTextBoxColumn.Name = "disponibilidadDataGridViewTextBoxColumn";
            disponibilidadDataGridViewTextBoxColumn.Width = 125;
            // 
            // toiletsDataGridViewTextBoxColumn
            // 
            toiletsDataGridViewTextBoxColumn.DataPropertyName = "Toilets";
            toiletsDataGridViewTextBoxColumn.HeaderText = "Toilets";
            toiletsDataGridViewTextBoxColumn.MinimumWidth = 6;
            toiletsDataGridViewTextBoxColumn.Name = "toiletsDataGridViewTextBoxColumn";
            toiletsDataGridViewTextBoxColumn.Width = 125;
            // 
            // habitacionBindingSource
            // 
            habitacionBindingSource.DataSource = typeof(Entidades.Habitacion);
            // 
            // Habitaciones
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(dtHabitaciones);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "Habitaciones";
            Text = "Habitaciones";
            ((System.ComponentModel.ISupportInitialize)dtHabitaciones).EndInit();
            ((System.ComponentModel.ISupportInitialize)habitacionBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dtHabitaciones;
        private DataGridViewTextBoxColumn idHabitacionDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn numeroHabitacionDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn precioPorNocheDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn camasIndividualesDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn camasMatrimonialesDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn disponibilidadDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn toiletsDataGridViewTextBoxColumn;
        private BindingSource habitacionBindingSource;
    }
}