﻿namespace TP4AURASOFT.Formularios
{
    partial class ModificarCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificarCliente));
            cbLocalidad = new ComboBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            btCancelarModificarCliente = new Button();
            btModificarClienteBD = new Button();
            tbMail = new TextBox();
            tbTelefono = new TextBox();
            tbNumDocumento = new TextBox();
            tbApellido = new TextBox();
            tbNombre = new TextBox();
            cbDocumentos = new ComboBox();
            label8 = new Label();
            cbClienteModificar = new ComboBox();
            SuspendLayout();
            // 
            // cbLocalidad
            // 
            cbLocalidad.Anchor = AnchorStyles.None;
            cbLocalidad.FormattingEnabled = true;
            cbLocalidad.Location = new Point(305, 360);
            cbLocalidad.Name = "cbLocalidad";
            cbLocalidad.Size = new Size(225, 28);
            cbLocalidad.TabIndex = 32;
            cbLocalidad.SelectedIndexChanged += cbLocalidad_SelectedIndexChanged;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(223, 363);
            label7.Name = "label7";
            label7.Size = new Size(74, 20);
            label7.TabIndex = 31;
            label7.Text = "Localidad";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(249, 317);
            label6.Name = "label6";
            label6.Size = new Size(38, 20);
            label6.TabIndex = 30;
            label6.Text = "Mail";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(232, 272);
            label5.Name = "label5";
            label5.Size = new Size(67, 20);
            label5.TabIndex = 29;
            label5.Text = "Teléfono";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(420, 221);
            label4.Name = "label4";
            label4.Size = new Size(63, 20);
            label4.TabIndex = 28;
            label4.Text = "Número";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(178, 221);
            label3.Name = "label3";
            label3.Size = new Size(121, 20);
            label3.TabIndex = 27;
            label3.Text = "Tipo Documento";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(223, 176);
            label2.Name = "label2";
            label2.Size = new Size(66, 20);
            label2.TabIndex = 26;
            label2.Text = "Apellido";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(223, 131);
            label1.Name = "label1";
            label1.Size = new Size(64, 20);
            label1.TabIndex = 25;
            label1.Text = "Nombre";
            // 
            // btCancelarModificarCliente
            // 
            btCancelarModificarCliente.Anchor = AnchorStyles.None;
            btCancelarModificarCliente.BackColor = SystemColors.Info;
            btCancelarModificarCliente.Location = new Point(579, 409);
            btCancelarModificarCliente.Name = "btCancelarModificarCliente";
            btCancelarModificarCliente.Size = new Size(97, 29);
            btCancelarModificarCliente.TabIndex = 24;
            btCancelarModificarCliente.Text = "Cancelar";
            btCancelarModificarCliente.UseVisualStyleBackColor = false;
            btCancelarModificarCliente.Click += btCancelarModificarCliente_Click;
            // 
            // btModificarClienteBD
            // 
            btModificarClienteBD.Anchor = AnchorStyles.None;
            btModificarClienteBD.BackColor = SystemColors.Info;
            btModificarClienteBD.Location = new Point(140, 409);
            btModificarClienteBD.Name = "btModificarClienteBD";
            btModificarClienteBD.Size = new Size(100, 29);
            btModificarClienteBD.TabIndex = 23;
            btModificarClienteBD.Text = "Modificar";
            btModificarClienteBD.UseVisualStyleBackColor = false;
            btModificarClienteBD.Click += btModificarClienteBD_Click;
            // 
            // tbMail
            // 
            tbMail.Anchor = AnchorStyles.None;
            tbMail.Location = new Point(305, 314);
            tbMail.Name = "tbMail";
            tbMail.Size = new Size(225, 27);
            tbMail.TabIndex = 22;
            tbMail.TextChanged += tbMail_TextChanged;
            // 
            // tbTelefono
            // 
            tbTelefono.Anchor = AnchorStyles.None;
            tbTelefono.Location = new Point(305, 269);
            tbTelefono.Name = "tbTelefono";
            tbTelefono.Size = new Size(225, 27);
            tbTelefono.TabIndex = 21;
            tbTelefono.TextChanged += tbTelefono_TextChanged;
            // 
            // tbNumDocumento
            // 
            tbNumDocumento.Anchor = AnchorStyles.None;
            tbNumDocumento.Location = new Point(489, 218);
            tbNumDocumento.Name = "tbNumDocumento";
            tbNumDocumento.Size = new Size(131, 27);
            tbNumDocumento.TabIndex = 20;
            tbNumDocumento.TextChanged += tbNumDocumento_TextChanged;
            // 
            // tbApellido
            // 
            tbApellido.Anchor = AnchorStyles.None;
            tbApellido.Location = new Point(305, 173);
            tbApellido.Name = "tbApellido";
            tbApellido.Size = new Size(225, 27);
            tbApellido.TabIndex = 19;
            tbApellido.TextChanged += tbApellido_TextChanged;
            // 
            // tbNombre
            // 
            tbNombre.Anchor = AnchorStyles.None;
            tbNombre.Location = new Point(305, 128);
            tbNombre.Name = "tbNombre";
            tbNombre.Size = new Size(225, 27);
            tbNombre.TabIndex = 18;
            tbNombre.TextChanged += tbNombre_TextChanged;
            // 
            // cbDocumentos
            // 
            cbDocumentos.Anchor = AnchorStyles.None;
            cbDocumentos.FormattingEnabled = true;
            cbDocumentos.Location = new Point(305, 217);
            cbDocumentos.Name = "cbDocumentos";
            cbDocumentos.Size = new Size(75, 28);
            cbDocumentos.TabIndex = 17;
            cbDocumentos.SelectedIndexChanged += cbDocumentos_SelectedIndexChanged;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.BackColor = SystemColors.ButtonHighlight;
            label8.Location = new Point(151, 88);
            label8.Name = "label8";
            label8.Size = new Size(190, 20);
            label8.TabIndex = 33;
            label8.Text = "Ingrese Cliente a Modificar:";
            // 
            // cbClienteModificar
            // 
            cbClienteModificar.Anchor = AnchorStyles.None;
            cbClienteModificar.FormattingEnabled = true;
            cbClienteModificar.Location = new Point(357, 85);
            cbClienteModificar.Name = "cbClienteModificar";
            cbClienteModificar.Size = new Size(205, 28);
            cbClienteModificar.TabIndex = 34;
            cbClienteModificar.SelectedIndexChanged += cbClienteModificar_SelectedIndexChanged;
            // 
            // ModificarCliente
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(cbClienteModificar);
            Controls.Add(label8);
            Controls.Add(cbLocalidad);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btCancelarModificarCliente);
            Controls.Add(btModificarClienteBD);
            Controls.Add(tbMail);
            Controls.Add(tbTelefono);
            Controls.Add(tbNumDocumento);
            Controls.Add(tbApellido);
            Controls.Add(tbNombre);
            Controls.Add(cbDocumentos);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "ModificarCliente";
            Text = "ModificarCliente";
            Load += ModificarCliente_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cbLocalidad;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btCancelarModificarCliente;
        private Button btModificarClienteBD;
        private TextBox tbMail;
        private TextBox tbTelefono;
        private TextBox tbNumDocumento;
        private TextBox tbApellido;
        private TextBox tbNombre;
        private ComboBox cbDocumentos;
        private Label label8;
        private ComboBox cbClienteModificar;
    }
}