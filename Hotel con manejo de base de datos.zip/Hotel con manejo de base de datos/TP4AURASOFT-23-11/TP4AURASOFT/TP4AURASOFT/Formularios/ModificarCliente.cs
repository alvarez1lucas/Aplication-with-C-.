﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Formularios
{
    public partial class ModificarCliente : Form
    {
        private Cliente clienteSeleccionado;
        public ModificarCliente()
        {
            InitializeComponent();
            CargarClientes();
        }

        private void CargarClientes()
        {
            // Obtener la lista de habitaciones y cargarla en el ComboBox
            List<Entidades.Cliente> clientes = pCliente.getAll();
            cbClienteModificar.DataSource = clientes;
            cbClienteModificar.DisplayMember = "NumeroHabitacion"; // Mostrar el número de habitación
            cbClienteModificar.ValueMember = "IdHabitacion"; // Usar el IdHabitacion como valor
        }
        private void ModificarCliente_Load(object sender, EventArgs e)
        {
            this.ControlBox = false;
        }

        private void cbClienteModificar_SelectedIndexChanged(object sender, EventArgs e)//LISTA DE CLIENTES POR ID
        {
            // Al seleccionar una habitación, cargar la información en los controles
            if (cbClienteModificar.SelectedItem != null && cbClienteModificar.SelectedItem is Habitacion)
            {
               clienteSeleccionado = (Cliente)cbClienteModificar.SelectedItem;
                CargarInformacionCliente();
            }
        }

        private void CargarInformacionCliente()
        {
            //// Cargar la información de la habitación en los controles
            //tbNombre.Text = clienteSeleccionado.No;
            //tbApellido.Text = clienteSeleccionado.Apellido;
            //nudCamasInd.Value = habitacionSeleccionada.CamasIndividuales;
            //nudCamasMat.Value = habitacionSeleccionada.CamasMatrimoniales;
            //// Asignar la disponibilidad según el valor de Disponibilidad (int)
            //cbDisponibilidadHabitación.SelectedItem = habitacionSeleccionada.Disponibilidad == 1 ? "Habilitado" : "Ocupado";
        }

        private void tbNombre_TextChanged(object sender, EventArgs e)//MODIFICAR NOMBRE CLIENTE EN LA BD
        {

        }

        private void tbApellido_TextChanged(object sender, EventArgs e)//MODIFICAR APELLIDO CLIENTE EN LA BD
        {

        }

        private void cbDocumentos_SelectedIndexChanged(object sender, EventArgs e)//MODIFICAR TIPO DE DOCUMENTO EN LA BD
        {

        }

        private void tbNumDocumento_TextChanged(object sender, EventArgs e)//MODIFICAR NÚMERO DOCUMENTO EN LA BD
        {

        }

        private void tbTelefono_TextChanged(object sender, EventArgs e)//MODIFICAR TELEFONO EN LA BD
        {

        }

        private void tbMail_TextChanged(object sender, EventArgs e)//MODIFICAR MAIL EN LA BD
        {

        }

        private void cbLocalidad_SelectedIndexChanged(object sender, EventArgs e)//MODIFICAR LOCALIDAD EN LA BD
        {

        }

        private void btModificarClienteBD_Click(object sender, EventArgs e)//RECIBIR LOS CAMBIOS EN LA BD
        {

        }

        private void btCancelarModificarCliente_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }
    }
}
