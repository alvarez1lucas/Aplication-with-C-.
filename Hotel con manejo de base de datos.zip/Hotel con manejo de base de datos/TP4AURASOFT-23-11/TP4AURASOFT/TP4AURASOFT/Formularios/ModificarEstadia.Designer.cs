﻿namespace TP4AURASOFT.Formularios
{
    partial class ModificarEstadia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificarEstadia));
            btCancelar = new Button();
            btModificar = new Button();
            tbMontoEstadia = new TextBox();
            label6 = new Label();
            cbCuentaCliente = new ComboBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btCancelar
            // 
            btCancelar.Anchor = AnchorStyles.None;
            btCancelar.BackColor = SystemColors.Info;
            btCancelar.Location = new Point(569, 360);
            btCancelar.Name = "btCancelar";
            btCancelar.Size = new Size(97, 29);
            btCancelar.TabIndex = 24;
            btCancelar.Text = "Cancelar";
            btCancelar.UseVisualStyleBackColor = false;
            btCancelar.Click += btCancelar_Click;
            // 
            // btModificar
            // 
            btModificar.Anchor = AnchorStyles.None;
            btModificar.BackColor = SystemColors.Info;
            btModificar.Location = new Point(136, 360);
            btModificar.Name = "btModificar";
            btModificar.Size = new Size(100, 29);
            btModificar.TabIndex = 23;
            btModificar.Text = "Modificar";
            btModificar.UseVisualStyleBackColor = false;
            btModificar.Click += btModificar_Click;
            // 
            // tbMontoEstadia
            // 
            tbMontoEstadia.Anchor = AnchorStyles.None;
            tbMontoEstadia.Location = new Point(386, 242);
            tbMontoEstadia.Name = "tbMontoEstadia";
            tbMontoEstadia.Size = new Size(151, 27);
            tbMontoEstadia.TabIndex = 28;
            tbMontoEstadia.TextChanged += tbMontoEstadia_TextChanged;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(263, 242);
            label6.Name = "label6";
            label6.Size = new Size(111, 20);
            label6.TabIndex = 27;
            label6.Text = "Monto a pagar:";
            // 
            // cbCuentaCliente
            // 
            cbCuentaCliente.Anchor = AnchorStyles.None;
            cbCuentaCliente.FormattingEnabled = true;
            cbCuentaCliente.Location = new Point(386, 182);
            cbCuentaCliente.Name = "cbCuentaCliente";
            cbCuentaCliente.Size = new Size(151, 28);
            cbCuentaCliente.TabIndex = 26;
            cbCuentaCliente.SelectedIndexChanged += cbCuentaCliente_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(263, 185);
            label1.Name = "label1";
            label1.Size = new Size(108, 20);
            label1.TabIndex = 25;
            label1.Text = "Cuenta Cliente:";
            // 
            // ModificarEstadia
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(tbMontoEstadia);
            Controls.Add(label6);
            Controls.Add(cbCuentaCliente);
            Controls.Add(label1);
            Controls.Add(btCancelar);
            Controls.Add(btModificar);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "ModificarEstadia";
            Text = "ModificarEstadia";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btCancelar;
        private Button btModificar;
        private TextBox tbMontoEstadia;
        private Label label6;
        private ComboBox cbCuentaCliente;
        private Label label1;
    }
}