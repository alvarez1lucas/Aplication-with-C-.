﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP4AURASOFT.Formularios
{
    public partial class ModificarEstadia : Form
    {
        public ModificarEstadia()
        {
            InitializeComponent();
        }

        private void cbCuentaCliente_SelectedIndexChanged(object sender, EventArgs e)//ELEGIR CUENTA CLIENTE A MODIFICAR
        {

        }

        private void tbMontoEstadia_TextChanged(object sender, EventArgs e)//MODIFICAR EL MONTO DE LA ESTADIA
        {

        }

        private void btModificar_Click(object sender, EventArgs e)//AGREGAR LA MODIFICACIÓN A LA BD
        {

        }

        private void btCancelar_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }
    }
}
