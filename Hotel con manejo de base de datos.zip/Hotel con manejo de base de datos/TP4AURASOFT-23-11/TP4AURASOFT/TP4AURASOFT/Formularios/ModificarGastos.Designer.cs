﻿namespace TP4AURASOFT.Formularios
{
    partial class ModificarGastos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificarGastos));
            btCancelar = new Button();
            btModificar = new Button();
            dtFechaGasto = new DateTimePicker();
            label4 = new Label();
            tbMontoAPagar = new TextBox();
            label3 = new Label();
            cbCliente = new ComboBox();
            label2 = new Label();
            cbTipoGastos = new ComboBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btCancelar
            // 
            btCancelar.Anchor = AnchorStyles.None;
            btCancelar.BackColor = SystemColors.Info;
            btCancelar.Location = new Point(568, 348);
            btCancelar.Name = "btCancelar";
            btCancelar.Size = new Size(106, 35);
            btCancelar.TabIndex = 19;
            btCancelar.Text = "Cancelar";
            btCancelar.UseVisualStyleBackColor = false;
            btCancelar.Click += btCancelar_Click;
            // 
            // btModificar
            // 
            btModificar.Anchor = AnchorStyles.None;
            btModificar.BackColor = SystemColors.Info;
            btModificar.Location = new Point(121, 348);
            btModificar.Name = "btModificar";
            btModificar.Size = new Size(106, 35);
            btModificar.TabIndex = 18;
            btModificar.Text = "Modificar";
            btModificar.UseVisualStyleBackColor = false;
            btModificar.Click += btModificar_Click;
            // 
            // dtFechaGasto
            // 
            dtFechaGasto.Anchor = AnchorStyles.None;
            dtFechaGasto.Location = new Point(321, 290);
            dtFechaGasto.Name = "dtFechaGasto";
            dtFechaGasto.Size = new Size(273, 27);
            dtFechaGasto.TabIndex = 27;
            dtFechaGasto.ValueChanged += dtFechaGasto_ValueChanged;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(188, 295);
            label4.Name = "label4";
            label4.Size = new Size(113, 20);
            label4.TabIndex = 26;
            label4.Text = "Fecha de Gasto:";
            // 
            // tbMontoAPagar
            // 
            tbMontoAPagar.Anchor = AnchorStyles.None;
            tbMontoAPagar.Location = new Point(383, 224);
            tbMontoAPagar.Name = "tbMontoAPagar";
            tbMontoAPagar.Size = new Size(151, 27);
            tbMontoAPagar.TabIndex = 25;
            tbMontoAPagar.TextChanged += tbMontoAPagar_TextChanged;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(248, 227);
            label3.Name = "label3";
            label3.Size = new Size(111, 20);
            label3.TabIndex = 24;
            label3.Text = "Monto a pagar:";
            // 
            // cbCliente
            // 
            cbCliente.Anchor = AnchorStyles.None;
            cbCliente.FormattingEnabled = true;
            cbCliente.Location = new Point(383, 108);
            cbCliente.Name = "cbCliente";
            cbCliente.Size = new Size(151, 28);
            cbCliente.TabIndex = 23;
            cbCliente.SelectedIndexChanged += cbCliente_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(295, 111);
            label2.Name = "label2";
            label2.Size = new Size(58, 20);
            label2.TabIndex = 22;
            label2.Text = "Cliente:";
            // 
            // cbTipoGastos
            // 
            cbTipoGastos.Anchor = AnchorStyles.None;
            cbTipoGastos.FormattingEnabled = true;
            cbTipoGastos.Location = new Point(383, 163);
            cbTipoGastos.Name = "cbTipoGastos";
            cbTipoGastos.Size = new Size(151, 28);
            cbTipoGastos.TabIndex = 21;
            cbTipoGastos.SelectedIndexChanged += cbTipoGastos_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(254, 166);
            label1.Name = "label1";
            label1.Size = new Size(105, 20);
            label1.TabIndex = 20;
            label1.Text = "Tipo de Gasto:";
            // 
            // ModificarGastos
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(dtFechaGasto);
            Controls.Add(label4);
            Controls.Add(tbMontoAPagar);
            Controls.Add(label3);
            Controls.Add(cbCliente);
            Controls.Add(label2);
            Controls.Add(cbTipoGastos);
            Controls.Add(label1);
            Controls.Add(btCancelar);
            Controls.Add(btModificar);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "ModificarGastos";
            Text = "ModificarGastos";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btCancelar;
        private Button btModificar;
        private DateTimePicker dtFechaGasto;
        private Label label4;
        private TextBox tbMontoAPagar;
        private Label label3;
        private ComboBox cbCliente;
        private Label label2;
        private ComboBox cbTipoGastos;
        private Label label1;
    }
}