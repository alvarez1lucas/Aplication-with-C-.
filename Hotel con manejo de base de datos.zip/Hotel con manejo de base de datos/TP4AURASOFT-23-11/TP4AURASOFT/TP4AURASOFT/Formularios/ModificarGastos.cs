﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP4AURASOFT.Formularios
{
    public partial class ModificarGastos : Form
    {
        public ModificarGastos()
        {
            InitializeComponent();
        }

        private void btCancelar_Click(object sender, EventArgs e)//VOLVER AL INICIO
        {
            Close();
        }

        private void cbCliente_SelectedIndexChanged(object sender, EventArgs e)//SELECCIONAR NUEVO CLIENTE
        {

        }

        private void cbTipoGastos_SelectedIndexChanged(object sender, EventArgs e)//SELECCIONAR NUEVO TIPO DE GASTO
        {

        }

        private void tbMontoAPagar_TextChanged(object sender, EventArgs e)//INSERTAR NUEVO COSTO DE GASTO
        {

        }

        private void dtFechaGasto_ValueChanged(object sender, EventArgs e)//SELECCIONAR NUEVA FECHA DE GASTO
        {

        }

        private void btModificar_Click(object sender, EventArgs e)//MODIFICAR GASTO EN LA BD
        {

        }
    }
}
