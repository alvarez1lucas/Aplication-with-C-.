﻿namespace TP4AURASOFT.Formularios
{
    partial class ModificarHabitaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificarHabitaciones));
            btCancelarModificarHabitacion = new Button();
            btModificarHabitacionBD = new Button();
            label6 = new Label();
            cbDisponibilidadHabitación = new ComboBox();
            tbMontoNocheHabitación = new TextBox();
            tbNumeroHabitación = new TextBox();
            nudCamasMat = new NumericUpDown();
            nudCamasInd = new NumericUpDown();
            label5 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            cbHabitaciónModificar = new ComboBox();
            label8 = new Label();
            ((System.ComponentModel.ISupportInitialize)nudCamasMat).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudCamasInd).BeginInit();
            SuspendLayout();
            // 
            // btCancelarModificarHabitacion
            // 
            btCancelarModificarHabitacion.Anchor = AnchorStyles.None;
            btCancelarModificarHabitacion.BackColor = SystemColors.Info;
            btCancelarModificarHabitacion.Location = new Point(556, 364);
            btCancelarModificarHabitacion.Name = "btCancelarModificarHabitacion";
            btCancelarModificarHabitacion.Size = new Size(97, 29);
            btCancelarModificarHabitacion.TabIndex = 41;
            btCancelarModificarHabitacion.Text = "Cancelar";
            btCancelarModificarHabitacion.UseVisualStyleBackColor = false;
            btCancelarModificarHabitacion.Click += btCancelarModificarHabitacion_Click;
            // 
            // btModificarHabitacionBD
            // 
            btModificarHabitacionBD.Anchor = AnchorStyles.None;
            btModificarHabitacionBD.BackColor = SystemColors.Info;
            btModificarHabitacionBD.Location = new Point(152, 364);
            btModificarHabitacionBD.Name = "btModificarHabitacionBD";
            btModificarHabitacionBD.Size = new Size(100, 29);
            btModificarHabitacionBD.TabIndex = 40;
            btModificarHabitacionBD.Text = "Modificar";
            btModificarHabitacionBD.UseVisualStyleBackColor = false;
            btModificarHabitacionBD.Click += btModificarHabitacionBD_Click;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(276, 326);
            label6.Name = "label6";
            label6.Size = new Size(110, 20);
            label6.TabIndex = 53;
            label6.Text = "Disponibilidad:";
            // 
            // cbDisponibilidadHabitación
            // 
            cbDisponibilidadHabitación.Anchor = AnchorStyles.None;
            cbDisponibilidadHabitación.FormattingEnabled = true;
            cbDisponibilidadHabitación.Items.AddRange(new object[] { "Habilitado", "Ocupado" });
            cbDisponibilidadHabitación.Location = new Point(392, 323);
            cbDisponibilidadHabitación.Name = "cbDisponibilidadHabitación";
            cbDisponibilidadHabitación.Size = new Size(150, 28);
            cbDisponibilidadHabitación.TabIndex = 52;
            cbDisponibilidadHabitación.SelectedIndexChanged += cbDisponibilidadHabitación_SelectedIndexChanged;
            // 
            // tbMontoNocheHabitación
            // 
            tbMontoNocheHabitación.Anchor = AnchorStyles.None;
            tbMontoNocheHabitación.Location = new Point(392, 187);
            tbMontoNocheHabitación.Name = "tbMontoNocheHabitación";
            tbMontoNocheHabitación.Size = new Size(88, 27);
            tbMontoNocheHabitación.TabIndex = 51;
            tbMontoNocheHabitación.TextChanged += tbMontoNocheHabitación_TextChanged;
            // 
            // tbNumeroHabitación
            // 
            tbNumeroHabitación.Anchor = AnchorStyles.None;
            tbNumeroHabitación.Location = new Point(392, 144);
            tbNumeroHabitación.Name = "tbNumeroHabitación";
            tbNumeroHabitación.Size = new Size(67, 27);
            tbNumeroHabitación.TabIndex = 50;
            tbNumeroHabitación.TextChanged += tbNumeroHabitación_TextChanged;
            // 
            // nudCamasMat
            // 
            nudCamasMat.Anchor = AnchorStyles.None;
            nudCamasMat.Location = new Point(392, 281);
            nudCamasMat.Name = "nudCamasMat";
            nudCamasMat.Size = new Size(67, 27);
            nudCamasMat.TabIndex = 49;
            // 
            // nudCamasInd
            // 
            nudCamasInd.Anchor = AnchorStyles.None;
            nudCamasInd.Location = new Point(392, 232);
            nudCamasInd.Name = "nudCamasInd";
            nudCamasInd.Size = new Size(67, 27);
            nudCamasInd.TabIndex = 48;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(231, 281);
            label5.Name = "label5";
            label5.Size = new Size(155, 20);
            label5.TabIndex = 47;
            label5.Text = "Camas Matrimoniales:";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(247, 234);
            label3.Name = "label3";
            label3.Size = new Size(139, 20);
            label3.TabIndex = 46;
            label3.Text = "Camas Individuales:";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(256, 190);
            label2.Name = "label2";
            label2.Size = new Size(130, 20);
            label2.TabIndex = 45;
            label2.Text = "Monto por Noche:";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(320, 147);
            label1.Name = "label1";
            label1.Size = new Size(66, 20);
            label1.TabIndex = 44;
            label1.Text = "Número:";
            // 
            // cbHabitaciónModificar
            // 
            cbHabitaciónModificar.Anchor = AnchorStyles.None;
            cbHabitaciónModificar.FormattingEnabled = true;
            cbHabitaciónModificar.Location = new Point(392, 100);
            cbHabitaciónModificar.Name = "cbHabitaciónModificar";
            cbHabitaciónModificar.Size = new Size(67, 28);
            cbHabitaciónModificar.TabIndex = 55;
            cbHabitaciónModificar.SelectedIndexChanged += cbHabitaciónModificar_SelectedIndexChanged_1;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.BackColor = SystemColors.ButtonHighlight;
            label8.Location = new Point(169, 103);
            label8.Name = "label8";
            label8.Size = new Size(217, 20);
            label8.TabIndex = 54;
            label8.Text = "Ingrese Habitación a Modificar:";
            label8.Click += label8_Click;
            // 
            // ModificarHabitaciones
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(cbHabitaciónModificar);
            Controls.Add(label8);
            Controls.Add(label6);
            Controls.Add(cbDisponibilidadHabitación);
            Controls.Add(tbMontoNocheHabitación);
            Controls.Add(tbNumeroHabitación);
            Controls.Add(nudCamasMat);
            Controls.Add(nudCamasInd);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btCancelarModificarHabitacion);
            Controls.Add(btModificarHabitacionBD);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "ModificarHabitaciones";
            Text = "ModificarHabitaciones";
            ((System.ComponentModel.ISupportInitialize)nudCamasMat).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudCamasInd).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btCancelarModificarHabitacion;
        private Button btModificarHabitacionBD;
        private Label label6;
        private ComboBox cbDisponibilidadHabitación;
        private TextBox tbMontoNocheHabitación;
        private TextBox tbNumeroHabitación;
        private NumericUpDown nudCamasMat;
        private NumericUpDown nudCamasInd;
        private Label label5;
        private Label label3;
        private Label label2;
        private Label label1;
        private ComboBox cbHabitaciónModificar;
        private Label label8;
    }
}