﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;

namespace TP4AURASOFT.Formularios
{
    public partial class ModificarHabitaciones : Form
    {
        private Habitacion habitacionSeleccionada;

        public ModificarHabitaciones()
        {
            InitializeComponent();
            CargarHabitaciones();
        }

        private void CargarHabitaciones()
        {
            // Obtener la lista de habitaciones y cargarla en el ComboBox
            List<Habitacion> habitaciones = pHabitacion.getAll();
            cbHabitaciónModificar.DataSource = habitaciones;
            cbHabitaciónModificar.DisplayMember = "NumeroHabitacion"; // Mostrar el número de habitación
            cbHabitaciónModificar.ValueMember = "IdHabitacion"; // Usar el IdHabitacion como valor
        }

        private void cbHabitaciónModificar_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Al seleccionar una habitación, cargar la información en los controles
            if (cbHabitaciónModificar.SelectedItem != null && cbHabitaciónModificar.SelectedItem is Habitacion)
            {
                habitacionSeleccionada = (Habitacion)cbHabitaciónModificar.SelectedItem;
                CargarInformacionHabitacion();
            }
        }

        private void CargarInformacionHabitacion()
        {
            // Cargar la información de la habitación en los controles
            tbNumeroHabitación.Text = habitacionSeleccionada.NumeroHabitacion.ToString();
            tbMontoNocheHabitación.Text = habitacionSeleccionada.PrecioPorNoche.ToString();
            nudCamasInd.Value = habitacionSeleccionada.CamasIndividuales;
            nudCamasMat.Value = habitacionSeleccionada.CamasMatrimoniales;
            // Asignar la disponibilidad según el valor de Disponibilidad (int)
            cbDisponibilidadHabitación.SelectedItem = habitacionSeleccionada.Disponibilidad == 1 ? "Habilitado" : "Ocupado";
        }

        private void btModificarHabitacionBD_Click(object sender, EventArgs e)
        {
            try
            {
                // Actualizar la información de la habitación seleccionada
                habitacionSeleccionada.NumeroHabitacion = int.Parse(tbNumeroHabitación.Text);
                habitacionSeleccionada.PrecioPorNoche = double.Parse(tbMontoNocheHabitación.Text);
                habitacionSeleccionada.CamasIndividuales = (int)nudCamasInd.Value;
                habitacionSeleccionada.CamasMatrimoniales = (int)nudCamasMat.Value;

                // Verificar si SelectedItem no es null antes de intentar acceder a su propiedad
                if (cbDisponibilidadHabitación.SelectedItem != null)
                {
                    // Convertir el valor del combo box a entero
                    habitacionSeleccionada.Disponibilidad = cbDisponibilidadHabitación.SelectedItem.ToString() == "Habilitado" ? 1 : 0;
                }

                // Llamar al método de la clase pHabitacion para guardar la modificación
                pHabitacion.Update(habitacionSeleccionada);

                MessageBox.Show("Habitación modificada correctamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al modificar habitación: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void cbDisponibilidadHabitación_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
        private void tbMontoNocheHabitación_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void tbNumeroHabitación_TextChanged(object sender, EventArgs e)
        {
           
        }
        private void label8_Click(object sender, EventArgs e)
        {
            
        }


        private void btCancelarModificarHabitacion_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
