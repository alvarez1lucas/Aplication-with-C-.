﻿namespace TP4AURASOFT.Formularios
{
    partial class ModificarReservas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ModificarReservas));
            btCancelar = new Button();
            btModificar = new Button();
            cbEstadia = new ComboBox();
            label7 = new Label();
            dtFechaReserva = new DateTimePicker();
            label6 = new Label();
            dtFechaSalida = new DateTimePicker();
            label5 = new Label();
            dtFechaEntrada = new DateTimePicker();
            label4 = new Label();
            cbPersonas = new ComboBox();
            label3 = new Label();
            cbHabitación = new ComboBox();
            label2 = new Label();
            cbCliente = new ComboBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // btCancelar
            // 
            btCancelar.Anchor = AnchorStyles.None;
            btCancelar.BackColor = SystemColors.Info;
            btCancelar.Location = new Point(572, 379);
            btCancelar.Name = "btCancelar";
            btCancelar.Size = new Size(108, 35);
            btCancelar.TabIndex = 23;
            btCancelar.Text = "Cancelar";
            btCancelar.UseVisualStyleBackColor = false;
            btCancelar.Click += btCancelar_Click;
            // 
            // btModificar
            // 
            btModificar.Anchor = AnchorStyles.None;
            btModificar.BackColor = SystemColors.Info;
            btModificar.Location = new Point(124, 379);
            btModificar.Name = "btModificar";
            btModificar.Size = new Size(108, 35);
            btModificar.TabIndex = 22;
            btModificar.Text = "Modificar";
            btModificar.UseVisualStyleBackColor = false;
            btModificar.Click += btModificar_Click;
            // 
            // cbEstadia
            // 
            cbEstadia.Anchor = AnchorStyles.None;
            cbEstadia.FormattingEnabled = true;
            cbEstadia.Location = new Point(494, 193);
            cbEstadia.Name = "cbEstadia";
            cbEstadia.Size = new Size(151, 28);
            cbEstadia.TabIndex = 37;
            cbEstadia.SelectedIndexChanged += cbEstadia_SelectedIndexChanged;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.BackColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(428, 196);
            label7.Name = "label7";
            label7.Size = new Size(60, 20);
            label7.TabIndex = 36;
            label7.Text = "Estadía:";
            // 
            // dtFechaReserva
            // 
            dtFechaReserva.Anchor = AnchorStyles.None;
            dtFechaReserva.Location = new Point(315, 343);
            dtFechaReserva.Name = "dtFechaReserva";
            dtFechaReserva.Size = new Size(278, 27);
            dtFechaReserva.TabIndex = 35;
            dtFechaReserva.ValueChanged += dtFechaReserva_ValueChanged;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(204, 343);
            label6.Name = "label6";
            label6.Size = new Size(105, 20);
            label6.TabIndex = 34;
            label6.Text = "Fecha Reserva:";
            // 
            // dtFechaSalida
            // 
            dtFechaSalida.Anchor = AnchorStyles.None;
            dtFechaSalida.Location = new Point(315, 293);
            dtFechaSalida.Name = "dtFechaSalida";
            dtFechaSalida.Size = new Size(278, 27);
            dtFechaSalida.TabIndex = 33;
            dtFechaSalida.ValueChanged += dtFechaSalida_ValueChanged;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(214, 298);
            label5.Name = "label5";
            label5.Size = new Size(95, 20);
            label5.TabIndex = 32;
            label5.Text = "Fecha Salida:";
            // 
            // dtFechaEntrada
            // 
            dtFechaEntrada.Anchor = AnchorStyles.None;
            dtFechaEntrada.Location = new Point(315, 244);
            dtFechaEntrada.Name = "dtFechaEntrada";
            dtFechaEntrada.Size = new Size(278, 27);
            dtFechaEntrada.TabIndex = 31;
            dtFechaEntrada.ValueChanged += dtFechaEntrada_ValueChanged;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.BackColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(204, 249);
            label4.Name = "label4";
            label4.Size = new Size(105, 20);
            label4.TabIndex = 30;
            label4.Text = "Fecha Entrada:";
            // 
            // cbPersonas
            // 
            cbPersonas.Anchor = AnchorStyles.None;
            cbPersonas.FormattingEnabled = true;
            cbPersonas.Location = new Point(337, 193);
            cbPersonas.Name = "cbPersonas";
            cbPersonas.Size = new Size(83, 28);
            cbPersonas.TabIndex = 29;
            cbPersonas.SelectedIndexChanged += cbPersonas_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(250, 196);
            label3.Name = "label3";
            label3.Size = new Size(69, 20);
            label3.TabIndex = 28;
            label3.Text = "Personas:";
            // 
            // cbHabitación
            // 
            cbHabitación.Anchor = AnchorStyles.None;
            cbHabitación.FormattingEnabled = true;
            cbHabitación.Location = new Point(337, 143);
            cbHabitación.Name = "cbHabitación";
            cbHabitación.Size = new Size(83, 28);
            cbHabitación.TabIndex = 27;
            cbHabitación.SelectedIndexChanged += cbHabitación_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.BackColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(234, 146);
            label2.Name = "label2";
            label2.Size = new Size(85, 20);
            label2.TabIndex = 26;
            label2.Text = "Habitación:";
            // 
            // cbCliente
            // 
            cbCliente.Anchor = AnchorStyles.None;
            cbCliente.FormattingEnabled = true;
            cbCliente.Location = new Point(337, 92);
            cbCliente.Name = "cbCliente";
            cbCliente.Size = new Size(151, 28);
            cbCliente.TabIndex = 25;
            cbCliente.SelectedIndexChanged += cbCliente_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(261, 95);
            label1.Name = "label1";
            label1.Size = new Size(58, 20);
            label1.TabIndex = 24;
            label1.Text = "Cliente:";
            // 
            // ModificarReservas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(cbEstadia);
            Controls.Add(label7);
            Controls.Add(dtFechaReserva);
            Controls.Add(label6);
            Controls.Add(dtFechaSalida);
            Controls.Add(label5);
            Controls.Add(dtFechaEntrada);
            Controls.Add(label4);
            Controls.Add(cbPersonas);
            Controls.Add(label3);
            Controls.Add(cbHabitación);
            Controls.Add(label2);
            Controls.Add(cbCliente);
            Controls.Add(label1);
            Controls.Add(btCancelar);
            Controls.Add(btModificar);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "ModificarReservas";
            Text = "ModificarReservas";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btCancelar;
        private Button btModificar;
        private ComboBox cbEstadia;
        private Label label7;
        private DateTimePicker dtFechaReserva;
        private Label label6;
        private DateTimePicker dtFechaSalida;
        private Label label5;
        private DateTimePicker dtFechaEntrada;
        private Label label4;
        private ComboBox cbPersonas;
        private Label label3;
        private ComboBox cbHabitación;
        private Label label2;
        private ComboBox cbCliente;
        private Label label1;
    }
}