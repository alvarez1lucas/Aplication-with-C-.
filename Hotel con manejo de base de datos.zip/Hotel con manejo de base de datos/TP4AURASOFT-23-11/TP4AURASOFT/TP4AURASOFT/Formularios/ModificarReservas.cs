﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP4AURASOFT.Formularios
{
    public partial class ModificarReservas : Form
    {
        public ModificarReservas()
        {
            InitializeComponent();
        }

        private void cbCliente_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbHabitación_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbPersonas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbEstadia_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dtFechaEntrada_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dtFechaSalida_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dtFechaReserva_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btModificar_Click(object sender, EventArgs e)
        {

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
