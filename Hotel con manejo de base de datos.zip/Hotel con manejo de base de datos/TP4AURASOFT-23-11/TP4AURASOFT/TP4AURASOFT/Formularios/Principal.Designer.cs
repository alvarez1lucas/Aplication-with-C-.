﻿namespace AURASOFT_DESIGN_TP4.Formularios
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            panel2 = new Panel();
            label2 = new Label();
            btMenuPanel = new PictureBox();
            panelPrincipal = new FlowLayoutPanel();
            panel1 = new Panel();
            btInicio = new Button();
            panelClientes = new FlowLayoutPanel();
            panel26 = new Panel();
            btClientes = new Button();
            panel27 = new Panel();
            btAgregarClientes = new Button();
            panel28 = new Panel();
            btModificarClientes = new Button();
            panel29 = new Panel();
            panel30 = new Panel();
            panel31 = new Panel();
            btEliminarClientes = new Button();
            panelHabitaciones = new FlowLayoutPanel();
            panel13 = new Panel();
            btHabitaciones = new Button();
            panel14 = new Panel();
            btAgregarHabitaciones = new Button();
            panel15 = new Panel();
            btModificarHabitaciones = new Button();
            panel20 = new Panel();
            panel21 = new Panel();
            panel22 = new Panel();
            btEliminarHabitaciones = new Button();
            panelEstadias = new FlowLayoutPanel();
            panel3 = new Panel();
            btEstadias = new Button();
            panel5 = new Panel();
            btAgregarEstadia = new Button();
            panel6 = new Panel();
            btModificarEstadia = new Button();
            panel32 = new Panel();
            panel33 = new Panel();
            panel34 = new Panel();
            btEliminarEstadia = new Button();
            panelReservas = new FlowLayoutPanel();
            panel4 = new Panel();
            btReservas = new Button();
            panel7 = new Panel();
            btAgregarReserva = new Button();
            panel9 = new Panel();
            btModificarReserva = new Button();
            panel10 = new Panel();
            panel11 = new Panel();
            panel12 = new Panel();
            btEliminarReserva = new Button();
            panelCuentaCliente = new FlowLayoutPanel();
            panel16 = new Panel();
            btCuentaCliente = new Button();
            panel17 = new Panel();
            btAgregarGasto = new Button();
            panel18 = new Panel();
            btModificarGasto = new Button();
            panel19 = new Panel();
            panel24 = new Panel();
            panel25 = new Panel();
            btEliminarGasto = new Button();
            panel23 = new Panel();
            btSalirr = new Button();
            menuTransitionCliente = new System.Windows.Forms.Timer(components);
            menuTransitionHabitacion = new System.Windows.Forms.Timer(components);
            menuTransitionEstadia = new System.Windows.Forms.Timer(components);
            menuTransitionReserva = new System.Windows.Forms.Timer(components);
            menuTransitionCuentaCliente = new System.Windows.Forms.Timer(components);
            panelMenuTransition = new System.Windows.Forms.Timer(components);
            menuTransitionUsuarios = new System.Windows.Forms.Timer(components);
            panelBase = new Panel();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btMenuPanel).BeginInit();
            panelPrincipal.SuspendLayout();
            panel1.SuspendLayout();
            panelClientes.SuspendLayout();
            panel26.SuspendLayout();
            panel27.SuspendLayout();
            panel28.SuspendLayout();
            panel29.SuspendLayout();
            panel30.SuspendLayout();
            panelHabitaciones.SuspendLayout();
            panel13.SuspendLayout();
            panel14.SuspendLayout();
            panel15.SuspendLayout();
            panel20.SuspendLayout();
            panel21.SuspendLayout();
            panelEstadias.SuspendLayout();
            panel3.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel32.SuspendLayout();
            panel33.SuspendLayout();
            panelReservas.SuspendLayout();
            panel4.SuspendLayout();
            panel7.SuspendLayout();
            panel9.SuspendLayout();
            panel10.SuspendLayout();
            panel11.SuspendLayout();
            panelCuentaCliente.SuspendLayout();
            panel16.SuspendLayout();
            panel17.SuspendLayout();
            panel18.SuspendLayout();
            panel19.SuspendLayout();
            panel24.SuspendLayout();
            panel23.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label2);
            panel2.Controls.Add(btMenuPanel);
            panel2.Location = new Point(-2, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1317, 49);
            panel2.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Small", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.SkyBlue;
            label2.Location = new Point(60, 12);
            label2.Name = "label2";
            label2.Size = new Size(355, 29);
            label2.TabIndex = 1;
            label2.Text = "SISTEMA DE GESTIÓN AURASOFT";
            // 
            // btMenuPanel
            // 
            btMenuPanel.Image = (Image)resources.GetObject("btMenuPanel.Image");
            btMenuPanel.Location = new Point(14, 12);
            btMenuPanel.Name = "btMenuPanel";
            btMenuPanel.Size = new Size(31, 32);
            btMenuPanel.TabIndex = 0;
            btMenuPanel.TabStop = false;
            btMenuPanel.Click += btMenuPanel_Click;
            // 
            // panelPrincipal
            // 
            panelPrincipal.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panelPrincipal.BackColor = Color.Beige;
            panelPrincipal.Controls.Add(panel1);
            panelPrincipal.Controls.Add(panelClientes);
            panelPrincipal.Controls.Add(panelHabitaciones);
            panelPrincipal.Controls.Add(panelEstadias);
            panelPrincipal.Controls.Add(panelReservas);
            panelPrincipal.Controls.Add(panelCuentaCliente);
            panelPrincipal.Controls.Add(panel23);
            panelPrincipal.FlowDirection = FlowDirection.TopDown;
            panelPrincipal.Location = new Point(-2, 51);
            panelPrincipal.Name = "panelPrincipal";
            panelPrincipal.Size = new Size(79, 1011);
            panelPrincipal.TabIndex = 2;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Beige;
            panel1.Controls.Add(btInicio);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Padding = new Padding(0, 29, 0, 0);
            panel1.Size = new Size(279, 69);
            panel1.TabIndex = 8;
            // 
            // btInicio
            // 
            btInicio.BackColor = Color.Beige;
            btInicio.Font = new Font("Verdana", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btInicio.Image = (Image)resources.GetObject("btInicio.Image");
            btInicio.ImageAlign = ContentAlignment.MiddleLeft;
            btInicio.Location = new Point(-3, -15);
            btInicio.Name = "btInicio";
            btInicio.Padding = new Padding(25, 0, 0, 0);
            btInicio.Size = new Size(287, 92);
            btInicio.TabIndex = 7;
            btInicio.Text = "              Inicio";
            btInicio.TextAlign = ContentAlignment.MiddleLeft;
            btInicio.UseVisualStyleBackColor = false;
            btInicio.Click += btInicio_Click;
            // 
            // panelClientes
            // 
            panelClientes.BackColor = Color.Beige;
            panelClientes.Controls.Add(panel26);
            panelClientes.Controls.Add(panel27);
            panelClientes.Controls.Add(panel28);
            panelClientes.Controls.Add(panel29);
            panelClientes.Location = new Point(3, 78);
            panelClientes.Name = "panelClientes";
            panelClientes.Size = new Size(231, 66);
            panelClientes.TabIndex = 29;
            // 
            // panel26
            // 
            panel26.BackColor = Color.Beige;
            panel26.Controls.Add(btClientes);
            panel26.Location = new Point(3, 3);
            panel26.Name = "panel26";
            panel26.Padding = new Padding(0, 29, 0, 0);
            panel26.Size = new Size(277, 69);
            panel26.TabIndex = 6;
            // 
            // btClientes
            // 
            btClientes.BackColor = Color.Beige;
            btClientes.Font = new Font("Verdana", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btClientes.Image = (Image)resources.GetObject("btClientes.Image");
            btClientes.ImageAlign = ContentAlignment.MiddleLeft;
            btClientes.Location = new Point(-8, -15);
            btClientes.Margin = new Padding(0);
            btClientes.Name = "btClientes";
            btClientes.Padding = new Padding(25, 0, 0, 0);
            btClientes.Size = new Size(293, 93);
            btClientes.TabIndex = 5;
            btClientes.Text = "             Clientes    ";
            btClientes.TextAlign = ContentAlignment.MiddleLeft;
            btClientes.UseVisualStyleBackColor = false;
            btClientes.Click += btClientes_Click_1;
            // 
            // panel27
            // 
            panel27.BackColor = Color.Beige;
            panel27.Controls.Add(btAgregarClientes);
            panel27.Location = new Point(3, 78);
            panel27.Name = "panel27";
            panel27.Padding = new Padding(0, 29, 0, 0);
            panel27.Size = new Size(279, 69);
            panel27.TabIndex = 18;
            // 
            // btAgregarClientes
            // 
            btAgregarClientes.BackColor = Color.Beige;
            btAgregarClientes.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btAgregarClientes.Image = (Image)resources.GetObject("btAgregarClientes.Image");
            btAgregarClientes.ImageAlign = ContentAlignment.MiddleLeft;
            btAgregarClientes.Location = new Point(-10, -13);
            btAgregarClientes.Name = "btAgregarClientes";
            btAgregarClientes.Padding = new Padding(25, 0, 0, 0);
            btAgregarClientes.Size = new Size(293, 89);
            btAgregarClientes.TabIndex = 24;
            btAgregarClientes.Text = "              Agregar";
            btAgregarClientes.TextAlign = ContentAlignment.MiddleLeft;
            btAgregarClientes.UseVisualStyleBackColor = false;
            btAgregarClientes.Click += btAgregarClientes_Click;
            // 
            // panel28
            // 
            panel28.BackColor = Color.Beige;
            panel28.Controls.Add(btModificarClientes);
            panel28.Location = new Point(3, 153);
            panel28.Name = "panel28";
            panel28.Padding = new Padding(0, 29, 0, 0);
            panel28.Size = new Size(279, 66);
            panel28.TabIndex = 18;
            // 
            // btModificarClientes
            // 
            btModificarClientes.BackColor = Color.Beige;
            btModificarClientes.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btModificarClientes.Image = (Image)resources.GetObject("btModificarClientes.Image");
            btModificarClientes.ImageAlign = ContentAlignment.MiddleLeft;
            btModificarClientes.Location = new Point(-10, -18);
            btModificarClientes.Margin = new Padding(0);
            btModificarClientes.Name = "btModificarClientes";
            btModificarClientes.Padding = new Padding(25, 0, 0, 0);
            btModificarClientes.Size = new Size(296, 96);
            btModificarClientes.TabIndex = 18;
            btModificarClientes.Text = "              Modificar";
            btModificarClientes.TextAlign = ContentAlignment.MiddleLeft;
            btModificarClientes.UseVisualStyleBackColor = false;
            btModificarClientes.Click += btModificarClientes_Click;
            // 
            // panel29
            // 
            panel29.BackColor = Color.Beige;
            panel29.Controls.Add(panel30);
            panel29.Controls.Add(btEliminarClientes);
            panel29.Location = new Point(3, 225);
            panel29.Name = "panel29";
            panel29.Padding = new Padding(0, 29, 0, 0);
            panel29.Size = new Size(279, 69);
            panel29.TabIndex = 26;
            // 
            // panel30
            // 
            panel30.BackColor = Color.Beige;
            panel30.Controls.Add(panel31);
            panel30.Location = new Point(3, 70);
            panel30.Name = "panel30";
            panel30.Padding = new Padding(0, 29, 0, 0);
            panel30.Size = new Size(279, 69);
            panel30.TabIndex = 25;
            // 
            // panel31
            // 
            panel31.BackColor = Color.Beige;
            panel31.Location = new Point(3, 153);
            panel31.Name = "panel31";
            panel31.Padding = new Padding(0, 29, 0, 0);
            panel31.Size = new Size(279, 69);
            panel31.TabIndex = 26;
            // 
            // btEliminarClientes
            // 
            btEliminarClientes.BackColor = Color.Beige;
            btEliminarClientes.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btEliminarClientes.Image = (Image)resources.GetObject("btEliminarClientes.Image");
            btEliminarClientes.ImageAlign = ContentAlignment.MiddleLeft;
            btEliminarClientes.Location = new Point(-11, -21);
            btEliminarClientes.Margin = new Padding(0);
            btEliminarClientes.Name = "btEliminarClientes";
            btEliminarClientes.Padding = new Padding(25, 0, 0, 0);
            btEliminarClientes.Size = new Size(296, 99);
            btEliminarClientes.TabIndex = 16;
            btEliminarClientes.Text = "              Eliminar";
            btEliminarClientes.TextAlign = ContentAlignment.MiddleLeft;
            btEliminarClientes.UseVisualStyleBackColor = false;
            btEliminarClientes.Click += btEliminarClientes_Click;
            // 
            // panelHabitaciones
            // 
            panelHabitaciones.BackColor = Color.Beige;
            panelHabitaciones.Controls.Add(panel13);
            panelHabitaciones.Controls.Add(panel14);
            panelHabitaciones.Controls.Add(panel15);
            panelHabitaciones.Controls.Add(panel20);
            panelHabitaciones.Location = new Point(3, 150);
            panelHabitaciones.Name = "panelHabitaciones";
            panelHabitaciones.Size = new Size(231, 66);
            panelHabitaciones.TabIndex = 31;
            // 
            // panel13
            // 
            panel13.BackColor = Color.Beige;
            panel13.Controls.Add(btHabitaciones);
            panel13.Location = new Point(3, 3);
            panel13.Name = "panel13";
            panel13.Padding = new Padding(0, 29, 0, 0);
            panel13.Size = new Size(277, 69);
            panel13.TabIndex = 6;
            // 
            // btHabitaciones
            // 
            btHabitaciones.BackColor = Color.Beige;
            btHabitaciones.Font = new Font("Verdana", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btHabitaciones.Image = (Image)resources.GetObject("btHabitaciones.Image");
            btHabitaciones.ImageAlign = ContentAlignment.MiddleLeft;
            btHabitaciones.Location = new Point(-10, -7);
            btHabitaciones.Margin = new Padding(0);
            btHabitaciones.Name = "btHabitaciones";
            btHabitaciones.Padding = new Padding(25, 0, 0, 0);
            btHabitaciones.Size = new Size(293, 84);
            btHabitaciones.TabIndex = 5;
            btHabitaciones.Text = "             Habitaciones    ";
            btHabitaciones.TextAlign = ContentAlignment.MiddleLeft;
            btHabitaciones.UseVisualStyleBackColor = false;
            btHabitaciones.Click += btHabitaciones_Click_1;
            // 
            // panel14
            // 
            panel14.BackColor = Color.Beige;
            panel14.Controls.Add(btAgregarHabitaciones);
            panel14.Location = new Point(3, 78);
            panel14.Name = "panel14";
            panel14.Padding = new Padding(0, 29, 0, 0);
            panel14.Size = new Size(279, 69);
            panel14.TabIndex = 18;
            // 
            // btAgregarHabitaciones
            // 
            btAgregarHabitaciones.BackColor = Color.Beige;
            btAgregarHabitaciones.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btAgregarHabitaciones.Image = (Image)resources.GetObject("btAgregarHabitaciones.Image");
            btAgregarHabitaciones.ImageAlign = ContentAlignment.MiddleLeft;
            btAgregarHabitaciones.Location = new Point(-10, -13);
            btAgregarHabitaciones.Name = "btAgregarHabitaciones";
            btAgregarHabitaciones.Padding = new Padding(25, 0, 0, 0);
            btAgregarHabitaciones.Size = new Size(293, 89);
            btAgregarHabitaciones.TabIndex = 24;
            btAgregarHabitaciones.Text = "              Agregar";
            btAgregarHabitaciones.TextAlign = ContentAlignment.MiddleLeft;
            btAgregarHabitaciones.UseVisualStyleBackColor = false;
            btAgregarHabitaciones.Click += btAgregarHabitaciones_Click;
            // 
            // panel15
            // 
            panel15.BackColor = Color.Beige;
            panel15.Controls.Add(btModificarHabitaciones);
            panel15.Location = new Point(3, 153);
            panel15.Name = "panel15";
            panel15.Padding = new Padding(0, 29, 0, 0);
            panel15.Size = new Size(279, 66);
            panel15.TabIndex = 18;
            // 
            // btModificarHabitaciones
            // 
            btModificarHabitaciones.BackColor = Color.Beige;
            btModificarHabitaciones.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btModificarHabitaciones.Image = (Image)resources.GetObject("btModificarHabitaciones.Image");
            btModificarHabitaciones.ImageAlign = ContentAlignment.MiddleLeft;
            btModificarHabitaciones.Location = new Point(-10, -18);
            btModificarHabitaciones.Margin = new Padding(0);
            btModificarHabitaciones.Name = "btModificarHabitaciones";
            btModificarHabitaciones.Padding = new Padding(25, 0, 0, 0);
            btModificarHabitaciones.Size = new Size(296, 96);
            btModificarHabitaciones.TabIndex = 18;
            btModificarHabitaciones.Text = "              Modificar";
            btModificarHabitaciones.TextAlign = ContentAlignment.MiddleLeft;
            btModificarHabitaciones.UseVisualStyleBackColor = false;
            btModificarHabitaciones.Click += btModificarHabitaciones_Click;
            // 
            // panel20
            // 
            panel20.BackColor = Color.Beige;
            panel20.Controls.Add(panel21);
            panel20.Controls.Add(btEliminarHabitaciones);
            panel20.Location = new Point(3, 225);
            panel20.Name = "panel20";
            panel20.Padding = new Padding(0, 29, 0, 0);
            panel20.Size = new Size(279, 69);
            panel20.TabIndex = 26;
            // 
            // panel21
            // 
            panel21.BackColor = Color.Beige;
            panel21.Controls.Add(panel22);
            panel21.Location = new Point(3, 70);
            panel21.Name = "panel21";
            panel21.Padding = new Padding(0, 29, 0, 0);
            panel21.Size = new Size(279, 69);
            panel21.TabIndex = 25;
            // 
            // panel22
            // 
            panel22.BackColor = Color.Beige;
            panel22.Location = new Point(3, 153);
            panel22.Name = "panel22";
            panel22.Padding = new Padding(0, 29, 0, 0);
            panel22.Size = new Size(279, 69);
            panel22.TabIndex = 26;
            // 
            // btEliminarHabitaciones
            // 
            btEliminarHabitaciones.BackColor = Color.Beige;
            btEliminarHabitaciones.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btEliminarHabitaciones.Image = (Image)resources.GetObject("btEliminarHabitaciones.Image");
            btEliminarHabitaciones.ImageAlign = ContentAlignment.MiddleLeft;
            btEliminarHabitaciones.Location = new Point(-11, -21);
            btEliminarHabitaciones.Margin = new Padding(0);
            btEliminarHabitaciones.Name = "btEliminarHabitaciones";
            btEliminarHabitaciones.Padding = new Padding(25, 0, 0, 0);
            btEliminarHabitaciones.Size = new Size(296, 99);
            btEliminarHabitaciones.TabIndex = 16;
            btEliminarHabitaciones.Text = "              Eliminar";
            btEliminarHabitaciones.TextAlign = ContentAlignment.MiddleLeft;
            btEliminarHabitaciones.UseVisualStyleBackColor = false;
            btEliminarHabitaciones.Click += btEliminarHabitaciones_Click;
            // 
            // panelEstadias
            // 
            panelEstadias.BackColor = Color.Beige;
            panelEstadias.Controls.Add(panel3);
            panelEstadias.Controls.Add(panel5);
            panelEstadias.Controls.Add(panel6);
            panelEstadias.Controls.Add(panel32);
            panelEstadias.Location = new Point(3, 222);
            panelEstadias.Name = "panelEstadias";
            panelEstadias.Size = new Size(231, 66);
            panelEstadias.TabIndex = 30;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Beige;
            panel3.Controls.Add(btEstadias);
            panel3.Location = new Point(3, 3);
            panel3.Name = "panel3";
            panel3.Padding = new Padding(0, 29, 0, 0);
            panel3.Size = new Size(277, 69);
            panel3.TabIndex = 6;
            // 
            // btEstadias
            // 
            btEstadias.BackColor = Color.Beige;
            btEstadias.Font = new Font("Verdana", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btEstadias.Image = (Image)resources.GetObject("btEstadias.Image");
            btEstadias.ImageAlign = ContentAlignment.MiddleLeft;
            btEstadias.Location = new Point(-10, -7);
            btEstadias.Margin = new Padding(0);
            btEstadias.Name = "btEstadias";
            btEstadias.Padding = new Padding(25, 0, 0, 0);
            btEstadias.Size = new Size(293, 84);
            btEstadias.TabIndex = 5;
            btEstadias.Text = "             Estadías    ";
            btEstadias.TextAlign = ContentAlignment.MiddleLeft;
            btEstadias.UseVisualStyleBackColor = false;
            btEstadias.Click += btEstadias_Click;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Beige;
            panel5.Controls.Add(btAgregarEstadia);
            panel5.Location = new Point(3, 78);
            panel5.Name = "panel5";
            panel5.Padding = new Padding(0, 29, 0, 0);
            panel5.Size = new Size(279, 69);
            panel5.TabIndex = 18;
            // 
            // btAgregarEstadia
            // 
            btAgregarEstadia.BackColor = Color.Beige;
            btAgregarEstadia.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btAgregarEstadia.Image = (Image)resources.GetObject("btAgregarEstadia.Image");
            btAgregarEstadia.ImageAlign = ContentAlignment.MiddleLeft;
            btAgregarEstadia.Location = new Point(-10, -13);
            btAgregarEstadia.Name = "btAgregarEstadia";
            btAgregarEstadia.Padding = new Padding(25, 0, 0, 0);
            btAgregarEstadia.Size = new Size(293, 89);
            btAgregarEstadia.TabIndex = 24;
            btAgregarEstadia.Text = "              Agregar";
            btAgregarEstadia.TextAlign = ContentAlignment.MiddleLeft;
            btAgregarEstadia.UseVisualStyleBackColor = false;
            btAgregarEstadia.Click += btAgregarEstadia_Click;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Beige;
            panel6.Controls.Add(btModificarEstadia);
            panel6.Location = new Point(3, 153);
            panel6.Name = "panel6";
            panel6.Padding = new Padding(0, 29, 0, 0);
            panel6.Size = new Size(279, 66);
            panel6.TabIndex = 18;
            // 
            // btModificarEstadia
            // 
            btModificarEstadia.BackColor = Color.Beige;
            btModificarEstadia.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btModificarEstadia.Image = (Image)resources.GetObject("btModificarEstadia.Image");
            btModificarEstadia.ImageAlign = ContentAlignment.MiddleLeft;
            btModificarEstadia.Location = new Point(-10, -18);
            btModificarEstadia.Margin = new Padding(0);
            btModificarEstadia.Name = "btModificarEstadia";
            btModificarEstadia.Padding = new Padding(25, 0, 0, 0);
            btModificarEstadia.Size = new Size(296, 96);
            btModificarEstadia.TabIndex = 18;
            btModificarEstadia.Text = "              Modificar";
            btModificarEstadia.TextAlign = ContentAlignment.MiddleLeft;
            btModificarEstadia.UseVisualStyleBackColor = false;
            btModificarEstadia.Click += btModificarEstadia_Click;
            // 
            // panel32
            // 
            panel32.BackColor = Color.Beige;
            panel32.Controls.Add(panel33);
            panel32.Controls.Add(btEliminarEstadia);
            panel32.Location = new Point(3, 225);
            panel32.Name = "panel32";
            panel32.Padding = new Padding(0, 29, 0, 0);
            panel32.Size = new Size(279, 69);
            panel32.TabIndex = 26;
            // 
            // panel33
            // 
            panel33.BackColor = Color.Beige;
            panel33.Controls.Add(panel34);
            panel33.Location = new Point(3, 70);
            panel33.Name = "panel33";
            panel33.Padding = new Padding(0, 29, 0, 0);
            panel33.Size = new Size(279, 69);
            panel33.TabIndex = 25;
            // 
            // panel34
            // 
            panel34.BackColor = Color.Beige;
            panel34.Location = new Point(3, 153);
            panel34.Name = "panel34";
            panel34.Padding = new Padding(0, 29, 0, 0);
            panel34.Size = new Size(279, 69);
            panel34.TabIndex = 26;
            // 
            // btEliminarEstadia
            // 
            btEliminarEstadia.BackColor = Color.Beige;
            btEliminarEstadia.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btEliminarEstadia.Image = (Image)resources.GetObject("btEliminarEstadia.Image");
            btEliminarEstadia.ImageAlign = ContentAlignment.MiddleLeft;
            btEliminarEstadia.Location = new Point(-11, -21);
            btEliminarEstadia.Margin = new Padding(0);
            btEliminarEstadia.Name = "btEliminarEstadia";
            btEliminarEstadia.Padding = new Padding(25, 0, 0, 0);
            btEliminarEstadia.Size = new Size(296, 99);
            btEliminarEstadia.TabIndex = 16;
            btEliminarEstadia.Text = "              Eliminar";
            btEliminarEstadia.TextAlign = ContentAlignment.MiddleLeft;
            btEliminarEstadia.UseVisualStyleBackColor = false;
            btEliminarEstadia.Click += btEliminarEstadia_Click;
            // 
            // panelReservas
            // 
            panelReservas.BackColor = Color.Beige;
            panelReservas.Controls.Add(panel4);
            panelReservas.Controls.Add(panel7);
            panelReservas.Controls.Add(panel9);
            panelReservas.Controls.Add(panel10);
            panelReservas.Location = new Point(3, 294);
            panelReservas.Name = "panelReservas";
            panelReservas.Size = new Size(231, 66);
            panelReservas.TabIndex = 30;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Beige;
            panel4.Controls.Add(btReservas);
            panel4.Location = new Point(3, 3);
            panel4.Name = "panel4";
            panel4.Padding = new Padding(0, 29, 0, 0);
            panel4.Size = new Size(277, 69);
            panel4.TabIndex = 6;
            // 
            // btReservas
            // 
            btReservas.BackColor = Color.Beige;
            btReservas.Font = new Font("Verdana", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btReservas.Image = (Image)resources.GetObject("btReservas.Image");
            btReservas.ImageAlign = ContentAlignment.MiddleLeft;
            btReservas.Location = new Point(-10, -7);
            btReservas.Margin = new Padding(0);
            btReservas.Name = "btReservas";
            btReservas.Padding = new Padding(25, 0, 0, 0);
            btReservas.Size = new Size(293, 84);
            btReservas.TabIndex = 5;
            btReservas.Text = "             Reservas    ";
            btReservas.TextAlign = ContentAlignment.MiddleLeft;
            btReservas.UseVisualStyleBackColor = false;
            btReservas.Click += btReservas_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Beige;
            panel7.Controls.Add(btAgregarReserva);
            panel7.Location = new Point(3, 78);
            panel7.Name = "panel7";
            panel7.Padding = new Padding(0, 29, 0, 0);
            panel7.Size = new Size(279, 69);
            panel7.TabIndex = 18;
            // 
            // btAgregarReserva
            // 
            btAgregarReserva.BackColor = Color.Beige;
            btAgregarReserva.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btAgregarReserva.Image = (Image)resources.GetObject("btAgregarReserva.Image");
            btAgregarReserva.ImageAlign = ContentAlignment.MiddleLeft;
            btAgregarReserva.Location = new Point(-10, -13);
            btAgregarReserva.Name = "btAgregarReserva";
            btAgregarReserva.Padding = new Padding(25, 0, 0, 0);
            btAgregarReserva.Size = new Size(293, 89);
            btAgregarReserva.TabIndex = 24;
            btAgregarReserva.Text = "              Agregar";
            btAgregarReserva.TextAlign = ContentAlignment.MiddleLeft;
            btAgregarReserva.UseVisualStyleBackColor = false;
            btAgregarReserva.Click += btAgregarReserva_Click;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Beige;
            panel9.Controls.Add(btModificarReserva);
            panel9.Location = new Point(3, 153);
            panel9.Name = "panel9";
            panel9.Padding = new Padding(0, 29, 0, 0);
            panel9.Size = new Size(279, 66);
            panel9.TabIndex = 18;
            // 
            // btModificarReserva
            // 
            btModificarReserva.BackColor = Color.Beige;
            btModificarReserva.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btModificarReserva.Image = (Image)resources.GetObject("btModificarReserva.Image");
            btModificarReserva.ImageAlign = ContentAlignment.MiddleLeft;
            btModificarReserva.Location = new Point(-10, -18);
            btModificarReserva.Margin = new Padding(0);
            btModificarReserva.Name = "btModificarReserva";
            btModificarReserva.Padding = new Padding(25, 0, 0, 0);
            btModificarReserva.Size = new Size(296, 96);
            btModificarReserva.TabIndex = 18;
            btModificarReserva.Text = "              Modificar";
            btModificarReserva.TextAlign = ContentAlignment.MiddleLeft;
            btModificarReserva.UseVisualStyleBackColor = false;
            btModificarReserva.Click += btModificarReserva_Click;
            // 
            // panel10
            // 
            panel10.BackColor = Color.Beige;
            panel10.Controls.Add(panel11);
            panel10.Controls.Add(btEliminarReserva);
            panel10.Location = new Point(3, 225);
            panel10.Name = "panel10";
            panel10.Padding = new Padding(0, 29, 0, 0);
            panel10.Size = new Size(279, 69);
            panel10.TabIndex = 26;
            // 
            // panel11
            // 
            panel11.BackColor = Color.Beige;
            panel11.Controls.Add(panel12);
            panel11.Location = new Point(3, 70);
            panel11.Name = "panel11";
            panel11.Padding = new Padding(0, 29, 0, 0);
            panel11.Size = new Size(279, 69);
            panel11.TabIndex = 25;
            // 
            // panel12
            // 
            panel12.BackColor = Color.Beige;
            panel12.Location = new Point(3, 153);
            panel12.Name = "panel12";
            panel12.Padding = new Padding(0, 29, 0, 0);
            panel12.Size = new Size(279, 69);
            panel12.TabIndex = 26;
            // 
            // btEliminarReserva
            // 
            btEliminarReserva.BackColor = Color.Beige;
            btEliminarReserva.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btEliminarReserva.Image = (Image)resources.GetObject("btEliminarReserva.Image");
            btEliminarReserva.ImageAlign = ContentAlignment.MiddleLeft;
            btEliminarReserva.Location = new Point(-11, -21);
            btEliminarReserva.Margin = new Padding(0);
            btEliminarReserva.Name = "btEliminarReserva";
            btEliminarReserva.Padding = new Padding(25, 0, 0, 0);
            btEliminarReserva.Size = new Size(296, 99);
            btEliminarReserva.TabIndex = 16;
            btEliminarReserva.Text = "              Eliminar";
            btEliminarReserva.TextAlign = ContentAlignment.MiddleLeft;
            btEliminarReserva.UseVisualStyleBackColor = false;
            btEliminarReserva.Click += btEliminarReserva_Click;
            // 
            // panelCuentaCliente
            // 
            panelCuentaCliente.BackColor = Color.Beige;
            panelCuentaCliente.Controls.Add(panel16);
            panelCuentaCliente.Controls.Add(panel17);
            panelCuentaCliente.Controls.Add(panel18);
            panelCuentaCliente.Controls.Add(panel19);
            panelCuentaCliente.Location = new Point(3, 366);
            panelCuentaCliente.Name = "panelCuentaCliente";
            panelCuentaCliente.Size = new Size(231, 66);
            panelCuentaCliente.TabIndex = 28;
            // 
            // panel16
            // 
            panel16.BackColor = Color.Beige;
            panel16.Controls.Add(btCuentaCliente);
            panel16.Location = new Point(3, 3);
            panel16.Name = "panel16";
            panel16.Padding = new Padding(0, 29, 0, 0);
            panel16.Size = new Size(277, 69);
            panel16.TabIndex = 6;
            // 
            // btCuentaCliente
            // 
            btCuentaCliente.BackColor = Color.Beige;
            btCuentaCliente.Font = new Font("Verdana", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btCuentaCliente.Image = (Image)resources.GetObject("btCuentaCliente.Image");
            btCuentaCliente.ImageAlign = ContentAlignment.MiddleLeft;
            btCuentaCliente.Location = new Point(-10, -7);
            btCuentaCliente.Margin = new Padding(0);
            btCuentaCliente.Name = "btCuentaCliente";
            btCuentaCliente.Padding = new Padding(25, 0, 0, 0);
            btCuentaCliente.Size = new Size(293, 84);
            btCuentaCliente.TabIndex = 5;
            btCuentaCliente.Text = "           Cuenta Cliente    ";
            btCuentaCliente.TextAlign = ContentAlignment.MiddleLeft;
            btCuentaCliente.UseVisualStyleBackColor = false;
            btCuentaCliente.Click += btCuentaCliente_Click;
            // 
            // panel17
            // 
            panel17.BackColor = Color.Beige;
            panel17.Controls.Add(btAgregarGasto);
            panel17.Location = new Point(3, 78);
            panel17.Name = "panel17";
            panel17.Padding = new Padding(0, 29, 0, 0);
            panel17.Size = new Size(279, 69);
            panel17.TabIndex = 18;
            // 
            // btAgregarGasto
            // 
            btAgregarGasto.BackColor = Color.Beige;
            btAgregarGasto.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btAgregarGasto.Image = (Image)resources.GetObject("btAgregarGasto.Image");
            btAgregarGasto.ImageAlign = ContentAlignment.MiddleLeft;
            btAgregarGasto.Location = new Point(-10, -13);
            btAgregarGasto.Name = "btAgregarGasto";
            btAgregarGasto.Padding = new Padding(25, 0, 0, 0);
            btAgregarGasto.Size = new Size(293, 89);
            btAgregarGasto.TabIndex = 24;
            btAgregarGasto.Text = "            Agregar Gasto";
            btAgregarGasto.TextAlign = ContentAlignment.MiddleLeft;
            btAgregarGasto.UseVisualStyleBackColor = false;
            btAgregarGasto.Click += btAgregarGasto_Click;
            // 
            // panel18
            // 
            panel18.BackColor = Color.Beige;
            panel18.Controls.Add(btModificarGasto);
            panel18.Location = new Point(3, 153);
            panel18.Name = "panel18";
            panel18.Padding = new Padding(0, 29, 0, 0);
            panel18.Size = new Size(279, 66);
            panel18.TabIndex = 18;
            // 
            // btModificarGasto
            // 
            btModificarGasto.BackColor = Color.Beige;
            btModificarGasto.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btModificarGasto.Image = (Image)resources.GetObject("btModificarGasto.Image");
            btModificarGasto.ImageAlign = ContentAlignment.MiddleLeft;
            btModificarGasto.Location = new Point(-10, -18);
            btModificarGasto.Margin = new Padding(0);
            btModificarGasto.Name = "btModificarGasto";
            btModificarGasto.Padding = new Padding(25, 0, 0, 0);
            btModificarGasto.Size = new Size(296, 96);
            btModificarGasto.TabIndex = 18;
            btModificarGasto.Text = "            Modificar Gasto";
            btModificarGasto.TextAlign = ContentAlignment.MiddleLeft;
            btModificarGasto.UseVisualStyleBackColor = false;
            btModificarGasto.Click += btModificarGasto_Click;
            // 
            // panel19
            // 
            panel19.BackColor = Color.Beige;
            panel19.Controls.Add(panel24);
            panel19.Controls.Add(btEliminarGasto);
            panel19.Location = new Point(3, 225);
            panel19.Name = "panel19";
            panel19.Padding = new Padding(0, 29, 0, 0);
            panel19.Size = new Size(279, 69);
            panel19.TabIndex = 26;
            // 
            // panel24
            // 
            panel24.BackColor = Color.Beige;
            panel24.Controls.Add(panel25);
            panel24.Location = new Point(3, 70);
            panel24.Name = "panel24";
            panel24.Padding = new Padding(0, 29, 0, 0);
            panel24.Size = new Size(279, 69);
            panel24.TabIndex = 25;
            // 
            // panel25
            // 
            panel25.BackColor = Color.Beige;
            panel25.Location = new Point(3, 153);
            panel25.Name = "panel25";
            panel25.Padding = new Padding(0, 29, 0, 0);
            panel25.Size = new Size(279, 69);
            panel25.TabIndex = 26;
            // 
            // btEliminarGasto
            // 
            btEliminarGasto.BackColor = Color.Beige;
            btEliminarGasto.Font = new Font("Verdana", 9F, FontStyle.Italic, GraphicsUnit.Point);
            btEliminarGasto.Image = (Image)resources.GetObject("btEliminarGasto.Image");
            btEliminarGasto.ImageAlign = ContentAlignment.MiddleLeft;
            btEliminarGasto.Location = new Point(-11, -21);
            btEliminarGasto.Margin = new Padding(0);
            btEliminarGasto.Name = "btEliminarGasto";
            btEliminarGasto.Padding = new Padding(25, 0, 0, 0);
            btEliminarGasto.Size = new Size(296, 99);
            btEliminarGasto.TabIndex = 16;
            btEliminarGasto.Text = "            Eliminar Gasto";
            btEliminarGasto.TextAlign = ContentAlignment.MiddleLeft;
            btEliminarGasto.UseVisualStyleBackColor = false;
            btEliminarGasto.Click += btEliminarGasto_Click;
            // 
            // panel23
            // 
            panel23.BackColor = Color.Beige;
            panel23.Controls.Add(btSalirr);
            panel23.Location = new Point(3, 438);
            panel23.Name = "panel23";
            panel23.Padding = new Padding(0, 29, 0, 0);
            panel23.Size = new Size(231, 88);
            panel23.TabIndex = 23;
            // 
            // btSalirr
            // 
            btSalirr.BackColor = Color.Beige;
            btSalirr.Font = new Font("Verdana", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btSalirr.Image = (Image)resources.GetObject("btSalirr.Image");
            btSalirr.ImageAlign = ContentAlignment.MiddleLeft;
            btSalirr.Location = new Point(-8, -7);
            btSalirr.Name = "btSalirr";
            btSalirr.Padding = new Padding(25, 0, 0, 0);
            btSalirr.Size = new Size(278, 104);
            btSalirr.TabIndex = 25;
            btSalirr.Text = "              Salir";
            btSalirr.TextAlign = ContentAlignment.MiddleLeft;
            btSalirr.UseVisualStyleBackColor = false;
            btSalirr.Click += btSalirr_Click;
            // 
            // menuTransitionCliente
            // 
            menuTransitionCliente.Interval = 10;
            menuTransitionCliente.Tick += menuTransitionCliente_Tick;
            // 
            // menuTransitionHabitacion
            // 
            menuTransitionHabitacion.Interval = 10;
            menuTransitionHabitacion.Tick += menuTransitionHabitacion_Tick_1;
            // 
            // menuTransitionEstadia
            // 
            menuTransitionEstadia.Interval = 10;
            menuTransitionEstadia.Tick += menuTransitionEstadia_Tick;
            // 
            // menuTransitionReserva
            // 
            menuTransitionReserva.Interval = 10;
            menuTransitionReserva.Tick += menuTransitionReserva_Tick;
            // 
            // menuTransitionCuentaCliente
            // 
            menuTransitionCuentaCliente.Interval = 10;
            menuTransitionCuentaCliente.Tick += menuTransitionCuentaCliente_Tick;
            // 
            // panelMenuTransition
            // 
            panelMenuTransition.Interval = 10;
            panelMenuTransition.Tick += panelMenuTransition_Tick;
            // 
            // menuTransitionUsuarios
            // 
            menuTransitionUsuarios.Tick += menuTransitionUsuarios_Tick;
            // 
            // panelBase
            // 
            panelBase.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            panelBase.BackgroundImage = (Image)resources.GetObject("panelBase.BackgroundImage");
            panelBase.BackgroundImageLayout = ImageLayout.Stretch;
            panelBase.Location = new Point(73, 44);
            panelBase.Name = "panelBase";
            panelBase.Size = new Size(1240, 642);
            panelBase.TabIndex = 4;
            // 
            // Principal
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1313, 684);
            Controls.Add(panelPrincipal);
            Controls.Add(panel2);
            Controls.Add(panelBase);
            Name = "Principal";
            Text = "Principal";
            FormClosing += Principal_FormClosing;
            Load += Principal_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btMenuPanel).EndInit();
            panelPrincipal.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panelClientes.ResumeLayout(false);
            panel26.ResumeLayout(false);
            panel27.ResumeLayout(false);
            panel28.ResumeLayout(false);
            panel29.ResumeLayout(false);
            panel30.ResumeLayout(false);
            panelHabitaciones.ResumeLayout(false);
            panel13.ResumeLayout(false);
            panel14.ResumeLayout(false);
            panel15.ResumeLayout(false);
            panel20.ResumeLayout(false);
            panel21.ResumeLayout(false);
            panelEstadias.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel32.ResumeLayout(false);
            panel33.ResumeLayout(false);
            panelReservas.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel9.ResumeLayout(false);
            panel10.ResumeLayout(false);
            panel11.ResumeLayout(false);
            panelCuentaCliente.ResumeLayout(false);
            panel16.ResumeLayout(false);
            panel17.ResumeLayout(false);
            panel18.ResumeLayout(false);
            panel19.ResumeLayout(false);
            panel24.ResumeLayout(false);
            panel23.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel panel2;
        private PictureBox pictureBox1;
        private Label label2;
        private PictureBox btMenuPanel;
        private FlowLayoutPanel panelPrincipal;
        private Panel panel1;
        private Button btInicio;
        private System.Windows.Forms.Timer menuTransitionCliente;
        private FlowLayoutPanel panelCuentaCliente;
        private Panel panel16;
        private Button btCuentaCliente;
        private Panel panel17;
        private Button btAgregarGasto;
        private Panel panel18;
        private Button btModificarGasto;
        private Panel panel19;
        private Panel panel24;
        private Panel panel25;
        private Button btEliminarGasto;
        private FlowLayoutPanel panelClientes;
        private Panel panel26;
        private Button btClientes;
        private Panel panel27;
        private Button btAgregarClientes;
        private Panel panel28;
        private Button btModificarClientes;
        private Panel panel29;
        private Panel panel30;
        private Panel panel31;
        private Button btEliminarClientes;
        private FlowLayoutPanel panelEstadias;
        private Panel panel3;
        private Button btEstadias;
        private Panel panel5;
        private Button btAgregarEstadia;
        private Panel panel6;
        private Button btModificarEstadia;
        private Panel panel32;
        private Panel panel33;
        private Panel panel34;
        private Button btEliminarEstadia;
        private FlowLayoutPanel panelReservas;
        private Panel panel4;
        private Button btReservas;
        private Panel panel7;
        private Button btAgregarReserva;
        private Panel panel9;
        private Button btModificarReserva;
        private Panel panel10;
        private Panel panel11;
        private Panel panel12;
        private Button btEliminarReserva;
        private FlowLayoutPanel panelHabitaciones;
        private Panel panel13;
        private Button btHabitaciones;
        private Panel panel14;
        private Button btAgregarHabitaciones;
        private Panel panel15;
        private Button btModificarHabitaciones;
        private Panel panel20;
        private Panel panel21;
        private Panel panel22;
        private Button btEliminarHabitaciones;
        private System.Windows.Forms.Timer menuTransitionHabitacion;
        private System.Windows.Forms.Timer menuTransitionEstadia;
        private System.Windows.Forms.Timer menuTransitionReserva;
        private System.Windows.Forms.Timer menuTransitionCuentaCliente;
        private Button btSalirr;
        private System.Windows.Forms.Timer panelMenuTransition;
        private System.Windows.Forms.Timer menuTransitionUsuarios;
        private Panel panel23;
        private Panel panelBase;
    }
}