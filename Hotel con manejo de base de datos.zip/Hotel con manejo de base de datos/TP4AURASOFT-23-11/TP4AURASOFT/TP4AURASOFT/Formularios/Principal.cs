﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TP4AURASOFT.Formularios;

namespace AURASOFT_DESIGN_TP4.Formularios
{
    public partial class Principal : Form
    {
        Inicio inicio;

        Cliente cliente;
        AgregarCliente agregarCliente;
        ModificarCliente modificarCliente;
        EliminarCliente eliminarCliente;

        Habitaciones habitaciones;
        AgregarHabitaciones agregarHabitaciones;
        ModificarHabitaciones modificarHabitaciones;
        EliminarHabitaciones eliminarHabitaciones;

        Estadía estadía;
        AgregarEstadia agregarEstadia;
        ModificarEstadia modificarEstadia;
        EliminarEstadia eliminarEstadia;

        Reservas reservas;
        AgregarReservas agregarReservas;
        ModificarReservas modificarReservas;
        EliminarReservas eliminarReservas;

        CuentasClientes clientes;
        AgregarGastos agregarGastos;
        ModificarGastos modificarGastos;
        EliminarGastos eliminarGastos;


        public Principal()
        {
            InitializeComponent();
        }

        void AbrirForm(Form f)//ABRE EL FORMULARIO DENTRO DEL PANEL
        {
            // Verifica si hay algún control en el panel
            if (panelBase.Controls.Count > 0)
            {
                // Elimina el primer control (si hay alguno)
                panelBase.Controls.RemoveAt(0);
            }
            // Establece que el formulario no es de nivel superior para ser contenido en otro control
            f.TopLevel = false;
            this.panelBase.Controls.Add(f);//AÑADIR EL FORM AL PANEL
            f.Dock = DockStyle.Fill;//RELLENAR EL PANEL CON EL FORM

            f.Show();//MOSTRAR EL FORM
            
        }

        //PARA QUE SEA RESPONSIVE =
        // Constantes que representan mensajes y comandos del sistema de Windows
        const int WM_SYSCOMMAND = 0x0112;
        const int SC_MAXIMIZE = 0xF030;
        const int SC_RESTORE = 0xF120;

        // Sobrescribe el método WndProc para personalizar el manejo de mensajes de ventana
        protected override void WndProc(ref Message m)
        {
            // Llama al método WndProc de la clase base para el procesamiento predeterminado
            base.WndProc(ref m);
            // Verifica si el mensaje es WM_SYSCOMMAND
            if (m.Msg == WM_SYSCOMMAND)
            {
                // Verifica si el comando es SC_MAXIMIZE o SC_RESTORE
                if (m.WParam == (IntPtr)SC_MAXIMIZE || m.WParam == (IntPtr)SC_RESTORE)
                    // Invoca el evento OnResizeEnd cuando se maximiza o restaura la ventana
                    this.OnResizeEnd(EventArgs.Empty);
            }
        }

        private void Principal_Load(object sender, EventArgs e)
        {

        }

        bool MenuExpandir = false; //BOLEANO PARA SABER SI EXPANDIR LOS MENU DE LOS SERVICIOS
        private void menuTransitionCliente_Tick(object sender, EventArgs e) //TRANSICIÓN DEL MENU CLIENTE
        {
            if (MenuExpandir == false)
            {
                panelClientes.Height += 10;//AUMENTA EL TAMAÑO DEL PANEL
                if (panelClientes.Height >= 297)//SE AGRANDA EL PANEL
                {
                    menuTransitionCliente.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = true;//SE EXPANDEN LAS OPCIONES DEL MENU
                }
            }
            else
            {
                panelClientes.Height -= 10;//DISMINUYE EL TAMAÑO DEL PANEL
                if (panelClientes.Height <= 66)//SE CIERRA EL PANEL
                {
                    menuTransitionCliente.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = false;//SE EXPANDEN LAS OPCIONES DEL MENU

                }
            }
        }

        private void menuTransitionHabitacion_Tick_1(object sender, EventArgs e)
        {
            if (MenuExpandir == false)
            {
                panelHabitaciones.Height += 10;//AUMENTA EL TAMAÑO DEL PANEL
                if (panelHabitaciones.Height >= 297)//SE AGRANDA EL PANEL
                {
                    menuTransitionHabitacion.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = true;//SE EXPANDEN LAS OPCIONES DEL MENU
                }
            }
            else
            {
                panelHabitaciones.Height -= 10;//DISMINUYE EL TAMAÑO DEL PANEL
                if (panelHabitaciones.Height <= 66)//SE CIERRA EL PANEL
                {
                    menuTransitionHabitacion.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = false;//SE EXPANDEN LAS OPCIONES DEL MENU

                }
            }
        }

        private void menuTransitionCuentaCliente_Tick(object sender, EventArgs e)
        {
            if (MenuExpandir == false)
            {
                panelCuentaCliente.Height += 10;//AUMENTA EL TAMAÑO DEL PANEL
                if (panelCuentaCliente.Height >= 297)//SE AGRANDA EL PANEL
                {
                    menuTransitionCuentaCliente.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = true;//SE EXPANDEN LAS OPCIONES DEL MENU
                }
            }
            else
            {
                panelCuentaCliente.Height -= 10;//DISMINUYE EL TAMAÑO DEL PANEL
                if (panelCuentaCliente.Height <= 66)//SE CIERRA EL PANEL
                {
                    menuTransitionCuentaCliente.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = false;//SE EXPANDEN LAS OPCIONES DEL MENU

                }
            }
        }

        private void menuTransitionReserva_Tick(object sender, EventArgs e)
        {
            if (MenuExpandir == false)
            {
                panelReservas.Height += 10;//AUMENTA EL TAMAÑO DEL PANEL
                if (panelReservas.Height >= 297)//SE AGRANDA EL PANEL
                {
                    menuTransitionReserva.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = true;//SE EXPANDEN LAS OPCIONES DEL MENU
                }
            }
            else
            {
                panelReservas.Height -= 10;//DISMINUYE EL TAMAÑO DEL PANEL
                if (panelReservas.Height <= 66)//SE CIERRA EL PANEL
                {
                    menuTransitionReserva.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = false;//SE EXPANDEN LAS OPCIONES DEL MENU

                }
            }
        }

        private void menuTransitionEstadia_Tick(object sender, EventArgs e)
        {
            if (MenuExpandir == false)
            {
                panelEstadias.Height += 10;//AUMENTA EL TAMAÑO DEL PANEL
                if (panelEstadias.Height >= 297)//SE AGRANDA EL PANEL
                {
                    menuTransitionEstadia.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = true;//SE EXPANDEN LAS OPCIONES DEL MENU
                }
            }
            else
            {
                panelEstadias.Height -= 10;//DISMINUYE EL TAMAÑO DEL PANEL
                if (panelEstadias.Height <= 66)//SE CIERRA EL PANEL
                {
                    menuTransitionEstadia.Stop();//TERMINA LA TRANSICIÓN
                    MenuExpandir = false;//SE EXPANDEN LAS OPCIONES DEL MENU

                }
            }
        }

        private void btClientes_Click_1(object sender, EventArgs e)
        {
            menuTransitionCliente.Start();//INICIA LA TRANSICIÓN DEL PANEL
            Cliente c = new Cliente();
            AbrirForm(c);//ABRE EL FORM
        }

        private void btHabitaciones_Click_1(object sender, EventArgs e)
        {
            menuTransitionHabitacion.Start();//INICIA LA TRANSICIÓN DEL PANEL
            Habitaciones h = new Habitaciones();
            AbrirForm(h);//ABRE EL FORM
        }

        private void btEstadias_Click(object sender, EventArgs e)
        {
            menuTransitionEstadia.Start();//INICIA LA TRANSICIÓN DEL PANEL
            Estadía es = new Estadía();
            AbrirForm(es);//ABRE EL FORM
        }

        private void btCuentaCliente_Click(object sender, EventArgs e)
        {
            menuTransitionCuentaCliente.Start();//INICIA LA TRANSICIÓN DEL PANEL
            CuentasClientes cc = new CuentasClientes();
            AbrirForm(cc);//ABRE EL FORM
        }

        private void btReservas_Click(object sender, EventArgs e)
        {
            menuTransitionReserva.Start();//INICIA LA TRANSICIÓN DEL PANEL
            Reservas r = new Reservas();
            AbrirForm(r);//ABRE EL FORM
        }

        private void btAgregarClientes_Click(object sender, EventArgs e)
        {
            AgregarCliente ac = new AgregarCliente();
            AbrirForm(ac);//ABRE EL FORM
        }

        private void AgregarCliente_FormClosed(object sender, FormClosedEventArgs e)
        {
            agregarCliente = null;
        }

        private void btModificarClientes_Click(object sender, EventArgs e)
        {
            ModificarCliente mc = new ModificarCliente();
            AbrirForm(mc);//ABRE EL FORM
        }

        private void btEliminarClientes_Click(object sender, EventArgs e)
        {
            EliminarCliente ec = new EliminarCliente();
            AbrirForm(ec);//ABRE EL FORM
        }

        private void btAgregarHabitaciones_Click(object sender, EventArgs e)
        {
            AgregarHabitaciones ah = new AgregarHabitaciones();
            AbrirForm(ah);//ABRE EL FORM
        }

        private void btModificarHabitaciones_Click(object sender, EventArgs e)
        {
            ModificarHabitaciones mh = new ModificarHabitaciones();
            AbrirForm(mh);//ABRE EL FORM
        }

        private void btEliminarHabitaciones_Click(object sender, EventArgs e)
        {
            EliminarHabitaciones eh = new EliminarHabitaciones();
            AbrirForm(eh);//ABRE EL FORM
        }

        private void btAgregarEstadia_Click(object sender, EventArgs e)
        {
            AgregarEstadia ae = new AgregarEstadia();
            AbrirForm(ae);//ABRE EL FORM
        }

        private void btModificarEstadia_Click(object sender, EventArgs e)
        {
            ModificarEstadia me = new ModificarEstadia();
            AbrirForm(me);//ABRE EL FORM
        }

        private void btEliminarEstadia_Click(object sender, EventArgs e)
        {
            EliminarEstadia ee = new EliminarEstadia();
            AbrirForm(ee);//ABRE EL FORM
        }

        private void btAgregarReserva_Click(object sender, EventArgs e)
        {
            AgregarReservas ar = new AgregarReservas();
            AbrirForm(ar);//ABRE EL FORM
        }

        private void btModificarReserva_Click(object sender, EventArgs e)
        {
            ModificarReservas mr = new ModificarReservas();
            AbrirForm(mr);//ABRE EL FORM
        }

        private void btEliminarReserva_Click(object sender, EventArgs e)
        {
            EliminarReservas er = new EliminarReservas();
            AbrirForm(er);//ABRE EL FORM
        }

        private void btAgregarGasto_Click(object sender, EventArgs e)
        {
            AgregarGastos ag = new AgregarGastos();
            AbrirForm(ag);//ABRE EL FORM
        }

        private void btModificarGasto_Click(object sender, EventArgs e)
        {
            ModificarGastos mg = new ModificarGastos();
            AbrirForm(mg);//ABRE EL FORM
        }

        private void btEliminarGasto_Click(object sender, EventArgs e)
        {
            EliminarGastos eg = new EliminarGastos();
            AbrirForm(eg);//ABRE EL FORM
        }

        private void btInicio_Click(object sender, EventArgs e)
        {
            //if (inicio == null)
            //{
            //    inicio = new Inicio();
            //    inicio.FormClosed += Inicio_FormClosed;
            //    inicio.MdiParent = this;
            //    inicio.Show();
            //}
            //else
            //{
            //    inicio.Activate();
            //}
            Inicio i = new Inicio();
            AbrirForm(i);
        }

        private void Inicio_FormClosed(object sender, FormClosedEventArgs e)
        {
            inicio = null;
        }

        private void btSalirr_Click(object sender, EventArgs e)//SALIR DEL PROGRAMA
        {
            //LLAMAR A FORM CLOSING
            this.Close();
        }

        private void btGestiónUsuarios_Click(object sender, EventArgs e)
        {


        }

        bool PanelExpandir = false;
        private void panelMenuTransition_Tick(object sender, EventArgs e)
        {
            if (PanelExpandir)
            {
                panelPrincipal.Width -= 5;
                if (panelPrincipal.Width <= 79)
                {
                    PanelExpandir = false;
                    panelMenuTransition.Stop();
                    panelClientes.Width = panelPrincipal.Width;
                    panelHabitaciones.Width = panelPrincipal.Width;
                    panelEstadias.Width = panelPrincipal.Width;
                    panelReservas.Width = panelPrincipal.Width;
                    panelCuentaCliente.Width = panelPrincipal.Width;

                }
            }
            else
            {
                panelPrincipal.Width += 5;
                if (panelPrincipal.Width >= 282)
                {
                    PanelExpandir = true;
                    panelMenuTransition.Stop();
                    panelClientes.Width = panelPrincipal.Width;
                    panelHabitaciones.Width = panelPrincipal.Width;
                    panelEstadias.Width = panelPrincipal.Width;
                    panelReservas.Width = panelPrincipal.Width;
                    panelCuentaCliente.Width = panelPrincipal.Width;

                }
            }
        }

        private void btMenuPanel_Click(object sender, EventArgs e)
        {
            panelMenuTransition.Start();
        }

        private void menuTransitionUsuarios_Tick(object sender, EventArgs e)
        {

        }

        private void Principal_FormClosing(object sender, FormClosingEventArgs e)//MENSAJE PARA CERRAR EL FORM DESDE LA X
        {
            ////AGREGAR UN MESSAGE BOX DE SI ESTA SEGURO QUE QUIERE SALIR?
            DialogResult resultado = new DialogResult();
            resultado = MessageBox.Show("¿Esta seguro de querer Salir?", "Aviso Importante", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultado == DialogResult.No)
            {
                e.Cancel = true;
                
            }
            
        }
    }
}
