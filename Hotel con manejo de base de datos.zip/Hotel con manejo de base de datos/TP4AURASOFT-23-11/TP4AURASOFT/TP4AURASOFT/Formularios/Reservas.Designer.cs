﻿namespace TP4AURASOFT.Formularios
{
    partial class Reservas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reservas));
            dtReservas = new DataGridView();
            idReservaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            fechaReservaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            fechaEntradaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            fechaSalidaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            cantidadDePersonasDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            habitacionDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            reservaBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)dtReservas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)reservaBindingSource).BeginInit();
            SuspendLayout();
            // 
            // dtReservas
            // 
            dtReservas.Anchor = AnchorStyles.None;
            dtReservas.AutoGenerateColumns = false;
            dtReservas.BackgroundColor = SystemColors.ButtonHighlight;
            dtReservas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dtReservas.Columns.AddRange(new DataGridViewColumn[] { idReservaDataGridViewTextBoxColumn, fechaReservaDataGridViewTextBoxColumn, fechaEntradaDataGridViewTextBoxColumn, fechaSalidaDataGridViewTextBoxColumn, cantidadDePersonasDataGridViewTextBoxColumn, habitacionDataGridViewTextBoxColumn });
            dtReservas.DataSource = reservaBindingSource;
            dtReservas.Location = new Point(110, 84);
            dtReservas.Name = "dtReservas";
            dtReservas.RowHeadersWidth = 51;
            dtReservas.RowTemplate.Height = 29;
            dtReservas.Size = new Size(578, 339);
            dtReservas.TabIndex = 14;
            dtReservas.CellContentClick += dtReservas_CellContentClick;
            // 
            // idReservaDataGridViewTextBoxColumn
            // 
            idReservaDataGridViewTextBoxColumn.DataPropertyName = "IdReserva";
            idReservaDataGridViewTextBoxColumn.HeaderText = "IdReserva";
            idReservaDataGridViewTextBoxColumn.MinimumWidth = 6;
            idReservaDataGridViewTextBoxColumn.Name = "idReservaDataGridViewTextBoxColumn";
            idReservaDataGridViewTextBoxColumn.Width = 125;
            // 
            // fechaReservaDataGridViewTextBoxColumn
            // 
            fechaReservaDataGridViewTextBoxColumn.DataPropertyName = "FechaReserva";
            fechaReservaDataGridViewTextBoxColumn.HeaderText = "FechaReserva";
            fechaReservaDataGridViewTextBoxColumn.MinimumWidth = 6;
            fechaReservaDataGridViewTextBoxColumn.Name = "fechaReservaDataGridViewTextBoxColumn";
            fechaReservaDataGridViewTextBoxColumn.Width = 125;
            // 
            // fechaEntradaDataGridViewTextBoxColumn
            // 
            fechaEntradaDataGridViewTextBoxColumn.DataPropertyName = "FechaEntrada";
            fechaEntradaDataGridViewTextBoxColumn.HeaderText = "FechaEntrada";
            fechaEntradaDataGridViewTextBoxColumn.MinimumWidth = 6;
            fechaEntradaDataGridViewTextBoxColumn.Name = "fechaEntradaDataGridViewTextBoxColumn";
            fechaEntradaDataGridViewTextBoxColumn.Width = 125;
            // 
            // fechaSalidaDataGridViewTextBoxColumn
            // 
            fechaSalidaDataGridViewTextBoxColumn.DataPropertyName = "FechaSalida";
            fechaSalidaDataGridViewTextBoxColumn.HeaderText = "FechaSalida";
            fechaSalidaDataGridViewTextBoxColumn.MinimumWidth = 6;
            fechaSalidaDataGridViewTextBoxColumn.Name = "fechaSalidaDataGridViewTextBoxColumn";
            fechaSalidaDataGridViewTextBoxColumn.Width = 125;
            // 
            // cantidadDePersonasDataGridViewTextBoxColumn
            // 
            cantidadDePersonasDataGridViewTextBoxColumn.DataPropertyName = "CantidadDePersonas";
            cantidadDePersonasDataGridViewTextBoxColumn.HeaderText = "CantidadDePersonas";
            cantidadDePersonasDataGridViewTextBoxColumn.MinimumWidth = 6;
            cantidadDePersonasDataGridViewTextBoxColumn.Name = "cantidadDePersonasDataGridViewTextBoxColumn";
            cantidadDePersonasDataGridViewTextBoxColumn.Width = 125;
            // 
            // habitacionDataGridViewTextBoxColumn
            // 
            habitacionDataGridViewTextBoxColumn.DataPropertyName = "Habitacion";
            habitacionDataGridViewTextBoxColumn.HeaderText = "Habitacion";
            habitacionDataGridViewTextBoxColumn.MinimumWidth = 6;
            habitacionDataGridViewTextBoxColumn.Name = "habitacionDataGridViewTextBoxColumn";
            habitacionDataGridViewTextBoxColumn.Width = 125;
            // 
            // reservaBindingSource
            // 
            reservaBindingSource.DataSource = typeof(Entidades.Reserva);
            // 
            // Reservas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(dtReservas);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "Reservas";
            Text = "Reservas";
            ((System.ComponentModel.ISupportInitialize)dtReservas).EndInit();
            ((System.ComponentModel.ISupportInitialize)reservaBindingSource).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private DataGridView dtReservas;
        private DataGridViewTextBoxColumn idReservaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn fechaReservaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn fechaEntradaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn fechaSalidaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn cantidadDePersonasDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn habitacionDataGridViewTextBoxColumn;
        private BindingSource reservaBindingSource;
    }
}