﻿namespace AURASOFT_DESIGN_TP4
{
    partial class Login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            tbUsuario = new TextBox();
            tbContraseña = new TextBox();
            Usuario = new Label();
            Contraseña = new Label();
            btLogin = new Button();
            SuspendLayout();
            // 
            // tbUsuario
            // 
            tbUsuario.Anchor = AnchorStyles.None;
            tbUsuario.Location = new Point(297, 215);
            tbUsuario.Name = "tbUsuario";
            tbUsuario.Size = new Size(225, 27);
            tbUsuario.TabIndex = 0;
            // 
            // tbContraseña
            // 
            tbContraseña.Anchor = AnchorStyles.None;
            tbContraseña.Location = new Point(297, 276);
            tbContraseña.Name = "tbContraseña";
            tbContraseña.Size = new Size(225, 27);
            tbContraseña.TabIndex = 1;
            tbContraseña.TextChanged += tbContraseña_TextChanged;
            // 
            // Usuario
            // 
            Usuario.Anchor = AnchorStyles.None;
            Usuario.AutoSize = true;
            Usuario.BackColor = SystemColors.ButtonHighlight;
            Usuario.Location = new Point(223, 218);
            Usuario.Name = "Usuario";
            Usuario.Size = new Size(59, 20);
            Usuario.TabIndex = 2;
            Usuario.Text = "Usuario";
            // 
            // Contraseña
            // 
            Contraseña.Anchor = AnchorStyles.None;
            Contraseña.AutoSize = true;
            Contraseña.BackColor = SystemColors.ButtonHighlight;
            Contraseña.Location = new Point(199, 279);
            Contraseña.Name = "Contraseña";
            Contraseña.Size = new Size(83, 20);
            Contraseña.TabIndex = 3;
            Contraseña.Text = "Contraseña";
            // 
            // btLogin
            // 
            btLogin.Anchor = AnchorStyles.None;
            btLogin.BackColor = SystemColors.InactiveCaption;
            btLogin.FlatAppearance.BorderColor = Color.FromArgb(255, 255, 192);
            btLogin.FlatAppearance.BorderSize = 14;
            btLogin.FlatStyle = FlatStyle.Popup;
            btLogin.Location = new Point(347, 326);
            btLogin.Name = "btLogin";
            btLogin.Size = new Size(122, 29);
            btLogin.TabIndex = 4;
            btLogin.Text = "Iniciar Sesión";
            btLogin.UseVisualStyleBackColor = false;
            btLogin.Click += btLogin_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(btLogin);
            Controls.Add(Contraseña);
            Controls.Add(Usuario);
            Controls.Add(tbContraseña);
            Controls.Add(tbUsuario);
            Name = "Login";
            Text = "Login AURASOFT";
            Load += Login_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox tbUsuario;
        private TextBox tbContraseña;
        private Label Usuario;
        private Label Contraseña;
        private Button btLogin;
    }
}