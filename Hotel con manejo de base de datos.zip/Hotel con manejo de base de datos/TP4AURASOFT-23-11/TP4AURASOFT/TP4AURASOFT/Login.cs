using AURASOFT_DESIGN_TP4.Formularios;
using TP4AURASOFT.Controladores;
using TP4AURASOFT.Entidades;
using TP4AURASOFT;

namespace AURASOFT_DESIGN_TP4
{
    public partial class Login : Form
    {

        public Login()
        {
            InitializeComponent();
            tbUsuario.Focus();
        }

        private void btLogin_Click(object sender, EventArgs e)
        {
            //Usuario usuario = pUsuario.GetByUsername(tbUsuario.Text);
            //if (usuario.Nombre == null)
            //{
            //    MessageBox.Show("El usuario no existe!!!");
            //    tbUsuario.Focus();
            //}
            //else
            //{
            //    if (usuario.Password == TP4AURASOFT.Controladores.nVarios.CreateMD5(tbContraseña.Text))
            //    {
            //        Program.loginOk = true;
            //        Close();
            //    }
            //    else
            //    {
            //        Program.loginOk = false;
            //        MessageBox.Show("Clave incorrecta");
            //        tbContraseña.Focus();
            //    }
            //}
            Form formularioA = new Principal();
            formularioA.Show();
            //AGREGAR EL CONTROL DE USUARIO Y CONTRASE�A
            //Y QUE SE CIERRE LA VENTANA AL INICIAR SESI�N
            this.Hide();
        }

        private void tbContraseña_TextChanged(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {



















        }
    }
}