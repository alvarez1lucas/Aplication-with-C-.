using AURASOFT_DESIGN_TP4;
using TP4AURASOFT.Formularios;

namespace TP4AURASOFT
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        /// 
        public static bool loginOk;
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Controladores.Conexion.OpenConnection();
            loginOk = true;
            if (loginOk)
            {
                Application.Run(new Login());
            }
            
            Controladores.Conexion.CloseConnection();
        }
    }
}