﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_parcial
{
    public class Cliente
    {
        public string Nombre { get; set; }
        public List<Linea> Lineas { get; set; }

        public Cliente(string nombre)
        {
            Nombre = nombre;
            Lineas = new List<Linea>();
        }
    }
}
