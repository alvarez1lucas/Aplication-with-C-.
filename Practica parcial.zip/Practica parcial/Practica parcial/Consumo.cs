﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_parcial
{
    public enum TipoConsumo
    {
        Llamada,
        MensajeTexto
    }
    public class Consumo
    {
        
        
            public TipoConsumo Tipo { get; set; }
            public DateTime Fecha { get; set; }
            public double Duracion { get; set; } // En segundos para llamadas, Cantidad para mensajes de texto

            public Consumo(TipoConsumo tipo, DateTime fecha, double duracion)
            {
                Tipo = tipo;
                Fecha = fecha;
                Duracion = duracion;
            }
        
    }
}
