﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_parcial
{
    public class Linea
    {
        public string Numero { get; set; }
        public Cliente Cliente { get; set; }
        public List<Consumo> Consumos { get; set; }

        public Linea(string numero, Cliente cliente)
        {
            Numero = numero;
            Cliente = cliente;
            Consumos = new List<Consumo>();
        }
    }
}
