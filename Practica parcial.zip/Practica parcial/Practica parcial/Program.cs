﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Cliente
{
    public string Nombre { get; set; }
    public List<Linea> Lineas { get; set; }

    public Cliente(string nombre)
    {
        Nombre = nombre;
        Lineas = new List<Linea>();
    }
}

public class Linea
{
    public string Numero { get; set; }
    public Cliente Cliente { get; set; }
    public List<Consumo> Consumos { get; set; }

    public Linea(string numero, Cliente cliente)
    {
        Numero = numero;
        Cliente = cliente;
        Consumos = new List<Consumo>();
    }
}

public enum TipoConsumo
{
    Llamada,
    MensajeTexto
}

public class Consumo
{
    public TipoConsumo Tipo { get; set; }
    public DateTime Fecha { get; set; }
    public double Duracion { get; set; }
    public Linea Linea { get; set; } // Agregar referencia a la línea

    public Consumo(TipoConsumo tipo, DateTime fecha, double duracion, Linea linea)
    {
        Tipo = tipo;
        Fecha = fecha;
        Duracion = duracion;
        Linea = linea;
    }
}

class Program
{
    static void Main(string[] args)
    {
        var clientes = new List<Cliente>
        {
            new Cliente("Cliente1"),
            new Cliente("Cliente2"),
        };

        var cliente1 = clientes[0];
        var cliente2 = clientes[1];

        cliente1.Lineas.Add(new Linea("1111", cliente1));
        cliente2.Lineas.Add(new Linea("2222", cliente2));

        var fechaActual = DateTime.Now;
        

        var consumos = new List<Consumo>
        {
            new Consumo(TipoConsumo.Llamada, fechaActual, 120, cliente1.Lineas[0]),
            new Consumo(TipoConsumo.Llamada, fechaActual, 180, cliente1.Lineas[0]),
            new Consumo(TipoConsumo.MensajeTexto, fechaActual, 5, cliente1.Lineas[0]),
        };

        cliente1.Lineas[0].Consumos.AddRange(consumos);

        while (true)
        {
            Console.WriteLine("Menú de opciones:");
            Console.WriteLine("1. Listar los clientes ordenados por monto de la factura");
            Console.WriteLine("2. Listar los consumos de un cliente en particular ordenados por fecha");
            Console.WriteLine("3. Listar las líneas de un cliente en particular con detalles");
            Console.WriteLine("4. Listar las primeras 10 llamadas más largas");
            Console.WriteLine("5. Salir");

            Console.Write("Ingrese el número de opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    ListarClientesPorFactura(clientes);
                    break;
                case "2":
                    ListarConsumosPorFecha(cliente1);
                    break;
                case "3":
                    ListarLineasConDetalles(cliente1);
                    break;
                case "4":
                    ListarLlamadasMasLargas(consumos);
                    break;
                case "5":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                    break;
            }
        }
    }

    static void ListarClientesPorFactura(List<Cliente> clientes)
    {
        var clientesOrdenadosPorFactura = clientes.OrderByDescending(cliente =>
        {
            double facturaTotal = cliente.Lineas.Sum(linea =>
            {
                double totalConsumo = linea.Consumos.Sum(consumo =>
                {
                    if (consumo.Tipo == TipoConsumo.Llamada)
                    {
                        return consumo.Duracion * 0.08; // Costo por segundo de llamada
                    }
                    else
                    {
                        return consumo.Duracion * 0.95; // Costo por mensaje de texto
                    }
                });
                return totalConsumo;
            });
            return facturaTotal;
        });

        Console.WriteLine("Clientes ordenados por monto de la factura:");
        foreach (var cliente in clientesOrdenadosPorFactura)
        {
            Console.WriteLine($"{cliente.Nombre}: ${cliente.Lineas.Sum(linea => linea.Consumos.Sum(consumo => CalcularCostoConsumo(consumo)))}");
        }
    }

    static void ListarConsumosPorFecha(Cliente cliente)
    {
        var consumosOrdenadosPorFecha = cliente.Lineas
            .SelectMany(linea => linea.Consumos)
            .OrderBy(consumo => consumo.Fecha);

        Console.WriteLine($"\nConsumos del cliente {cliente.Nombre} ordenados por fecha:");
        foreach (var consumo in consumosOrdenadosPorFecha)
        {
            Console.WriteLine($"{consumo.Fecha}: {consumo.Tipo}, Duración: {consumo.Duracion}");
        }
    }

    static void ListarLineasConDetalles(Cliente cliente)
    {
        Console.WriteLine($"\nDetalles de las líneas del cliente {cliente.Nombre}:");
        foreach (Linea linea in cliente.Lineas)
        {
            double facturaLinea = linea.Consumos.Sum(consumo => CalcularCostoConsumo(consumo));

            Console.WriteLine($"Linea: {linea.Numero}");
            Console.WriteLine($"Tiempo de llamada: {linea.Consumos.Where(consumo => consumo.Tipo == TipoConsumo.Llamada).Sum(consumo => consumo.Duracion)} segundos");
            Console.WriteLine($"Cantidad de mensajes de texto: {linea.Consumos.Where(consumo => consumo.Tipo == TipoConsumo.MensajeTexto).Sum(consumo => consumo.Duracion)}");
            Console.WriteLine($"Monto de la factura: ${facturaLinea}");
        }
    }

    static void ListarLlamadasMasLargas(List<Consumo> consumos)
    {
        var llamadasMasLargas = consumos.Where(consumo => consumo.Tipo == TipoConsumo.Llamada)
            .OrderByDescending(consumo => consumo.Duracion)
            .Take(10);

        Console.WriteLine("\nLas 10 llamadas más largas:");
        foreach (var llamada in llamadasMasLargas)
        {
            if (llamada.Linea != null && llamada.Linea.Cliente != null)
            {
                Console.WriteLine($"Cliente: {llamada.Linea.Cliente.Nombre}, Línea: {llamada.Linea.Numero}");
                Console.WriteLine($"Duración de la llamada: {llamada.Duracion} segundos");
            }
            else
            {
                Console.WriteLine("Error: Llamada sin línea o cliente asociado.");
            }
        }
    }

    static double CalcularCostoConsumo(Consumo consumo)
    {
        if (consumo.Tipo == TipoConsumo.Llamada)
        {
            return consumo.Duracion * 0.08; // Costo por segundo de llamada
        }
        else
        {
            return consumo.Duracion * 0.95; // Costo por mensaje de texto
        }
    }
}