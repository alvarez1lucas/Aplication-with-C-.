﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrabajoPractico2AURASOFT.Entidades;
using LibreriaAURASOFT;

namespace TrabajoPractico2AURASOFT.Controladores
{
    internal class nPlayaEstacionamiento
    {
        public static void Crear()
        {
            Console.WriteLine("Creando playa de estacionamiento...");

            Console.Write("Ingrese el nombre de la playa: ");
            string nombre = Herramientas.StringNoNulo();

            Console.Write("Ingrese la cantidad de filas: ");
            int filas = Herramientas.IngresoEntero();

            Console.Write("Ingrese la cantidad de columnas: ");
            int columnas = Herramientas.IngresoEntero();

            Console.Write("Ingrese el valor por hora de estacionamiento: ");
            double valorPorHora = Herramientas.IngresoDouble();

            PlayaEstacionamiento playa = new PlayaEstacionamiento(nombre, filas, columnas, valorPorHora);
            Program.playas.Add(playa);
            Console.WriteLine("Playa creada exitosamente.");
            Console.ReadKey(true);
        }

        public static void Imprimir()
        {
            string[] nombres = new string[Program.playas.Count];

            for (int i = 0; i < Program.playas.Count; i++)
            {
                nombres[i] = Program.playas[i].Nombre;
            }

            Herramientas.DibujarMenu("Playas", nombres);
        }

        public static int Seleccionar()
        {
            Console.WriteLine();
            Imprimir();
            Console.Write("Seleccione una playa: ");
            int s = Herramientas.IngresoEntero(1, Program.playas.Count);
            return s - 1;
        }

        public static void Eliminar()
        {
            int i = Seleccionar();
            Program.playas.RemoveAt(i);
        }

        public static void Modificar(int i)
        {
            Console.WriteLine();
            Console.Write("Ingrese nuevo nombre para {0}: ", Program.playas[i].Nombre);
            Program.playas[i].Nombre = Herramientas.StringNoNulo();
            Console.WriteLine();
            Console.Write("Ingrese nuevo número de filas para {0}: ", Program.playas[i].Filas);
            Program.playas[i].Filas = Herramientas.IngresoEntero();
            Console.WriteLine();
            Console.Write("Ingrese nueva cantidad de columnas para {0}: ", Program.playas[i].Columnas);
            Program.playas[i].Columnas = Herramientas.IngresoEntero();
            Console.WriteLine();
            Console.Write("Ingrese un nuevo Valor por Hora para {0}: ", Program.playas[i].ValorPorHora);
            Program.playas[i].ValorPorHora = Herramientas.IngresoDouble();
            Console.WriteLine();

        }

        public static void DibujoPlaya()
        {
            int p = Seleccionar();
            PlayaEstacionamiento playa = Program.playas[p];
            Console.Clear();
            DibujarPlaya(playa.Lugares);
            Console.ReadKey(true);
        }

        public static void ImprimirInforme()
        {
            int p = Seleccionar();
            PlayaEstacionamiento playa = Program.playas[p];
            Console.Clear();
            ImprimirTablaInforme(playa.Informe);
            Console.ReadKey(true);
        }

        public static void Menu()
        {
            string[] opciones = new string[] { "Crear", "Modificar", "Eliminar", "Listar", "Importar", "Dibujar", "Imprimir informe", "Mostrar recaudación", "Mostrar Playas por lugares libres " ,"Volver" };
            Console.Clear();
            Herramientas.DibujarMenu("Playas de estacionamiento", opciones);
            Console.Write("Seleccione Opción: ");
            int seleccion = Herramientas.IngresoEntero(1, 9); // Ajusta el rango para incluir la nueva opción
            Console.WriteLine();
            switch (seleccion)
            {
                case 1: Crear(); Menu(); break;
                case 2: Modificar(Seleccionar()); Menu(); break;
                case 3:
                    if (Program.playas.Count > 0)
                    { Eliminar(); }
                    else
                    {
                        Console.WriteLine("No existen datos a eliminar"); Console.ReadKey(true);
                    }; Menu(); break;
                case 4: ListarCantidadPlayas(); Console.ReadKey(); Menu(); break;
                case 5: ImportarPlayasDesdeArchivo(); Menu(); break;
                case 6: DibujoPlaya(); Menu(); break;
                case 7: ImprimirInforme(); Menu(); break;
                case 8: OrdenarXPlayas(); Menu(); break;
                case 9: OrdenarPlayasPorLugaresLibres(); Menu(); break;
                case 10: break;
            }
        }

        public static void ListarCantidadPlayas() 
        {
            OrdenarXPlayas();
            Console.WriteLine("Listando playas de estacionamiento...");

            ListaPlayasTabla(Program.playas); // Cambiar Program.playas por la lista de playas ordenadas

            Console.WriteLine();
            Console.WriteLine("Desea Imprimir el listado en un archivo txt?");
            Console.WriteLine("1.Si");
            Console.WriteLine("2.No");
            int var = Herramientas.IngresoEntero(1, 2);
            if(var == 1)
            {
                using (StreamWriter Escribe = new StreamWriter("InfomePlayas.txt", true))
                {
                    foreach (PlayaEstacionamiento playa in Program.playas)
                    {
                        Escribe.WriteLine($"Nombre: {playa.Nombre}");
                        Escribe.WriteLine($"Filas: {playa.Filas}");
                        Escribe.WriteLine($"Columnas: {playa.Columnas}");
                        //Escribe.WriteLine($"Autos por fila: {playa.AutosPorFila}");
                        //Escribe.WriteLine($"Autos por columna: {playa.AutosPorColumna}");
                        Escribe.WriteLine($"Valor por hora: {playa.ValorPorHora}");
                        Escribe.WriteLine();
                    }
                    Console.WriteLine("El informe ha sido guardado");
                }
            }
            else
            {
                Console.WriteLine("No se ha impreso el informe"); Console.ReadKey(true);
            }

        }
        //Alvarez
        public static double IterarRecaudacion(PlayaEstacionamiento playa)
        {
            double recaudacion = 0;
            foreach (Vehiculo vehiculo in playa.Informe)
            {
                if (vehiculo.Cobro_Realizado.HasValue)
                {
                    recaudacion += vehiculo.Cobro_Realizado.Value;
                }
            }
            return recaudacion;
        }

        public static void OrdenarXPlayas()
        {
            var playasOrdenadas = Program.playas.OrderByDescending(playa => IterarRecaudacion(playa));

            Console.WriteLine("Playas ordenadas por recaudación (de mayor a menor):");

            foreach (var playa in playasOrdenadas)
            {
                double recaudacion = IterarRecaudacion(playa);
                Console.WriteLine($"Playa: {playa.Nombre}, Recaudación: ${recaudacion}");
            }

            Console.ReadKey(true);
        }


        public static int CalcularLugaresLibres(PlayaEstacionamiento playa)
        {
            int lugaresLibres = 0;
            for (int i = 0; i < playa.Lugares.GetLength(0); i++)
            {
                for (int j = 0; j < playa.Lugares.GetLength(1); j++)
                {
                    if (playa.Lugares[i, j] == null)
                    {
                        lugaresLibres++;
                    }
                }
            }
            return lugaresLibres;
        }
        public static void OrdenarPlayasPorLugaresLibres()
        {
            var playasOrdenadas = Program.playas.OrderByDescending(playa => CalcularLugaresLibres(playa));

            Console.WriteLine("Playas ordenadas por lugares libres (de mayor a menor):");

            foreach (var playa in playasOrdenadas)
            {
                int lugaresLibres = CalcularLugaresLibres(playa);
                Console.WriteLine($"Playa: {playa.Nombre}, Lugares Libres: {lugaresLibres}");
            }

            Console.ReadKey(true);
        }

        // Función que devuelve true si hay lugares libres y false si no.
        public static bool CheckLugares(int playa)
        {
            // Se ingresa a la lista de playas y se busca la playa específica
            // a través de su índice, pasado como parámetro.

            for (int i = 0; i < Program.playas[playa].Lugares.GetLength(0); i++)
            {
                for (int j = 0; j < Program.playas[playa].Lugares.GetLength(1); j++)
                {
                    // Si la playa tiene un lugar vacío, el método devuelve true.

                    if (Program.playas[playa].Lugares[i, j] == null)
                    {
                        return true;
                    }
                }
            }

            // Si no hay lugares, el método devuelve false
            return false;
        }

        // Función para ingresar el vehículo en la primera posición libre encontrada
        // en la playa elegida. Misma lógica que CheckLugares, solo que en este caso se le
        // pasa como parámetro también un vehículo y este se guarda en la matriz Lugares.
        public static void EstacionarVehiculo(PlayaEstacionamiento playa, Vehiculo v)
        {
            for (int i = 0; i < playa.Lugares.GetLength(0); i++)
            {
                for (int j = 0; j < playa.Lugares.GetLength(1); j++)
                {
                    if (playa.Lugares[i, j] == null)
                    {
                        playa.Lugares[i, j] = v;
                        return;
                    }
                }
            }
        }

        public static void AgregarVehiculoAlinforme(PlayaEstacionamiento playa, Vehiculo v)
        {
            playa.Informe.Add(v);
        }

        public static void QuitarVehiculo(PlayaEstacionamiento playa, Vehiculo v)
        {
            for (int i = 0; i < playa.Lugares.GetLength(0); i++)
            {
                for (int j = 0; j < playa.Lugares.GetLength(1); j++)
                {
                    if (playa.Lugares[i, j] != null && playa.Lugares[i, j].Patente == v.Patente)
                    {
                        playa.Lugares[i, j] = null;
                        return;
                    }
                }
            }
        }

        public static void ImportarPlayasDesdeArchivo()
        {

        }

        public static void DibujarPlaya(Vehiculo[,] playa)
        {
            // Caracteres a usar
            char lineaVertical = '│';
            char lineaHorizontal = '─';
            char empalmeSupVertical = '┬';
            char empalmeInfVertical = '┴';
            char esquinaSupIzq = '┌';
            char esquinaSupDer = '┐';
            char esquinaInfIzq = '└';
            char esquinaInfDer = '┘';
            char cruce = '┼';
            char empalmeIzq = '├';
            char empalmeDer = '┤';
            char bloque = '█';

            int anchoCol = 2;

            string lugarVacio = new string(' ', anchoCol); // Cuando el lugar está vacío, se usa este string
            string lugarOcupado = new string(bloque, anchoCol); // Lo contrario para este
            string bordeSuperior = ""; // Acumula los caracteres que forman el borde superior 
            string pasillo = new string(' ', (anchoCol + 1) * playa.GetLength(1) - 1); // Espacio vacio para separar dos filas
            string bordeInterior = ""; // Acumula los caracteres del borde que separa dos filas
            string bordeInferior = ""; // Acumula los caracteres del borde inferior
            string bordeInfPared = new string(lineaHorizontal, (anchoCol + 1) * playa.GetLength(1) - 1); // Borde formado para cuando la playa termina en un espacio o pasillo

            for (int i = 0; i < playa.GetLength(1); i++)
            {
                // Formar los bordes según el ancho de la matriz dada
                if (i == playa.GetLength(1) - 1)
                {
                    bordeSuperior += new string(lineaHorizontal, anchoCol);
                    bordeInterior += new string(lineaHorizontal, anchoCol);
                    bordeInferior += new string(lineaHorizontal, anchoCol);
                }

                else
                {
                    // Si no es la última columna, se suman los caracteres correspondientes.
                    bordeSuperior += new string(lineaHorizontal, anchoCol) + empalmeSupVertical;
                    bordeInterior += new string(lineaHorizontal, anchoCol) + cruce;
                    bordeInferior += new string(lineaHorizontal, anchoCol) + empalmeInfVertical;
                }
            }

            // Se terminan de formar los strings con sus esquinas correspondientes 
            bordeSuperior = esquinaSupIzq + bordeSuperior + esquinaSupDer;
            pasillo = lineaVertical + pasillo + lineaVertical;
            bordeInterior = empalmeIzq + bordeInterior + empalmeDer;
            bordeInferior = esquinaInfIzq + bordeInferior + esquinaInfDer;
            bordeInfPared = esquinaInfIzq + bordeInfPared + esquinaInfDer;

            Console.SetCursorPosition(2, 1);
            Console.WriteLine(bordeSuperior);

            for (int i = 0; i < playa.GetLength(0); i++)
            {
                for (int j = 0; j < playa.GetLength(1); j++)
                {
                    if (j == 0)
                    {
                        // Si es la primera columna, se escribe el caracter correspondiente
                        Console.CursorLeft = 2;
                        Console.Write(lineaVertical);
                    }
                    if (playa[i, j] == null)
                    {
                        // Si estamos en un lugar vacío, se escriben los caracteres correspondientes
                        Console.Write(lugarVacio + lineaVertical);
                    }

                    else
                    {
                        // Si estamos en un lugar ocupado, se escriben los caracteres correspondientes
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write(lugarOcupado);
                        Console.ResetColor();
                        Console.Write(lineaVertical);
                    }

                    if (j == playa.GetLength(1) - 1)
                    {
                        // Si estamos en la última columna...
                        Console.WriteLine();
                        Console.CursorLeft = 2;

                        if (i == 0 || i % 2 == 0)
                        {
                            // Si la fila es 0 o par
                            Console.Write(pasillo);

                            if (i == playa.GetLength(0) - 1)
                            {
                                // Y si ya estamos en la última fila
                                Console.WriteLine();
                                Console.CursorLeft = 2;
                                Console.Write(bordeInfPared);
                            }
                        }

                        else
                        {
                            // Si la fila no es par 
                            if (i == playa.GetLength(0) - 1)
                            {
                                // Y si ya estamos en la última fila 
                                Console.Write(bordeInferior);
                            }
                            else
                            {
                                Console.Write(bordeInterior);
                            }
                        }

                        Console.WriteLine();
                    }
                }
            }

        }

        public static void ImprimirTablaInforme(List<Vehiculo> vehiculos)
        {
            // Caracteres para los bordes de la tabla
            char bordeHorizontalExt = '═';
            char bordeVerticalExt = '║';
            char esquinaSuperiorIzq = '╔';
            char esquinaSuperiorDer = '╗';
            char esquinaInferiorIzq = '╚';
            char esquinaInferiorDer = '╝';
            char bordeHorizontalInt = '─';
            char bordeVerticalInt = '│';
            char bordeIzq = '╟';
            char bordeDer = '╢';
            char bordeVerticalSup = '╤';
            char bordeVerticalInf = '╧';
            char cruce = '┼';

            // Obtener el ancho de cada columna basado en la longitud de las propiedades
            int[] anchosColumnas = new int[]
            {
                vehiculos.Any() ? vehiculos.Max(v => v.Marca.Length) : 0,
                vehiculos.Any() ? vehiculos.Max(v => v.Modelo.Length) : 0,
                vehiculos.Any() ? vehiculos.Max(v => v.Patente.Length) : 0,
                vehiculos.Any() ? vehiculos.Max(v => v.HoraEntrada.ToString("HH:mm").Length) : 0,
                vehiculos.Any() ? vehiculos.Max(v => (v.HoraSalida?.ToString("HH:mm") ?? "").Length) : 0,
                vehiculos.Any() ? vehiculos.Max(v => v.Cobro_Realizado.ToString().Length) : 0
            };

            string[] titulos = new string[] { "Marca", "Modelo", "Patente", "Hora Entrada", "Hora Salida", "Cobro Realizado" };

            for (int i = 0; i < anchosColumnas.Length; i++)
            {
                if (titulos[i].Length > anchosColumnas[i])
                {
                    anchosColumnas[i] = titulos[i].Length;
                }
            }


            string columnasExt = "";
            string columnasInt = "";
            string columnasExt2 = "";

            // Calcular las líneas de separación y bordes en función de los anchos de columna
            for (int i = 0; i < anchosColumnas.Length; i++)
            {
                if (i == anchosColumnas.Length - 1)
                {
                    columnasInt += new string(bordeHorizontalInt, anchosColumnas[i]);
                    columnasExt += new string(bordeHorizontalExt, anchosColumnas[i]);
                    columnasExt2 += new string(bordeHorizontalExt, anchosColumnas[i]);
                }
                else
                {
                    columnasExt += new string(bordeHorizontalExt, anchosColumnas[i]) + bordeVerticalSup;
                    columnasInt += new string(bordeHorizontalInt, anchosColumnas[i]) + cruce;
                    columnasExt2 += new string(bordeHorizontalExt, anchosColumnas[i]) + bordeVerticalInf;
                }
            }

            // Línea superior de la tabla
            string bordeSuperior = esquinaSuperiorIzq + columnasExt + esquinaSuperiorDer;

            // Línea de separación interna
            string bordeInterior = bordeIzq + columnasInt + bordeDer;

            // Dibujar borde superior
            Console.SetCursorPosition(2, Console.CursorTop);
            Console.WriteLine(bordeSuperior);

            // Imprimir los nombres de las columnas en rojo
            Console.CursorLeft = 2;
            Console.Write(bordeVerticalExt);
            for (int i = 0; i < titulos.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.Red; // Cambio de color a rojo
                Console.Write(titulos[i].PadRight(anchosColumnas[i]));
                Console.ResetColor(); // Restablecer el color a su valor predeterminado
                if (i < titulos.Length - 1)
                {
                    Console.Write(bordeVerticalInt);
                }
            }
            Console.Write(bordeVerticalExt);
            Console.WriteLine();
            Console.CursorLeft = 2;
            Console.WriteLine(bordeInterior);

            // Imprimir los datos de los vehículos
            for (int i = 0; i < vehiculos.Count; i++)
            {
                Console.CursorLeft = 2;
                Console.Write(bordeVerticalExt);
                Console.Write(vehiculos[i].Marca.PadRight(anchosColumnas[0]));
                Console.Write(bordeVerticalInt);

                Console.Write(vehiculos[i].Modelo.PadRight(anchosColumnas[1]));
                Console.Write(bordeVerticalInt);

                Console.Write(vehiculos[i].Patente.PadRight(anchosColumnas[2]));
                Console.Write(bordeVerticalInt);

                Console.Write(vehiculos[i].HoraEntrada.ToString("HH:mm").PadRight(anchosColumnas[3]));
                Console.Write(bordeVerticalInt);

                Console.Write(vehiculos[i].HoraSalida?.ToString("HH:mm").PadRight(anchosColumnas[4]));
                Console.Write(bordeVerticalInt);

                Console.Write($"${vehiculos[i].Cobro_Realizado.ToString().PadRight(anchosColumnas[5] - 1)}");
                Console.Write(bordeVerticalExt);

                if (i < vehiculos.Count - 1)
                {
                    Console.WriteLine();
                    Console.CursorLeft = 2;
                    Console.WriteLine(bordeInterior);
                }
                else
                {
                    Console.WriteLine();
                    Console.CursorLeft = 2;
                }
            }

            // Línea inferior de la tabla
            Console.CursorLeft = 2;
            Console.WriteLine(esquinaInferiorIzq + columnasExt2 + esquinaInferiorDer);
        }
        public static void ListaPlayasTabla(List<PlayaEstacionamiento> playas)
        {
            // Caracteres para los bordes de la tabla
            char bordeHorizontalExt = '═';
            char bordeVerticalExt = '║';
            char esquinaSuperiorIzq = '╔';
            char esquinaSuperiorDer = '╗';
            char esquinaInferiorIzq = '╚';
            char esquinaInferiorDer = '╝';
            char bordeHorizontalInt = '─';
            char bordeVerticalInt = '│';
            char bordeIzq = '╟';
            char bordeDer = '╢';
            char bordeVerticalSup = '╤';
            char bordeVerticalInf = '╧';
            char cruce = '┼';

            // Obtener el ancho de cada columna basado en la longitud de las propiedades
            int[] anchosColumnas = new int[]
            {
                playas.Any() ? playas.Max(p => p.Nombre.Length): 0,
                playas.Any() ? playas.Max(p => p.Filas.ToString().Length): 0,
                playas.Any() ? playas.Max(p => p.Columnas.ToString().Length) : 0,
                playas.Any() ? playas.Max(p => p.ValorPorHora.ToString().Length) : 0
            };

            string[] titulos = new string[] { "Nombre", "Cant. filas", "Cant. columnas", "Valor por hora" };

            for (int i = 0; i < anchosColumnas.Length; i++)
            {
                if (titulos[i].Length > anchosColumnas[i])
                {
                    anchosColumnas[i] = titulos[i].Length;
                }
            }


            string columnasExt = "";
            string columnasInt = "";
            string columnasExt2 = "";

            // Calcular las líneas de separación y bordes en función de los anchos de columna
            for (int i = 0; i < anchosColumnas.Length; i++)
            {
                if (i == anchosColumnas.Length - 1)
                {
                    columnasInt += new string(bordeHorizontalInt, anchosColumnas[i]);
                    columnasExt += new string(bordeHorizontalExt, anchosColumnas[i]);
                    columnasExt2 += new string(bordeHorizontalExt, anchosColumnas[i]);
                }
                else
                {
                    columnasExt += new string(bordeHorizontalExt, anchosColumnas[i]) + bordeVerticalSup;
                    columnasInt += new string(bordeHorizontalInt, anchosColumnas[i]) + cruce;
                    columnasExt2 += new string(bordeHorizontalExt, anchosColumnas[i]) + bordeVerticalInf;
                }
            }

            // Línea superior de la tabla
            string bordeSuperior = esquinaSuperiorIzq + columnasExt + esquinaSuperiorDer;

            // Línea de separación interna
            string bordeInterior = bordeIzq + columnasInt + bordeDer;

            // Dibujar borde superior
            Console.SetCursorPosition(2, Console.CursorTop);
            Console.WriteLine(bordeSuperior);

            // Imprimir los nombres de las columnas en rojo
            Console.CursorLeft = 2;
            Console.Write(bordeVerticalExt);
            for (int i = 0; i < titulos.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.Red; // Cambio de color a rojo
                Console.Write(titulos[i].PadRight(anchosColumnas[i]));
                Console.ResetColor(); // Restablecer el color a su valor predeterminado
                if (i < titulos.Length - 1)
                {
                    Console.Write(bordeVerticalInt);
                }
            }
            Console.Write(bordeVerticalExt);
            Console.WriteLine();
            Console.CursorLeft = 2;
            Console.WriteLine(bordeInterior);

            // Imprimir los datos de los vehículos
            for (int i = 0; i < playas.Count; i++)
            {
                Console.CursorLeft = 2;
                Console.Write(bordeVerticalExt);
                Console.Write(playas[i].Nombre.PadRight(anchosColumnas[0]));
                Console.Write(bordeVerticalInt);

                Console.Write(playas[i].Filas.ToString().PadRight(anchosColumnas[1]));
                Console.Write(bordeVerticalInt);

                Console.Write(playas[i].Columnas.ToString().PadRight(anchosColumnas[2]));
                Console.Write(bordeVerticalInt);

                Console.Write($"${playas[i].ValorPorHora.ToString().PadRight(anchosColumnas[3] - 1)}");
                Console.Write(bordeVerticalExt);

                if (i < playas.Count - 1)
                {
                    Console.WriteLine();
                    Console.CursorLeft = 2;
                    Console.WriteLine(bordeInterior);
                }
                else
                {
                    Console.WriteLine();
                    Console.CursorLeft = 2;
                }
            }

            // Línea inferior de la tabla
            Console.CursorLeft = 2;
            Console.WriteLine(esquinaInferiorIzq + columnasExt2 + esquinaInferiorDer);
        }

    }
}
