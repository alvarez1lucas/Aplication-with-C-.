﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TrabajoPractico2AURASOFT.Entidades;
using LibreriaAURASOFT;

namespace TrabajoPractico2AURASOFT.Controladores
{
    internal class nVehiculo
    {
        public static void EntradaVehiculo()
        {
            // Iniciamos un bucle infinito para manejar la elección de la playa si no hay lugares disponibles.
            while (true)
            {
                // Mostramos un mensaje amigable al usuario.
                Console.WriteLine("Registrando vehículo...");

                // El usuario elige una playa de estacionamiento.
                int p = nPlayaEstacionamiento.Seleccionar();
                PlayaEstacionamiento playa = Program.playas[p];

                // Comprobamos si hay lugares disponibles en la playa seleccionada.
                bool hayLugar = nPlayaEstacionamiento.CheckLugares(p);

                if (hayLugar == true)
                {
                    // Variables para almacenar la información del vehículo.
                    string marca = "";
                    string modelo = "";
                    DateTime horaEntrada;

                    // Pedimos al usuario que ingrese la patente del vehículo.
                    Console.Write("Ingrese la patente del vehículo (formato AAA 000): ");
                    string patente = Herramientas.ValidarPatente();

                    bool vehiculoExistente = false;

                    // Comprobamos si el vehículo ya existe en la lista de vehículos.
                    foreach (Vehiculo v in Program.vehiculos)
                    {
                        if (patente == v.Patente)
                        {
                            vehiculoExistente = true;
                            Console.WriteLine("Vehículo existente encontrado");
                            marca = v.Marca;
                            modelo = v.Modelo;

                            // Pedimos al usuario que ingrese la hora de entrada.
                            Console.Write("Ingrese la hora de entrada: ");
                            horaEntrada = Herramientas.ValidarHora();

                            // Creamos un objeto Vehiculo con los datos y lo estacionamos en la playa.
                            Vehiculo vehiculo = new Vehiculo(marca, modelo, patente, horaEntrada);
                            nPlayaEstacionamiento.EstacionarVehiculo(playa, vehiculo);
                        }
                    }

                    if (!vehiculoExistente)
                    {
                        // Si el vehículo no existe, solicitamos más información al usuario.
                        Console.Write("Ingrese la marca del vehículo: ");
                        marca = Herramientas.StringNoNulo();

                        Console.Write("Ingrese el modelo del vehículo: ");
                        modelo = Herramientas.StringNoNulo();

                        // Pedimos al usuario que ingrese la hora de entrada.
                        Console.Write("Ingrese la hora de entrada: ");
                        horaEntrada = Herramientas.ValidarHora();

                        // Creamos un nuevo objeto Vehiculo con los datos y lo agregamos a la lista de vehículos.
                        Vehiculo vehiculo = new Vehiculo(marca, modelo, patente, horaEntrada);
                        Program.vehiculos.Add(vehiculo);

                        // Estacionamos el vehículo en la playa.
                        nPlayaEstacionamiento.EstacionarVehiculo(playa, vehiculo);
                    }

                    // Mostramos un mensaje de éxito.
                    Console.WriteLine("Vehículo ingresado exitosamente.");
                    break;
                }
                else
                {
                    // Si no hay lugar en la playa, informamos al usuario y le pedimos que seleccione nuevamente.
                    Console.WriteLine("No hay lugar en esta playa, por favor seleccione otra.");
                    Console.ReadKey(true);
                }
            }
        }


        public static void SalidaVehiculo()
        {
            // Mostramos un mensaje amigable al usuario.
            Console.WriteLine("Registrando la salida de un vehículo...");

            // El usuario selecciona una playa de estacionamiento.
            int playaSeleccionada = nPlayaEstacionamiento.Seleccionar();

            // Obtenemos la información de la playa seleccionada.
            PlayaEstacionamiento playa = Program.playas[playaSeleccionada];

            Console.WriteLine(); // Agregamos un espacio para una mejor presentación.

            // Aquí vamos a guardar las patentes de los vehículos estacionados.
            List<string> patentes = new List<string>();

            // Recorremos la matriz de la playa para encontrar vehículos estacionados.
            for (int i = 0; i < playa.Lugares.GetLength(0); i++)
            {
                for (int j = 0; j < playa.Lugares.GetLength(1); j++)
                {
                    Vehiculo vehiculo = playa.Lugares[i, j];
                    if (vehiculo != null)
                    {
                        // Si encontramos un vehículo, guardamos su patente.
                        patentes.Add(vehiculo.Patente);
                    }
                }
            }

            // Convertimos la lista de patentes en un arreglo.
            string[] arrayPatentes = patentes.ToArray();

            // Creamos un título para mostrar las patentes como en un menú.
            string titulo = $"Patentes de vehículos en {playa.Nombre}:";

            // Mostramos las patentes al estilo de un menú.
            Herramientas.DibujarMenu(titulo, arrayPatentes);

            // Pedimos al usuario que ingrese la patente del vehículo que sale.
            Console.Write("Por favor, ingrese la patente del vehículo que se retira (formato AAA 000): ");

            // Validamos la patente ingresada por el usuario.
            string patente = Herramientas.ValidarPatente();

            Vehiculo vehiculoEncontrado = null;

            // Buscamos el vehículo en la lista de vehículos estacionados.
            foreach (Vehiculo v in Program.vehiculos)
            {
                if (patente == v.Patente)
                {
                    // Hemos encontrado el vehículo.
                    vehiculoEncontrado = v;
                    break;
                }
            }

            if (vehiculoEncontrado != null)
            {
                // Registramos la hora de salida del vehículo.
                Console.Write("Por favor, ingrese la hora de salida del vehículo: ");
                vehiculoEncontrado.HoraSalida = Herramientas.ValidarHora();

                // Calculamos el costo del estacionamiento.
                double costo = CalcularCosto(playa, vehiculoEncontrado);

                // Registramos el costo realizado en el vehículo.
                vehiculoEncontrado.Cobro_Realizado = costo;

                // Agregamos el vehículo al informe y lo retiramos de la playa.
                nPlayaEstacionamiento.AgregarVehiculoAlinforme(playa, vehiculoEncontrado);
                nPlayaEstacionamiento.QuitarVehiculo(playa, vehiculoEncontrado);

                // Mostramos un mensaje de éxito y el costo en formato de moneda.
                Console.WriteLine($"El vehículo con patente {vehiculoEncontrado.Patente} ha salido con éxito.");
                Console.WriteLine($"El costo es de: {costo:C}");
                Console.WriteLine("Por favor, presione cualquier tecla para continuar.");
                Console.ReadKey(true);
            }
            else
            {
                // Si no encontramos el vehículo, informamos al usuario.
                Console.WriteLine("Vehículo no encontrado en la playa de estacionamiento.");
                Console.WriteLine("Por favor, presione cualquier tecla para continuar.");
                Console.ReadKey(true);
            }
        }

        public static double CalcularCosto(PlayaEstacionamiento playa, Vehiculo vehiculo)
        {
            // Obtener la hora de entrada y salida del vehículo
            DateTime horaEntrada = vehiculo.HoraEntrada;
            DateTime horaSalida = vehiculo.HoraSalida ?? DateTime.Now; // Si la hora de salida es nula, se toma la hora actual

            // Se suma un día completo a la hora de salida, si la hora ingresada para esta es menor o igual a la de entrada
            if (horaSalida <= horaEntrada)
            {
                horaSalida = horaSalida.AddDays(1);
            }

            // Calcular la diferencia de tiempo en horas
            TimeSpan tiempoEstacionado = horaSalida - horaEntrada;

            // Obtener el precio por hora de la playa seleccionada
            double precioPorHora = playa.ValorPorHora;

            // Calcular el costo total
            double costo = tiempoEstacionado.TotalHours * precioPorHora;

            return costo;
        }

        public static void Menu()
        {
            string[] opciones = new string[] { "Entrada de vehículo", "Salida de vehiculo ", "Volver" };
            Console.Clear();
            Herramientas.DibujarMenu("Vehículos", opciones);
            Console.Write("Seleccione Opción: ");
            int seleccion = Herramientas.IngresoEntero(1, 3);         
            Console.WriteLine();
            switch (seleccion)
            {
                case 1: EntradaVehiculo(); Menu(); break;
                case 2: SalidaVehiculo(); Menu(); break;
                case 3: break;
            }
        }

    }
}
