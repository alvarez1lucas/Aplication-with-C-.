﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabajoPractico2AURASOFT.Entidades
{
    internal class PlayaEstacionamiento
    {
        public string Nombre { get; set; }
        public int Filas { get; set; }
        public int Columnas { get; set; }
        public double ValorPorHora { get; set; }
        public Vehiculo? [,] Lugares { get; set; } // Matriz de la playa con todos los lugares para estacionar
        public List<Vehiculo> Informe { get; set; } // Cuando se retira al vehículo, se debe agregar a esta lista, que es el informe de la playa.
        public PlayaEstacionamiento() { }

        public PlayaEstacionamiento(string nombre, int filas, int columnas, double valorPorHora)
        {
            Nombre = nombre;
            Filas = filas;
            Columnas = columnas;
            ValorPorHora = valorPorHora;
            Lugares = new Vehiculo[Filas, Columnas]; // Se inicializa con tamaño fijo, según las filas y columnas indicadas.
            Informe = new List<Vehiculo>();
        }

    }
}
