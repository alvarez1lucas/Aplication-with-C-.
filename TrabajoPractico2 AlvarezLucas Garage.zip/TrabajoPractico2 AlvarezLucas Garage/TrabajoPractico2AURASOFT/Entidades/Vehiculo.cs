﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrabajoPractico2AURASOFT.Entidades
{
    // Definimos una clase llamada Vehiculo en el espacio de nombres TrabajoPractico2AURASOFT.Entidades.
    internal class Vehiculo
    {
        // Propiedades públicas que representan las características de un vehículo.
        public string Marca { get; set; } // La marca del vehículo.
        public string Modelo { get; set; } // El modelo del vehículo.
        public string Patente { get; set; } // La patente del vehículo.
        public DateTime HoraEntrada { get; set; } // La hora de entrada del vehículo.

        // La siguiente propiedad es opcional y puede ser nula, se usa cuando el vehículo se retira de la playa de estacionamiento.
        public DateTime? HoraSalida { get; set; } // La hora de salida del vehículo (puede ser nula).

        // Esta propiedad también es opcional y puede ser nula, se usa para registrar el costo del estacionamiento cuando el vehículo se retira.
        public double? Cobro_Realizado { get; set; } // El costo de estacionamiento realizado (puede ser nulo).

        // Constructor vacío por defecto.
        public Vehiculo() { }

        // Constructor personalizado que permite crear un objeto Vehiculo con datos iniciales.
        public Vehiculo(string marca, string modelo, string patente, DateTime horaEntrada, DateTime? horaSalida = null, double? cobro_Realizado = null)
        {
            // Asignamos los valores iniciales a las propiedades del vehículo.
            Marca = marca;
            Modelo = modelo;
            Patente = patente;
            HoraEntrada = horaEntrada;
            HoraSalida = horaSalida; // Opcional: hora de salida (puede ser nula).
            Cobro_Realizado = cobro_Realizado; // Opcional: costo de estacionamiento (puede ser nulo).
        }
    }
}
