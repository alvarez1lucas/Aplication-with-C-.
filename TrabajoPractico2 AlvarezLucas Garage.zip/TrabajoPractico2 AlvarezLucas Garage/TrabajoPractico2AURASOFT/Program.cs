﻿using TrabajoPractico2AURASOFT.Entidades;
using TrabajoPractico2AURASOFT.Controladores;
using System.Globalization;
using LibreriaAURASOFT;

namespace TrabajoPractico2AURASOFT
{
    internal class Program
    {
        public static List<PlayaEstacionamiento> playas;
        public static List<Vehiculo> vehiculos;
        static void Main(string[] args)
        {
            playas = new List<PlayaEstacionamiento>();
            vehiculos = new List<Vehiculo>();
            Datos();
            Menu();
        }

        public static void Menu()
        {
            Console.Clear();
            Console.WriteLine("Bienvenido a la administración de playas de estacionamiento");
            string[] opciones = new string[] { "Playas de estacionamiento", "Vehiculos", "Salir" };
            Herramientas.DibujarMenu("Menú Principal", opciones);
            Console.Write("Seleccione Opción: ");
            int seleccion = Herramientas.IngresoEntero(1, 3);
            switch (seleccion)
            {
                case 1: nPlayaEstacionamiento.Menu(); Menu(); break;
                case 2: nVehiculo.Menu(); Menu(); break; 
                case 3: break;
            }
        }

        public static void Datos()
        {
            // BY SANTIAGO FARIAS
            playas.Add(new PlayaEstacionamiento("Playa 1", 10, 10, 450));

            Vehiculo Vehiculo1 = new Vehiculo("Peugeot", "306", "NUK 329", DateTime.ParseExact("18:00", "HH:mm", null));
            Vehiculo Vehiculo2 = new Vehiculo("Audi", "A3", "TYC 987", DateTime.ParseExact("07:00", "HH:mm", null));
            Vehiculo Vehiculo3 = new Vehiculo("Ford", "Mustang", "VVR 113", DateTime.ParseExact("15:30", "HH:mm", null));

            vehiculos.Add(Vehiculo1);
            vehiculos.Add(Vehiculo2);
            vehiculos.Add(Vehiculo3);

            playas[0].Lugares[0, 0] = Vehiculo1;
            playas[0].Lugares[0, 1] = Vehiculo2;
            playas[0].Lugares[1, 0] = Vehiculo3;

            playas.Add(new PlayaEstacionamiento("Playa 2", 8, 8, 400)); 

            Vehiculo vehiculo4 = new Vehiculo("Toyota", "Corolla", "XYZ 456", DateTime.ParseExact("09:30", "HH:mm", null));
            Vehiculo vehiculo5 = new Vehiculo("Honda", "Civic", "ABC 123", DateTime.ParseExact("10:15", "HH:mm", null));
            Vehiculo vehiculo6 = new Vehiculo("Nissan", "Sentra", "DEF 789", DateTime.ParseExact("14:45", "HH:mm", null));

            vehiculos.Add(vehiculo4);
            vehiculos.Add(vehiculo5);
            vehiculos.Add(vehiculo6);

            playas[1].Lugares[0, 0] = vehiculo4;
            playas[1].Lugares[0, 1] = vehiculo5;
            playas[1].Lugares[1, 0] = vehiculo6;

            playas.Add(new PlayaEstacionamiento("Playa 3", 12, 12, 600)); 

            Vehiculo vehiculo7 = new Vehiculo("Chevrolet", "Cruze", "GHI 789", DateTime.ParseExact("08:15", "HH:mm", null));
            Vehiculo vehiculo8 = new Vehiculo("Ford", "Escape", "JKL 123", DateTime.ParseExact("10:30", "HH:mm", null));
            Vehiculo vehiculo9 = new Vehiculo("Volkswagen", "Passat", "MNO 456", DateTime.ParseExact("12:20", "HH:mm", null));

            vehiculos.Add(vehiculo7);
            vehiculos.Add(vehiculo8);
            vehiculos.Add(vehiculo9);

            playas[2].Lugares[0, 0] = vehiculo7;
            playas[2].Lugares[0, 1] = vehiculo8;
            playas[2].Lugares[1, 0] = vehiculo9;

            playas.Add(new PlayaEstacionamiento("Playa 4", 14, 14, 750));

            Vehiculo vehiculo10 = new Vehiculo("Toyota", "Etios", "PQR 789", DateTime.ParseExact("21:45", "HH:mm", null));
            Vehiculo vehiculo11 = new Vehiculo("Honda", "Accord", "XYZ 234", DateTime.ParseExact("12:15", "HH:mm", null));
            Vehiculo vehiculo12 = new Vehiculo("Audi", "R8", "ABC 456", DateTime.ParseExact("05:30", "HH:mm", null));

            vehiculos.Add(vehiculo10);
            vehiculos.Add(vehiculo11);
            vehiculos.Add(vehiculo12);

            playas[3].Lugares[0, 0] = vehiculo10;
            playas[3].Lugares[0, 1] = vehiculo11;
            playas[3].Lugares[1, 0] = vehiculo12;

            playas.Add(new PlayaEstacionamiento("Playa 5", 16, 16, 900)); 

            Vehiculo vehiculo13 = new Vehiculo("Ford", "Ka", "RST 789", DateTime.ParseExact("10:00", "HH:mm", null));
            Vehiculo vehiculo14 = new Vehiculo("Chevrolet", "Corsa", "UVW 234", DateTime.ParseExact("13:45", "HH:mm", null));
            Vehiculo vehiculo15 = new Vehiculo("Citroen", "C3", "BCD 567", DateTime.ParseExact("20:20", "HH:mm", null));

            vehiculos.Add(vehiculo13);
            vehiculos.Add(vehiculo14);
            vehiculos.Add(vehiculo15);

            playas[4].Lugares[0, 0] = vehiculo13;
            playas[4].Lugares[0, 1] = vehiculo14;
            playas[4].Lugares[1, 0] = vehiculo15;

            playas.Add(new PlayaEstacionamiento("Playa 6", 20, 20, 1200)); 

            Vehiculo vehiculo19 = new Vehiculo("Porsche", "Taycan", "LMN 123", DateTime.ParseExact("06:30", "HH:mm", null));
            Vehiculo vehiculo20 = new Vehiculo("Volvo", "XC40", "OPQ 456", DateTime.ParseExact("07:45", "HH:mm", null));
            Vehiculo vehiculo21 = new Vehiculo("Hyundai", "Elantra", "RST 789", DateTime.ParseExact("09:15", "HH:mm", null));

            vehiculos.Add(vehiculo19);
            vehiculos.Add(vehiculo20);
            vehiculos.Add(vehiculo21);

            playas[5].Lugares[0, 0] = vehiculo19;
            playas[5].Lugares[0, 1] = vehiculo20;
            playas[5].Lugares[1, 0] = vehiculo21;

        }

    }
}
