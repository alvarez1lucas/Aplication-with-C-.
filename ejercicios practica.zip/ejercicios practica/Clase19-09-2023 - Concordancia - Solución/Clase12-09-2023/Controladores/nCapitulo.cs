﻿using Clase12_09_2023.Entidades;
using Libreria2023;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase12_09_2023.Controladores
{
    internal class nCapitulo
    {
        public static void Crear()
        {
            List<Capitulo> capitulosDelLibro = nLibro.Seleccionar().Capitulos;
            Capitulo capitulo = new Capitulo();
            Console.Write("Ingrese el Id del capítulo: ");
            capitulo.Id = Herramientas.IngresoEnteros();
            Console.WriteLine();
            Console.Write("Ingrese el número del capítulo: ");
            capitulo.NumeroCapitulo = Herramientas.IngresoEnteros();
            Console.WriteLine();
            Console.Write("¿El capítulo tiene nombre?");
            Console.WriteLine();
            string[] opciones = new string[] { "Sí", "No" };
            Herramientas.DibujoMenu("Nombre", opciones);
            int opcion = Herramientas.IngresoEnteros(1, 2);
            Console.WriteLine();
            if (opcion == 1)
            {
                Console.Write("Ingrese el nombre del capítulo: ");
                capitulo.NombreCapitulo = Console.ReadLine();
            }
            else 
            {
                capitulo.NombreCapitulo = "";
            }
            capitulosDelLibro.Add(capitulo);
        }

        public static Libro Imprimir()
        {
            Libro libro = nLibro.Seleccionar();
            libro = OrdenarCapitulos(libro);
            string[,] capitulosTabla = new string[libro.Capitulos.Count + 1, 3];
            capitulosTabla[0, 0] = "Id";
            capitulosTabla[0, 1] = "Número";
            capitulosTabla[0, 2] = "Nombre del capítulo";

            foreach (Capitulo c in libro.Capitulos)
            {
                capitulosTabla[libro.Capitulos.IndexOf(c) + 1, 0] = (libro.Capitulos.IndexOf(c) + 1).ToString();
                capitulosTabla[libro.Capitulos.IndexOf(c) + 1, 1] = c.NumeroCapitulo.ToString();
                if (c.NombreCapitulo != null)
                {
                    capitulosTabla[libro.Capitulos.IndexOf(c) + 1, 2] = c.NombreCapitulo;
                }
                else
                {
                    capitulosTabla[libro.Capitulos.IndexOf(c) + 1, 2] = "";
                }
            }
            Herramientas.DibujaTabla(capitulosTabla);
            return libro;
        }
        public static Capitulo Seleccionar()
        {

            Console.WriteLine();
            Libro libro = Imprimir();
            Console.Write("Seleccione el id del capítulo: ");
            int s = Herramientas.IngresoEnteros(1, libro.Capitulos.Count);
            return libro.Capitulos[s - 1];

        }
        public static void Eliminar()
        {
            Libro libro = Imprimir();
            if (libro.Capitulos.Count > 0)
            {
                Console.Write("Seleccione el id del capítulo a eliminar: ");
                int capitulId = Herramientas.IngresoEnteros(1, libro.Capitulos.Count);
                Capitulo capituloAEliminar = libro.Capitulos[capitulId - 1];
                libro.Capitulos.Remove(capituloAEliminar);
            }
            else
            {
                Console.WriteLine("No existen datos a eliminar"); Console.ReadKey(true);
            }
        }
        public static void Modificar(Capitulo capitulo)
        {
            Console.WriteLine();
            Console.Write("Ingrese nuevo numero del capítulo: ");
            capitulo.NumeroCapitulo = Herramientas.IngresoEnteros();
            Console.WriteLine();
        }
        public static void Menu()
        {
            string[] opciones = new string[] { "Crear", "Modificar", "Eliminar", "Listar", "Volver" };
            Console.Clear();
            Herramientas.DibujoMenu("Capítulos", opciones);
            Console.Write("Seleccione Opcion: ");
            int seleccion = Herramientas.IngresoEnteros(1, opciones.Length);
            Console.WriteLine();
            switch (seleccion)
            {
                case 1: Crear(); Menu(); break;
                case 2: Modificar(Seleccionar()); Menu(); break;
                case 3: Eliminar(); Menu(); break;
                case 4: Imprimir(); Console.ReadKey(); Menu(); break;
                case 5: Program.Menu(); break;
            }
        }
        public static Libro OrdenarCapitulos(Libro libro)
        {
            libro.Capitulos = libro.Capitulos.OrderBy(a => a.NumeroCapitulo).ToList();
            return libro;
        }
    }
}
