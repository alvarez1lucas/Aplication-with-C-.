﻿using Clase12_09_2023.Entidades;
using Libreria2023;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase12_09_2023.Controladores
{
    internal class nLibro
    {
        public static void Crear()
        {
            List<Libro> librosDelTestamento = nTestamento.Seleccionar().Libros;
            Libro libro = new Libro();
            Console.Write("Ingrese el Id del libro: ");
            libro.Id = Herramientas.IngresoEnteros();
            Console.WriteLine();
            Console.Write("Ingrese el número del libro: ");
            libro.NumeroLibro = Herramientas.IngresoEnteros();
            Console.WriteLine();
            Console.Write("Ingrese el nombre del libro: ");
            libro.Nombre = Console.ReadLine();
            librosDelTestamento.Add(libro);
        }

        public static Testamento Imprimir()
        {
            Testamento testamento = nTestamento.Seleccionar();
            testamento = OrdenarLibros(testamento);
            string[,] librosTabla = new string[testamento.Libros.Count + 1, 3];
            librosTabla[0, 0] = "Id";
            librosTabla[0, 1] = "Número";
            librosTabla[0, 2] = "Nombre del libro";

            foreach (Libro l in testamento.Libros)
            {
                librosTabla[testamento.Libros.IndexOf(l) + 1, 0] = (testamento.Libros.IndexOf(l) + 1).ToString();
                librosTabla[testamento.Libros.IndexOf(l) + 1, 1] = l.NumeroLibro.ToString();
                librosTabla[testamento.Libros.IndexOf(l) + 1, 2] = l.Nombre;
            }
            Herramientas.DibujaTabla(librosTabla);
            return testamento;
        }
        public static Libro Seleccionar()
        {
            Console.WriteLine();
            Testamento testamento = Imprimir();
            Console.Write("Seleccione el id del libro: ");
            int s = Herramientas.IngresoEnteros(1, testamento.Libros.Count);
            Console.WriteLine();
            return testamento.Libros[s - 1];
        }
        public static void Eliminar()
        {
            Testamento testamento = Imprimir();
            if (testamento.Libros.Count > 0)
            {
                Console.Write("Seleccione el id del libro a eliminar: ");
                int libroId = Herramientas.IngresoEnteros(1, testamento.Libros.Count);
                Libro libroAEliminar = testamento.Libros[libroId - 1];
                testamento.Libros.Remove(libroAEliminar);
            }
            else
            {
                Console.WriteLine("No existen datos a eliminar"); Console.ReadKey(true);
            }
        }
        public static void Modificar(Libro libro)
        {
            Console.WriteLine();
            Console.Write("Ingrese nuevo nombre del libro: ");
            libro.Nombre = Console.ReadLine();
        }
        public static void Menu()
        {
            string[] opciones = new string[] { "Crear", "Modificar", "Eliminar", "Listar", "Volver" };
            Console.Clear();
            Herramientas.DibujoMenu("Libros", opciones);
            Console.Write("Seleccione Opcion: ");
            int seleccion = Herramientas.IngresoEnteros(1, opciones.Length);
            Console.WriteLine();
            switch (seleccion)
            {
                case 1: Crear(); Menu(); break;
                case 2: Modificar(Seleccionar()); Menu(); break;
                case 3: Eliminar (); Menu(); break;
                case 4: Imprimir(); Console.ReadKey(); Menu(); break;
                case 5: Program.Menu(); break;
            }
        }
        public static Testamento OrdenarLibros(Testamento testamento)
        {
            testamento.Libros = testamento.Libros.OrderBy(a => a.NumeroLibro).ToList();
            return testamento;
        }
    }
}
