﻿using Clase12_09_2023.Entidades;
using Libreria2023;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase12_09_2023.Controladores
{
    internal class nTestamento
    {
        public static List<Testamento> testamentos = new List<Testamento>();
        public static void Crear()
        {
            Testamento testamento = new Testamento();
            Console.Write("Ingrese el Id del Testamento: ");
            testamento.Id = Herramientas.IngresoEnteros();
            Console.WriteLine();
            Console.Write("Ingrese el número del Testamento: ");
            testamento.NumeroTestamento = Herramientas.IngresoEnteros();
            Console.WriteLine();
            Console.Write("Ingrese el nombre del Testamento: ");
            testamento.Nombre = Console.ReadLine();
            testamentos.Add(testamento);
        }

        public static void Imprimir()
        {
            Console.WriteLine();
            OrdenarTestamentos();
            string[,] tablaTestamentos = new string[testamentos.Count + 1, 3];
            tablaTestamentos[0, 0] = "Id";
            tablaTestamentos[0, 1] = "Número";
            tablaTestamentos[0, 2] = "Nombre del Testamento";
            
            foreach (Testamento t in testamentos)
            {
                tablaTestamentos[testamentos.IndexOf(t) + 1, 0] = (testamentos.IndexOf(t) + 1).ToString();
                tablaTestamentos[testamentos.IndexOf(t) + 1, 1] = t.NumeroTestamento.ToString();
                tablaTestamentos[testamentos.IndexOf(t) + 1, 2] = t.Nombre;
            }
            Herramientas.DibujaTabla(tablaTestamentos);
        }
        public static Testamento Seleccionar()
        {
            Console.WriteLine();
            Imprimir();
            Console.Write("Seleccione el id del testamento: ");
            int s = Herramientas.IngresoEnteros(1, testamentos.Count);
            Console.WriteLine();
            return testamentos[s - 1];
        }
        public static void Eliminar()
        {
            Testamento testamentoAEliminar = Seleccionar();
            testamentos.Remove(testamentoAEliminar);
        }
        public static void Modificar(Testamento testamentoAModificar)
        {
            Console.WriteLine();
            Console.Write("Ingrese nuevo nombre del testamento: ");
            testamentoAModificar.Nombre = Console.ReadLine();
        }
        public static void Menu()
        {
            string[] opciones = new string[] { "Crear", "Modificar", "Eliminar", "Listar", "Volver" };
            Console.Clear();
            Herramientas.DibujoMenu("Testamentos", opciones);
            Console.Write("Seleccione Opcion: ");
            int seleccion = Herramientas.IngresoEnteros(1, opciones.Length);
            Console.WriteLine();
            switch (seleccion)
            {
                case 1: Crear(); Menu(); break;
                case 2: Modificar(Seleccionar()); Menu(); break;
                case 3:
                    if (testamentos.Count > 0)
                    { Eliminar(); }
                    else
                    {
                        Console.WriteLine("No existen datos a eliminar"); Console.ReadKey(true);
                    }; Menu(); break;
                case 4: Imprimir(); Console.ReadKey(); Menu(); break;
                case 5: Program.Menu(); break;
            }
        }
        public static void OrdenarTestamentos()
        {
            testamentos = testamentos.OrderBy(a => a.NumeroTestamento).ToList();
        }
    }
}
