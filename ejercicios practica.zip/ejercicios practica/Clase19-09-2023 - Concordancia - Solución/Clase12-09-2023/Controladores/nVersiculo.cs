﻿using Clase12_09_2023.Entidades;
using Libreria2023;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase12_09_2023.Controladores
{
    internal class nVersiculo
    {
        public static void Crear()
        {
            List<Versiculo> versiculosDelCapitulo = nCapitulo.Seleccionar().Versiculos;
            Versiculo versiculo = new Versiculo();
            Console.WriteLine();
            Console.Write("Ingrese el Id del versículo: ");
            versiculo.Id = Herramientas.IngresoEnteros();
            Console.WriteLine();
            Console.Write("Ingrese el número del versículo: ");
            versiculo.NumeroVersiculo = Herramientas.IngresoEnteros();
            Console.WriteLine();
            Console.Write("Ingrese el texto del versículo: ");
            versiculo.TextoVersiculo = Console.ReadLine();
            versiculosDelCapitulo.Add(versiculo);
        }
        public static Capitulo Imprimir()
        {
            Console.WriteLine();
            Capitulo capitulo = nCapitulo.Seleccionar();
            Console.WriteLine();
            capitulo = OrdenarVersiculos(capitulo);
            Console.WriteLine();
            foreach (Versiculo versiculo in capitulo.Versiculos)
            {
                Console.SetCursorPosition(Console.CursorLeft + 1, Console.CursorTop);
                Console.Write("Id: " + versiculo.Id +  " - ");
                Console.SetCursorPosition(Console.CursorLeft + 10, Console.CursorTop);
                Console.WriteLine(versiculo.NumeroVersiculo + " " + versiculo.TextoVersiculo);
            }
            return capitulo;
        }
        public static Versiculo Seleccionar()
        {
            Console.WriteLine();
            Capitulo capitulo = Imprimir();
            Console.Write("Seleccione el id del versiculo: ");
            int s = Herramientas.IngresoEnteros(1, capitulo.Versiculos.Count);
            return capitulo.Versiculos[s - 1];
        }
        public static void Eliminar()
        {
            Capitulo capitulo = Imprimir();
            if (capitulo.Versiculos.Count > 0)
            {
                Console.Write("Seleccione el id del versiculo a eliminar: ");
                int versiculoId = Herramientas.IngresoEnteros(1, capitulo.Versiculos.Count);
                Versiculo versiculoAEliminar = capitulo.Versiculos[versiculoId - 1];
                capitulo.Versiculos.Remove(versiculoAEliminar);
            }
            else
            {
                Console.WriteLine("No existen datos a eliminar"); Console.ReadKey(true);
            }
        }
        public static void Modificar(Versiculo versiculo)
        {
            Console.WriteLine();
            Console.Write("Ingrese nuevo texto del versículo: ");
            versiculo.TextoVersiculo = Console.ReadLine();
        }
        public static void Menu()
        {
            string[] opciones = new string[] { "Crear", "Modificar", "Eliminar", "Listar", "Volver" };
            Console.Clear();
            Herramientas.DibujoMenu("Versiculos", opciones);
            Console.Write("Seleccione Opcion: ");
            int seleccion = Herramientas.IngresoEnteros(1, opciones.Length);
            Console.WriteLine();
            switch (seleccion)
            {
                case 1: Crear(); Menu(); break;
                case 2: Modificar(Seleccionar()); Menu(); break;
                case 3: Eliminar(); Menu(); break;
                case 4: Imprimir(); Console.ReadKey(); Menu(); break;
                case 5: Program.Menu();  break;
            }
        }
        public static Capitulo OrdenarVersiculos(Capitulo capitulo)
        {
            capitulo.Versiculos= capitulo.Versiculos.OrderBy(a => a.NumeroVersiculo).ToList();
            return capitulo;
        }
    }
}
