﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase12_09_2023.Entidades
{
    internal class Capitulo
    {
        public int Id { get; set; }
        public int NumeroCapitulo { get; set; }
        public string? NombreCapitulo { get; set; }
        public List<Versiculo> Versiculos { get; set;}

        public Capitulo() { 
            Versiculos = new List<Versiculo>();
        }
        public Capitulo(int id, int numeroCapitulo, string? nombreCapitulo = null)
        {
            Id = id;
            NumeroCapitulo = numeroCapitulo;
            NombreCapitulo = nombreCapitulo;
            Versiculos = new List<Versiculo>();
        }
    }
}
