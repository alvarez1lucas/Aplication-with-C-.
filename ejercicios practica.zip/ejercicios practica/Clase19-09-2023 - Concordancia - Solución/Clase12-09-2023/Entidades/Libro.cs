﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase12_09_2023.Entidades
{
    internal class Libro
    {
        public int Id { get; set; }
        public int NumeroLibro { get; set; }
        public string Nombre {get; set; }
        public List<Capitulo> Capitulos { get; set;}
        public Libro() {
            Capitulos = new List<Capitulo>();
        }
        public Libro(int id, int numeroLibro, string nombre)
        {
            Id = id;
            NumeroLibro = numeroLibro;
            Nombre = nombre;
            Capitulos = new List<Capitulo>();
        }

    }
}
