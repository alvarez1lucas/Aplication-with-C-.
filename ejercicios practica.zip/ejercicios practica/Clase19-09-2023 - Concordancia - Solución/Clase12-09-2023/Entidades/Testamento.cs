﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase12_09_2023.Entidades
{
    internal class Testamento
    {
        public int Id { get; set; }
        public int NumeroTestamento { get; set; }
        public string Nombre { get; set; }
        public List<Libro> Libros { get; set; }

        public Testamento()
        {
            Libros = new List<Libro>();
        }
        public Testamento(int id, int numeroTestamento, string nombre)
        {
            Id = id;
            NumeroTestamento = numeroTestamento;
            Nombre = nombre;
            Libros = new List<Libro>();
        }
    }
}
