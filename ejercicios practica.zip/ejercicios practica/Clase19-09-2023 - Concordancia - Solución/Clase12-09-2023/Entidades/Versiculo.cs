﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase12_09_2023.Entidades
{
    internal class Versiculo
    {
        public int Id { get; set; }
        public int NumeroVersiculo { get; set; }
        public string TextoVersiculo { get; set; }

        public Versiculo() { }
        public Versiculo(int id, int numeroVersiculo, string textoVersiculo)
        {
            Id = id;
            NumeroVersiculo = numeroVersiculo;
            TextoVersiculo = textoVersiculo;
        }
    }
}
