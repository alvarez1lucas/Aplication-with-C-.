﻿using Clase12_09_2023.Entidades;
using Libreria2023;
using Clase12_09_2023.Controladores;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;

namespace Clase12_09_2023
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Datos();
            Menu();
        }
        public static void Menu()
        {
            Console.Clear();
            string[] opciones = { "Testamentos", "Libros", "Capítulos", "Versículos", "Concordancia", "Salir" };
            Herramientas.DibujoMenu("Biblia", opciones);
            Console.Write("Seleccione: ");
            int seleccion = Herramientas.IngresoEnteros(1, opciones.Length);
            switch (seleccion)
            {
                case 1: nTestamento.Menu(); Menu(); break;
                case 2: nLibro.Menu(); Menu(); break;
                case 3: nCapitulo.Menu(); Menu(); break;
                case 4: nVersiculo.Menu(); break;
                case 5: Concordancia(); Menu(); break;
                case 6: break;
            }

        }
        public static void Concordancia()
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("Ingrese la palabra buscada: ");
            string palabraBuscada = Console.ReadLine();
            List<String[]> versiculosCoincidentes = new List<String[]>();
            foreach (Testamento testamento in nTestamento.testamentos) { 
                foreach (Libro libro in testamento.Libros)
                {
                    foreach (Capitulo capitulo in libro.Capitulos)
                    {
                        foreach (Versiculo versiculo in capitulo.Versiculos)
                        {
                            if (versiculo.TextoVersiculo.Contains(palabraBuscada))
                            {
                                string[] datosVersiculos = {testamento.Nombre, libro.Nombre, capitulo.NumeroCapitulo.ToString(), "Versiculo: " + versiculo.NumeroVersiculo + " " + versiculo.TextoVersiculo};
                                versiculosCoincidentes.Add(datosVersiculos);
                            }
                        }
                    }
                }
            }
            Console.WriteLine("Los versiculos que contienen la palabra son: ");
            Console.WriteLine();
            foreach (String[] versiculosCoincidente in versiculosCoincidentes)
            {
                Console.WriteLine(versiculosCoincidente[0] + " - " + versiculosCoincidente[1] + " " + versiculosCoincidente[2]);
                Console.WriteLine(versiculosCoincidente[3]);
                Console.WriteLine();
            }
            Console.ReadKey(true);
        }
        public static void Datos()
        {
            nTestamento.testamentos.Add(new Testamento(1, 2, "Nuevo Testamento"));
            nTestamento.testamentos.Add(new Testamento(2, 1, "Antiguo Testamento"));

            nTestamento.testamentos[1].Libros.Add(new Libro(1, 2, "Éxodo"));
            nTestamento.testamentos[1].Libros.Add(new Libro(2, 1, "Génesis"));

            nTestamento.testamentos[0].Libros.Add(new Libro(3, 1, "Mateo"));
            nTestamento.testamentos[0].Libros.Add(new Libro(4, 2, "Marcos"));

            nTestamento.testamentos[1].Libros[1].Capitulos.Add(new Capitulo(1, 1, "La creación"));
            nTestamento.testamentos[1].Libros[1].Capitulos.Add(new Capitulo(2, 2, "El hombre en el huerto del Edén"));

            nTestamento.testamentos[1].Libros[0].Capitulos.Add(new Capitulo(3, 1, "Aflicción de los israelitas en Egipto"));
            nTestamento.testamentos[1].Libros[0].Capitulos.Add(new Capitulo(4, 2, "Nacimiento de Moisés"));

            nTestamento.testamentos[0].Libros[0].Capitulos.Add(new Capitulo(5, 1, "Genealogía de Jesucristo"));
            nTestamento.testamentos[0].Libros[0].Capitulos.Add(new Capitulo(6, 2, "La visita de los magos"));

            nTestamento.testamentos[0].Libros[1].Capitulos.Add(new Capitulo(7, 1, "Predicación de Juan el Bautista"));
            nTestamento.testamentos[0].Libros[1].Capitulos.Add(new Capitulo(8, 2, "Jesús sana a un paralítico"));

            //Genesis - Capítulo 1 (La creación) - Versiculos del 1 al 6
            nTestamento.testamentos[1].Libros[1].Capitulos[0].Versiculos.Add(new Versiculo(1, 3, "Y dijo Dios: Sea la luz; y fue la luz."));
            nTestamento.testamentos[1].Libros[1].Capitulos[0].Versiculos.Add(new Versiculo(2, 4, "Y vio Dios que la luz era buena; y separó Dios la luz de las tinieblas."));
            nTestamento.testamentos[1].Libros[1].Capitulos[0].Versiculos.Add(new Versiculo(3, 2, "Y la tierra estaba desordenada y vacía, y las tinieblas estaban sobre la faz del abismo, y el Espíritu de Dios se movía sobre la faz de las aguas."));
            nTestamento.testamentos[1].Libros[1].Capitulos[0].Versiculos.Add(new Versiculo(4, 1, "En el principio creó Dios los cielos y la tierra."));
            nTestamento.testamentos[1].Libros[1].Capitulos[0].Versiculos.Add(new Versiculo(5, 6, "Luego dijo Dios: Haya expansión en medio de las aguas, y separe las aguas de las aguas."));
            nTestamento.testamentos[1].Libros[1].Capitulos[0].Versiculos.Add(new Versiculo(6, 5, "Y llamó Dios a la luz Día, y a las tinieblas llamó Noche. Y fue la tarde y la mañana un día."));

            //Éxodo - Capítulo 1 (Aflicción de los israelitas en Egipto) - Versiculos del 1 al 6
            nTestamento.testamentos[1].Libros[0].Capitulos[0].Versiculos.Add(new Versiculo(7, 1, "Estos son los nombres de los hijos de Israel que entraron en Egipto con Jacob; cada uno entró con su familia:"));
            nTestamento.testamentos[1].Libros[0].Capitulos[0].Versiculos.Add(new Versiculo(8, 2, "Rubén, Simeón, Leví, Judá,"));
            nTestamento.testamentos[1].Libros[0].Capitulos[0].Versiculos.Add(new Versiculo(9, 3, "Isacar, Zabulón, Benjamín,"));
            nTestamento.testamentos[1].Libros[0].Capitulos[0].Versiculos.Add(new Versiculo(10, 4, "Dan, Neftalí, Gad y Aser."));
            nTestamento.testamentos[1].Libros[0].Capitulos[0].Versiculos.Add(new Versiculo(11, 5, "Todas las personas que le nacieron a Jacob fueron setenta. Y José estaba en Egipto."));
            nTestamento.testamentos[1].Libros[0].Capitulos[0].Versiculos.Add(new Versiculo(12, 6, "Y murió José, y todos sus hermanos, y toda aquella generación."));

            //Éxodo - Capítulo 2 (Nacimiento de Moisés) - versículos del 1 al 6
            nTestamento.testamentos[1].Libros[0].Capitulos[1].Versiculos.Add(new Versiculo(13, 1, "Un varón de la familia de Leví fue y tomó por mujer a una hija de Leví,"));
            nTestamento.testamentos[1].Libros[0].Capitulos[1].Versiculos.Add(new Versiculo(14, 2, "la que concibió, y dio a luz un hijo; y viéndole que era hermoso, le tuvo escondido tres meses."));
            nTestamento.testamentos[1].Libros[0].Capitulos[1].Versiculos.Add(new Versiculo(15, 3, "Pero no pudiendo ocultarle más tiempo, tomó una arquilla de juncos y la calafateó con asfalto y brea, y colocó en ella al niño y lo puso en un carrizal a la orilla del río."));
            nTestamento.testamentos[1].Libros[0].Capitulos[1].Versiculos.Add(new Versiculo(16, 4, "Y una hermana suya se puso a lo lejos, para ver lo que le acontecería."));
            nTestamento.testamentos[1].Libros[0].Capitulos[1].Versiculos.Add(new Versiculo(17, 5, "Y la hija de Faraón descendió a lavarse al río, y paseándose sus doncellas por la ribera del río, vio ella la arquilla en el carrizal, y envió una criada suya a que la tomase."));
            nTestamento.testamentos[1].Libros[0].Capitulos[1].Versiculos.Add(new Versiculo(18, 6, "Y cuando la abrió, vio al niño; y he aquí que el niño lloraba. Y teniendo compasión de él, dijo: De los niños de los hebreos es éste."));

            //??????? "Entonces Moisés respondió diciendo: He aquí que ellos no me creerán, ni oirán mi voz; porque dirán: No te ha aparecido Jehová."));
            //??????? "Y Jehová dijo: ¿Qué es eso que tienes en tu mano? Y él respondió: Una vara."));
            //??????? "El le dijo: Echala en tierra. Y él la echó en tierra, y se hizo una culebra; y Moisés huía de ella."));
            //??????? "Entonces dijo Jehová a Moisés: Extiende tu mano, y tómala por la cola. Y él extendió su mano, y la tomó, y se volvió vara en su mano."));
            //??????? "Por esto creerán que se te ha aparecido Jehová, el Dios de tus padres, el Dios de Abraham, Dios de Isaac y Dios de Jacob."));
            //??????? "Le dijo además Jehová: Mete ahora tu mano en tu seno. Y él metió la mano en su seno; y cuando la sacó, he aquí que su mano estaba leprosa como la nieve."));

            //??????? "Abraham engendró a Isaac, Isaac a Jacob, y Jacob a Judá y a sus hermanos."));
            //??????? "Libro de la genealogía de Jesucristo, hijo de David, hijo de Abraham."));
            //??????? "Isaí engendró al rey David, y el rey David engendró a Salomón de la que fue mujer de Urías."));
            //??????? "Judá engendró de Tamar a Fares y a Zara, Fares a Esrom, y Esrom a Aram."));
            //??????? "Salmón engendró de Rahab a Booz, Booz engendró de Rut a Obed, y Obed a Isa."));
            //??????? "Aram engendró a Aminadab, Aminadab a Naasón, y Naasón a Salmón."));

            //??????? "Principio del evangelio de Jesucristo, Hijo de Dios."));
            //??????? "Y salían a él toda la provincia de Judea, y todos los de Jerusalén; y eran bautizados por él en el río Jordán, confesando sus pecados."));
            //??????? "Bautizaba Juan en el desierto, y predicaba el bautismo de arrepentimiento para perdón de pecados."));
            //??????? "Como está escrito en Isaías el profeta: He aquí yo envío mi mensajero delante de tu faz, El cual preparará tu camino delante de ti."));
            //??????? "Y Juan estaba vestido de pelo de camello, y tenía un cinto de cuero alrededor de sus lomos; y comía langostas y miel silvestre."));
            //??????? "Voz del que clama en el desierto: Preparad el camino del Señor; Enderezad sus sendas."));

            //??????? "Y dijo: Yo soy el Dios de tu padre, Dios de Abraham, Dios de Isaac, y Dios de Jacob. Entonces Moisés cubrió su rostro, porque tuvo miedo de mirar a Dios."));
            //??????? "Y se le apareció el Angel de Jehová en una llama de fuego en medio de una zarza; y él miró, y vio que la zarza ardía en fuego, y la zarza no se consumía."));
            //??????? "Apacentando Moisés las ovejas de Jetro su suegro, sacerdote de Madián, llevó las ovejas a través del desierto, y llegó hasta Horeb, monte de Dios."));
            //??????? "Y dijo: No te acerques; quita tu calzado de tus pies, porque el lugar en que tú estás, tierra santa es."));
            //??????? "Entonces Moisés dijo: Iré yo ahora y veré esta grande visión, por qué causa la zarza no se quema."));
            //??????? "Viendo Jehová que él iba a ver, lo llamó Dios de en medio de la zarza, y dijo: ¡Moisés, Moisés! Y él respondió: Heme aquí."));

            //??????? "Y vio la mujer que el árbol era bueno para comer, y que era agradable a los ojos, y árbol codiciable para alcanzar la sabiduría; y tomó de su fruto, y comió; y dio también a su marido, el cual comió así como ella."));
            //??????? "Y la mujer respondió a la serpiente: Del fruto de los árboles del huerto podemos comer;"));
            //??????? "pero del fruto del árbol que está en medio del huerto dijo Dios: No comeréis de él, ni le tocaréis, para que no muráis."));
            //??????? "sino que sabe Dios que el día que comáis de él, serán abiertos vuestros ojos, y seréis como Dios, sabiendo el bien y el mal."));
            //??????? "Pero la serpiente era astuta, más que todos los animales del campo que Jehová Dios había hecho; la cual dijo a la mujer: ¿Conque Dios os ha dicho: No comáis de todo árbol del huerto?"));
            //??????? "Entonces la serpiente dijo a la mujer: No moriréis;"));

            //??????? "Fueron, pues, acabados los cielos y la tierra, y todo el ejército de ellos."));
            //??????? "Estos son los orígenes de los cielos y de la tierra cuando fueron creados, el día que Jehová Dios hizo la tierra y los cielos,"));
            //??????? "sino que subía de la tierra un vapor, el cual regaba toda la faz de la tierra."));
            //??????? "Y acabó Dios en el día séptimo la obra que hizo; y reposó el día séptimo de toda la obra que hizo."));
            //??????? "y toda planta del campo antes que fuese en la tierra, y toda hierba del campo antes que naciese; porque Jehová Dios aún no había hecho llover sobre la tierra, ni había hombre para que labrase la tierra"));
            //??????? "Y bendijo Dios al día séptimo, y lo santificó, porque en él reposó de toda la obra que había hecho en la creación."));
        }
    }
}



