﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase04092023.Controladores
{
    internal class Conexion
    {
        static string cadena = "Data Source=biblioteca.s3db";
        static SQLiteConnection conexion = new SQLiteConnection(cadena);

        public static void OpenConnection()
        {
            if (conexion.State == System.Data.ConnectionState.Closed)
                conexion.Open();
        }
        public static void CloseConnection()
        {
            conexion.Close();
        }
        public static SQLiteConnection Connection
        {
            set { conexion = value; }
            get { return conexion; }
        }
    }
}
