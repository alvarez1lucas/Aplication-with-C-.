﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using clase04092023.Entidades;
using Libreria2023;
using System.Data.SQLite;

namespace clase04092023.Controladores
{
    internal class nAutor
    {
        public static void Crear()
        {
            Console.Clear();
            Console.Write("Ingrese el nombre del Autor: ");
            string nombre = Console.ReadLine();
            Console.Write("Ingrese el apellido del Autor: ");
            string apellido = Console.ReadLine();
            Console.Write("Ingrese el id del Autor: ");
            //int id = int.Parse(Console.ReadLine());
            int id = Herramientas.IngresoEnteros();
            Autor autor = new Autor(id, nombre, apellido);
            Program.autores.Add(autor);
            GuardarArchivo(autor);
        }
        public static void GuardarArchivo(Autor a)
        {
            StreamWriter sw = File.AppendText("autores.txt");
            sw.WriteLine($"{a.Id};{a.Nombre};{a.Apellido}");
            sw.Close();

        }
        public static void Imprimir()
        {
            string[] autores = new string[Program.autores.Count];
            foreach (Autor autor in Program.autores)
            {
                autores[Program.autores.IndexOf(autor)] = autor.ToString(); ;
                //Console.WriteLine("{0} - {1} {2}", Program.autores.IndexOf(autor) + 1, autor.Nombre, autor.Apellido);
            }
            Herramientas.DibujoMenu("Autores", autores);
        }
        public static int Seleccionar()
        {
            Console.WriteLine();
            Imprimir();
            Console.Write("Seleccione un Autor: ");
            //int s = int.Parse(Console.ReadLine());
            int s = Herramientas.IngresoEnteros(1, Program.autores.Count);
            return s - 1;
        }
        public static void Eliminar()
        {
            int i = Seleccionar();
            Program.autores.RemoveAt(i);
        }
        public static void Modificar(int i)
        {
            Console.Clear();
            Console.WriteLine();
            Console.Write("Ingrese nuevo nombre para {0}: ", Program.autores[i].Nombre);
            Program.autores[i].Nombre = Console.ReadLine();
            Console.WriteLine();
            Console.Write("Ingrese nuevo apellido para {0}: ", Program.autores[i].Apellido);
            Program.autores[i].Apellido = Console.ReadLine();
        }
        public static void Menu()
        {
            string[] opciones = new string[] { "Crear", "Modificar", "Eliminar", "Listar", "Volver" };
            Console.Clear();
            Herramientas.DibujoMenu("Autores", opciones);
            Console.Write("Seleccione Opcion: ");
            //int seleccion = int.Parse(Console.ReadLine());
            int seleccion = Herramientas.IngresoEnteros(1, 5);
            Console.WriteLine();
            switch (seleccion)
            {
                case 1: Crear(); Menu(); break;
                case 2: Modificar(Seleccionar()); Menu(); break;
                case 3:
                    if (Program.autores.Count > 0)
                    { Eliminar(); }
                    else
                    {
                        Console.WriteLine("No existen datos a eliminar"); Console.ReadKey(true);
                    }; Menu(); break;
                case 4: Console.Clear(); ListarCantidadLibros(); Console.ReadKey(); Menu(); break;
                case 5: break;
            }
        }
        public static void ListarCantidadLibros()
        {
            OrdenarXLibros();
            string[,] tabla = new string[Program.autores.Count + 1, 2];
            tabla[0, 0] = "Autor";
            tabla[0, 1] = "Libros";

            foreach (Autor a in Program.autores)
            {
                tabla[Program.autores.IndexOf(a) + 1, 0] = a.ToString();
                tabla[Program.autores.IndexOf(a) + 1, 1] = nLibro.CantidadLibros(a).ToString();
            }

            Herramientas.DibujaTabla(tabla);
        }
        public static void OrdenarXLibros()
        {
            Program.autores = Program.autores.OrderByDescending(a => nLibro.CantidadLibros(a)).ToList();

            //Comentamos el algoritmo de burbuja.
            //for (int i = 0; i < Program.autores.Count; i++)
            //{
            //    for (int j = 0; j < Program.autores.Count - 1; j++)
            //    {
            //        if (nLibro.CantidadLibros(Program.autores[j]) < nLibro.CantidadLibros(Program.autores[j + 1]))
            //        {
            //            Autor aux = Program.autores[j];
            //            Program.autores[j] = Program.autores[j + 1];
            //            Program.autores[j + 1] = aux;
            //        }
            //    }
            //}
        }
    }
}
