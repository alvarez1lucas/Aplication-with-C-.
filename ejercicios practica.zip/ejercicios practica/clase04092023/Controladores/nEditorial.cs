﻿using clase04092023.Entidades;
using Libreria2023;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase04092023.Controladores
{
    internal class nEditorial
    {
        public static void Crear()
        {
            Console.Clear();
            Console.Write("Ingrese nombre de la Editorial: ");
            string nombre = Console.ReadLine();

            //int id = int.Parse(Console.ReadLine());
            Console.Write("Ingrese id de la Editorial: ");
            int id = Herramientas.IngresoEnteros();
            Editorial editorial = new Editorial(id, nombre);
            Program.editoriales.Add(editorial);
        }
        public static void Imprimir()
        {
            string[] editoriales = new string[Program.editoriales.Count];
            foreach (Editorial t in Program.editoriales)
            {
                editoriales[Program.editoriales.IndexOf(t)] = t.Nombre;
                //Console.WriteLine($"{Program.editoriales.IndexOf(t) + 1} - {t.Nombre}");
            }
            Herramientas.DibujoMenu("Editoriales", editoriales);
        }
        public static int Seleccionar()
        {
            Imprimir();
            Console.Write("Seleccione una Editorial: ");
            int s = Herramientas.IngresoEnteros(1, Program.editoriales.Count);
            return s - 1;
        }
        public static void Eliminar()
        {
            int i = Seleccionar();
            Program.editoriales.RemoveAt(i);
        }
        public static void Modificar(int i)
        {
            Console.Write($"Ingrese nuevo nombre para {Program.editoriales[i].Nombre}: ");
            Program.editoriales[i].Nombre = Console.ReadLine();
        }
        public static void Menu()
        {
            string[] opciones = new string[] { "Crear", "Modificar", "Eliminar", "Listar", "Salir" };
            Console.Clear();
            Herramientas.DibujoMenu("Editoriales", opciones);
            Console.Write("Seleccione opcion: ");
            int o = Herramientas.IngresoEnteros(1, opciones.Length);
            switch (o)
            {
                case 1: Crear(); Menu(); break;
                case 2: Modificar(Seleccionar()); Menu(); break;
                case 3: if (Program.editoriales.Count > 0)
                       {Eliminar();} else{ Console.WriteLine("No existen datos a eliminar"); Console.ReadKey(true); }; Menu(); break;
                case 4: Console.Clear(); Imprimir(); Console.ReadKey(true); Menu(); break;
                case 5: break;
            }




        }
    }
}
