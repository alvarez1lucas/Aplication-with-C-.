﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using clase04092023.Entidades;
using Libreria2023;

namespace clase04092023.Controladores
{
    internal class nLibro
    {
        public static void Crear()
        {
            Libro l = new Libro();
            l.Tema = Program.temas[nTema.Seleccionar()];
            bool agregar = true;
            do
            {
                l.Autores.Add(Program.autores[nAutor.Seleccionar()]);
                string[] opciones = new string[] { "Agregar Otro Autor", "Continuar" };
                Herramientas.DibujoMenu("Autores", opciones);
                int op = Herramientas.IngresoEnteros(1, 2);
                if (op == 2)
                {
                    agregar = false;
                }

            } while (agregar);
            l.Editorial = Program.editoriales[nEditorial.Seleccionar()];
            Console.WriteLine();
            Console.Write("Ingrese el título del libro: ");
            l.Titulo = Console.ReadLine();
            Console.Write("Ingrese el número de páginas del libro: ");
            //l.Paginas = int.Parse(Console.ReadLine());
            l.Paginas = Herramientas.IngresoEnteros();
            Console.WriteLine();
            Console.Write("Ingrese el id del libro: ");
            //l.Id = int.Parse(Console.ReadLine());
            l.Id = Herramientas.IngresoEnteros();
            Console.WriteLine();

            Program.libros.Add(l);
        }

        public static void ListarLibrosTema(Tema t)
        {
            Console.Clear();
            List<Libro> libros = Program.libros.Where(l => l.Tema.Id == t.Id).ToList();
            
            string[] titulos = libros.Select(l => l.Titulo + "- " + l.Tema.Nombre).ToArray();

            //bool grandes = libros.All(l => l.Paginas > 500);
            //libros.Any(l => l.Paginas > 500);

            Herramientas.DibujoMenu("Libros " + t.Nombre, titulos);

            //foreach(Libro l in libros)
            //{
            //    Console.WriteLine($"{l.Titulo} - {l.Tema.Nombre}");
            //}
        }

        public static void Imprimir()
        {
            //List<Libro> librosTema = Program.libros.Where(l => l.Paginas > 500).ToList();
            string[,] libros = new string[Program.libros.Count + 1, 6];
            libros[0, 0] = " # ";
            libros[0, 1] = " Titulo ";
            libros[0, 2] = " Tema ";
            libros[0, 3] = " Autor ";
            libros[0, 4] = " Editorial ";
            libros[0, 5] = " Paginas ";
            foreach (Libro libro in Program.libros)
            {
                libros[Program.libros.IndexOf(libro) + 1, 0] = (Program.libros.IndexOf(libro) + 1).ToString();
                libros[Program.libros.IndexOf(libro) + 1, 1] = libro.Titulo;
                libros[Program.libros.IndexOf(libro) + 1, 2] = libro.Tema.Nombre;
                libros[Program.libros.IndexOf(libro) + 1, 3] = libro.NombreAutores;//libro.Autor.ToString();
                libros[Program.libros.IndexOf(libro) + 1, 4] = libro.Editorial.Nombre;
                libros[Program.libros.IndexOf(libro) + 1, 5] = libro.Paginas.ToString();
                
            }
            Herramientas.DibujaTabla(libros);
            //Crear un archivo nuevo cada vez, si existe lo pisa
            StreamWriter sw = new StreamWriter("libros.txt");
            //Agrega lineas al archivo si este ya existe.
            //StreamWriter sw = File.AppendText("libros.txt");

            foreach (Libro l in Program.libros)
            {
                sw.WriteLine($"{l.Titulo}\t{l.Tema}\t{l.NombreAutores}" );
            }
            sw.Close();
        }
        public static int Seleccionar()
        {
            Console.WriteLine();
            Imprimir();
            Console.Write("Seleccione un Libro: ");
            //int s = int.Parse(Console.ReadLine());
            int s = Herramientas.IngresoEnteros();
            return s - 1;
        }
        public static void Eliminar()
        {
            int i = Seleccionar();
            Program.libros.RemoveAt(i);
        }

        public static void AgregarAutor(int i)
        {
            Console.Clear();
            Console.WriteLine("{0}\nNuevo Autor", Program.libros[i].Titulo);
            Autor a = Program.autores[nAutor.Seleccionar()];
            if (Program.libros[i].Autores.Contains(a))
            {
                Console.WriteLine("\nEl autor ya existe en el libro");
            }
            else
            {
                Program.libros[i].Autores.Add(a);
                Console.WriteLine("\nEl autor se agrego en el libro");
            }
            Console.ReadKey(true); 

        }

        public static void EliminarAutor(int i)
        {
            Console.Clear();
            Console.WriteLine("Eliminar autor de: {0}", Program.libros[i].Titulo);
            string[] autores = Program.libros[i].Autores.Select(x => x.ToString()).ToArray();
            Herramientas.DibujoMenu("Autores", autores);
            Console.Write("Seleccione autor a eliminar: ");
            int o = Herramientas.IngresoEnteros(1, autores.Length);
            Program.libros[i].Autores.RemoveAt(o -1); 
        }
        
        public static void Modificar(int i)
        {
            Console.Clear();

            Console.WriteLine();
            string[] opciones = new string[] { "Título", "Tema", "Agregar Autor", "Eliminar Autor", "Editorial", "Paginas", "Volver" };
            Console.Clear();
            Herramientas.DibujoMenu("Modificar", opciones);
            Console.Write("Seleccione Opcion a modificar: ");
            //int seleccion = int.Parse(Console.ReadLine());
            int seleccion = Herramientas.IngresoEnteros(1, 7);
            Console.WriteLine();
            switch (seleccion)
            {
                case 1:
                    Console.Write("Ingrese nuevo título para el libro {0}: ", Program.libros[i].Titulo);
                    Program.libros[i].Titulo = Console.ReadLine(); Modificar(i); break;
                case 2:
                    Console.Write("Seleccione un nuevo tema para el libro {0}: ", Program.libros[i].Titulo);
                    Program.libros[i].Tema = Program.temas[nTema.Seleccionar()]; Modificar(i); break;
                case 3:
                    AgregarAutor(i);
                    Modificar(i); break;
                case 4:
                   EliminarAutor(i); Modificar(i); break;
                case 5:
                    Console.Write("Seleccione una nueva editorial para el libro {0}: ", Program.libros[i].Titulo);
                    Program.libros[i].Editorial = Program.editoriales[nEditorial.Seleccionar()]; Modificar(i); break;
                case 6:
                    Console.Write("Seleccione un nuevo número de páginas para el libro {0}: ", Program.libros[i].Titulo);
                    //Program.libros[i].Paginas = int.Parse(Console.ReadLine());
                    Program.libros[i].Paginas = Herramientas.IngresoEnteros(); Modificar(i); break;
                case 7: break;
            }
        }
        public static void Menu()
        {
            string[] opciones = new string[] { "Crear", "Modificar", "Eliminar", "Listar", "Ordenar x Paginas", "Libros por Tema", "Volver" };
            Console.Clear();
            Herramientas.DibujoMenu("Libros", opciones);
            Console.Write("Seleccione Opcion: ");
            int seleccion = Herramientas.IngresoEnteros(1, opciones.Length);
            Console.WriteLine();
            switch (seleccion)
            {
                case 1: Crear(); Menu(); break;
                case 2: Console.Clear(); Modificar(Seleccionar()); Menu(); break;
                case 3:
                    if (Program.editoriales.Count > 0)
                    { Eliminar(); }
                    else
                    {
                        Console.WriteLine("No existen datos a eliminar"); Console.ReadKey(true);
                    }; Menu(); break;
                case 4: Console.Clear(); Imprimir(); Console.ReadKey(); Menu(); break;
                case 5: OrdenarXPaginas(); Menu(); break;
                case 6: ListarLibrosTema(Program.temas[nTema.Seleccionar()]); Console.ReadKey(true); Menu();  break;
                case 7: break;

            }
        }

        public static void OrdenarXPaginas()
        {
            Program.libros = Program.libros.OrderBy(l => l.Paginas).ToList();



            //for (int i = 0; i < Program.libros.Count; i++)
            //{
            //    for (int j = 0; j < Program.libros.Count - 1; j++)
            //    {
            //        if (Program.libros[j].Paginas < Program.libros[j + 1].Paginas)
            //        {
            //            Libro aux = Program.libros[j];
            //            Program.libros[j] = Program.libros[j + 1];
            //            Program.libros[j + 1] = aux;
            //        }
            //    }
            //}
        }

        public static int CantidadLibros(Autor a)
        {
            int total = 0;
            foreach (Libro l in Program.libros)
            {
                foreach(Autor at in l.Autores)
                {
                    if (a.Id == at.Id)
                    {
                        total++;   
                    }
                }
            }
            return total;
        }
    }
}
