﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using clase04092023.Entidades;
using Libreria2023;

namespace clase04092023.Controladores
{
    internal class nTema
    {
        public static void Crear()
        {
            Console.Clear();
            Console.Write("Ingrese nombre del tema: ");
            string nombre = Console.ReadLine();
            
            //int id = int.Parse(Console.ReadLine());
            Console.Write("Ingrese id del tema: ");
            int id = Herramientas.IngresoEnteros();
            Tema tema = new Tema(id, nombre);
            Program.temas.Add(tema);
        }
        public static void Imprimir()
        {
            string[] temas = new string[Program.temas.Count];
            
            foreach (Tema t in Program.temas)
            {
                temas[Program.temas.IndexOf(t)] = t.Nombre;
                //Console.WriteLine($"{Program.temas.IndexOf(t) + 1} - {t.Nombre}" );
            }
            Herramientas.DibujoMenu("Temas", temas);
        
        }

       
        public static int Seleccionar()
        {
            Imprimir();
            Console.Write("Seleccione un tema: ");
            int s = int.Parse(Console.ReadLine());//Herramientas.IngresoEnteros(1, Program.temas.Count);
            return s - 1;
        }
        public static void Eliminar()
        {
            int i = Seleccionar();
            Program.temas.RemoveAt(i);
        }
        public static void Modificar(int i)
        {
            Console.Write($"Ingrese nuevo nombre para {Program.temas[i].Nombre}: ");
            Program.temas[i].Nombre = Console.ReadLine();
        }
        public static void Menu()
        {
            string[] opciones = new string[] { "Crear", "Modificar", "Eliminar", "Listar", "Salir" };
            Console.Clear();
            Herramientas.DibujoMenu("Temas", opciones);
            Console.Write("Seleccione opcion: ");
            int o = Herramientas.IngresoEnteros(1, opciones.Length);
            switch (o)
            {
                case 1: Crear(); Menu(); break;
                case 2: Modificar(Seleccionar()); Menu(); break;
                case 3: Eliminar(); Menu(); break;
                case 4: Console.Clear(); Imprimir();  Console.ReadKey(true); Menu(); break;
                case 5: break;
            }




        }
    }
}
