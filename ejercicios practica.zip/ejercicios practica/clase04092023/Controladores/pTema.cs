﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using clase04092023.Entidades;

namespace clase04092023.Controladores
{
    internal class pTema
    {
        public static List<Tema> getAll()
        {
            List<Tema> temas = new List<Tema>();
            SQLiteCommand cmd = new SQLiteCommand("select id, nombre from Tema");
            cmd.Connection = Conexion.Connection;
            SQLiteDataReader obdr = cmd.ExecuteReader();

            while (obdr.Read())
            {
                Tema tema = new Tema();
                tema.Id = obdr.GetInt32(0);
                tema.Nombre = obdr.GetString(1);

                temas.Add(tema);
            }


            return temas;
        }
    }
}
