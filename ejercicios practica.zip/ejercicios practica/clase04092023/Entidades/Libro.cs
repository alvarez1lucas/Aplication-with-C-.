﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase04092023.Entidades
{
    internal class Libro
    {
        public int Id { get; set; }
        public string Titulo { get; set; }
        public int Paginas { get; set; }
        public List<Autor> Autores { get; set; }

        
        public Editorial Editorial { get; set; }
        public Tema Tema { get; set; }

        public string NombreAutores { get => ConcatenarAutores(); }
        
        public Libro() {
            Autores = new List<Autor>();
        }

        public Libro(int id, string titulo, int paginas,  Editorial editorial, Tema tema)
        {
            Id = id;
            Titulo = titulo;
            Paginas = paginas;
            Editorial = editorial;
            Tema = tema;
            Autores = new List<Autor>();
        }


        string ConcatenarAutores()
        {
            string a = "";
            foreach (Autor autor in Autores)
            {
                a = a + autor.Apellido;
                if (Autores.IndexOf(autor) < Autores.Count - 1)
                {
                    a = a + " - ";
                }
            }
            return a;
        }
    }
}
