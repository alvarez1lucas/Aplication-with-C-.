﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase04092023.Entidades
{
    internal class Tema
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

        public Tema() { }

        public Tema(int id, string nombre)
        {
            Id = id;
            Nombre = nombre;
        }

        public override string ToString()
        {
            return Nombre;
        }
    }
}
