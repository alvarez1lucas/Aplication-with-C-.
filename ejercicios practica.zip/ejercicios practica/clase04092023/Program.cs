﻿using clase04092023.Entidades;
using clase04092023.Controladores;
using Libreria2023;
using System.Linq.Expressions;

namespace clase04092023
{
    internal class Program
    {
        public static List<Autor> autores;
        public static List<Tema> temas;
        public static List<Editorial> editoriales;
        public static List<Libro> libros;
        static void Main(string[] args)
        {
            libros = new List<Libro>();
            autores = new List<Autor>();
            editoriales = new List<Editorial>();
            temas = new List<Tema>();

            Conexion.OpenConnection();
            Datos();
            Menu();
            Conexion.CloseConnection();
        }


        public static void Menu()
        {
            Console.Clear();
            string[] opciones = new string[] { "Temas", "Editoriales", "Autores", "Libros", "Salir" };

            Herramientas.DibujoMenu("Biblioteca", opciones);
            Console.Write("Seleccione opcion: ");
            int o = Herramientas.IngresoEnteros(1, 5);

            switch (o)
            {
                case 1: nTema.Menu(); Menu(); break;
                case 2: nEditorial.Menu(); Menu(); break;
                case 3: nAutor.Menu(); Menu(); break;
                case 4: nLibro.Menu(); Menu(); break;
                case 5: break;
            }
        }

        public static void importarAutores()
        {

            StreamReader sr = new StreamReader("autores.txt");
            string line = sr.ReadLine();
            while (line != null)
            {
                string[] datos = line.Split(';');
                autores.Add(new Autor(int.Parse(datos[0]), datos[1], datos[2]));
                line = sr.ReadLine();
            }
            sr.Close();
        }
        public static void Datos()
        {
            //temas.Add(new Tema(1, "Historia"));
            //temas.Add(new Tema(2, "Psicologia"));
            //temas.Add(new Tema(3, "Programación"));
            //temas.Add(new Tema(4, "Matemáticas"));
            temas = pTema.getAll();
            editoriales.Add(new Editorial(1, "Atlantida"));
            editoriales.Add(new Editorial(2, "ACES"));
            editoriales.Add(new Editorial(3, "System"));

            importarAutores();
            //autores.Add(new Autor(1, "Ariel", "Romero"));
            //autores.Add(new Autor(2, "Ismael", "Contreras"));
            //autores.Add(new Autor(3, "Javier", "Pavon"));

            libros.Add(new Libro(1,"Historia Argentina", 786, editoriales[1], temas[2]));
            libros[0].Autores.Add(autores[0]);
            libros[0].Autores.Add(autores[1]);

            libros.Add(new Libro(2, "Matematica Analitica", 185, editoriales[0], temas[3]));
            libros[1].Autores.Add(autores[0]);
            libros[1].Autores.Add(autores[1]);
            libros.Add(new Libro(2, "Programacion C#", 985, editoriales[2], temas[2]));
            libros[2].Autores.Add(autores[0]);
            libros[2].Autores.Add(autores[2]);
        }
    }
}